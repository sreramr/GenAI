"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""

from typing import AnyStr, Union
from abc import ABC, abstractmethod
from sqlalchemy.engine import Engine
from sqlalchemy import text

from Utility.postgres_conn import connect_sql


# move this to config
BLOB_BACKEND = "DATABASE"


class BlobStoreBase():

    @abstractmethod
    def read_blob(self, key):
        pass

    @abstractmethod
    def write_blob(self, key, blob):
        pass


class LocalFileStore(BlobStoreBase):

    def read_blob(self, key):
        raise NotImplementedError("Not Implemented")

    def write_blob(self, key, blob):
        raise NotImplementedError("Not Implemented")


class AzureBlobStore(BlobStoreBase):
    def read_blob(self, key):
        raise NotImplementedError("Not Implemented")

    def write_blob(self, key, blob):
        raise NotImplementedError("Not Implemented")


class DatabaseStore(BlobStoreBase):
    def __init__(self, conn_string=None, engine: Engine = None, table="blob_store", *args, **kwargs) -> None:
        super().__init__()
        self.engine = engine
        self.table = table

    def read_blob(self, key):
        connection = self.engine.connect()
        stmt = text(f"SELECT id, key, blob FROM {self.table} WHERE key=:key")
        result = connection.execute(stmt, **{"key": key}).mappings().fetchone()
        connection.close()
        return result["blob"]

    def write_blob(self, key, blob):
        connection = self.engine.connect()
        stmt = text(
            f"INSERT INTO {self.table} (key, blob) VALUES(:key, :blob) RETURNING id")
        result = connection.execute(
            stmt, **{"key": key, "blob": blob}).mappings().fetchone()
        connection.close()
        return result["id"]


def get_blob_client(blob_backend=None) -> BlobStoreBase:
    if not blob_backend:
        blob_backend = BLOB_BACKEND

    if blob_backend == "DATABASE":
        engine = connect_sql()
        return DatabaseStore(engine=engine)

    else:
        raise ValueError("{}: Not Implemented".format(BLOB_BACKEND))


blob_client = get_blob_client()
