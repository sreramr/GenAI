"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""


"""App URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""


from django.contrib import admin
from django.urls import include, re_path, path
from django.views.generic import TemplateView
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path("auth/", include("API.urls.authentication")),
    path("organization/", include("API.urls.organization")),
    path("role/", include("API.urls.role")),
    path("user/", include("API.urls.user")),
    path("project/", include("API.urls.project")),
    path("plan/", include("API.urls.plans")),
    path("project_files/", include("API.urls.projectFiles")),
    path("data_management/", include("API.urls.data_management")),
    path("model/", include("API.urls.model_run")),
    path("clustering/", include("API.urls.artifact_grouping")),
    path("usecase/", include("API.urls.usecase")),
    path("chat/", include("API.urls.conversation")),
    path("search/", include("API.urls.search")),
    path("configuration/", include("API.urls.configuration")),
    path("regression/", include("API.urls.reg_opt")),
    path("feature/", include("API.urls.feature")),
    path('defect_search/', include("API.urls.defect_search")),
    path('orphan_defects/', include("API.urls.orphan_defects")),
    path('change_impact_analysis_ai/', include("API.urls.change_impact_analysis_ai")),
    path('load_content/', include("API.urls.load_content")),
    path('forum/', include("API.urls.forum")),
    re_path(".*", TemplateView.as_view(template_name="index.html")),
    ]
# ] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
