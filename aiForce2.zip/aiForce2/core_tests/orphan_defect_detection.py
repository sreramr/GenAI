from langchain.chat_models import AzureChatOpenAI
from core.usecases.testing.orphan_defect_detection.main import OrphanDefectDetection
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
from langchain.llms import CTransformers
from dotenv import load_dotenv
import os

load_dotenv()

CurrentDir = os.path.abspath(os.getcwd())
AssetsDir = os.path.join(CurrentDir, "Assets")
ModelsDir = os.path.join(AssetsDir, "Models")

#output_dir = "core_tests/results/change_impact_analysis"
# model_name = "llama-2-7b-chat.Q4_K_M.gguf"
model_name = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=3500,
    #     temperature=0.3,
    #     openai_api_type='azure'
        
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})

    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )
    input_folder_path = r"core_tests\data\OrphanDefect"
    testcase_filename = "TestCaseInfo.xlsx"
    defect_filename = "Defects_Info.xlsx"
    feature_filename = "Feature_Mapping.xlsx"
    orphan_filename = "OrphanFeatures.xlsx"
    
    
    usecase = OrphanDefectDetection(
                llm=llm,
                input_folder_path = input_folder_path,
                testcase_filename = testcase_filename,
                defect_filename = defect_filename,
                feature_filename = feature_filename,
                orphan_filename = orphan_filename,
                orphan_only=True
            )

    # Same for all usecase
    usecase.execute_and_save_result(output_dir="Assets", report_format="md")  # saves result
    


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    print("\n\nOrphan Detection Started\n\n")
    result = execute_usecase()
    print("\n\nOrphan Detection Ended\n\n")
