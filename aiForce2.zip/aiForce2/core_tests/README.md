RUN STEPS:

1. Create and activate Virtual Environment
   `python -m venv .venv`
   `.venv/Scrips/activate.bat`
2. Install required packages
   `pip install -r requirements.txt`
3. Configure the .env file for Azure OpenAI and TFS credentials.
4. Run the usecases using below command, e.g., run code summarization
   `python code_summarization.py`
