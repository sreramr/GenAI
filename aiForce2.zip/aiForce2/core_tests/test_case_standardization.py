from langchain.chat_models import AzureChatOpenAI
from langchain.llms import CTransformers
from core.usecases.testing.test_case_standardization.main import TestCaseStandardizer
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
from dotenv import load_dotenv
import os
load_dotenv()

def execute_usecase():
    print("Test Case Standardization... core_tests")
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})
    
    
    CurrentDir = os.path.abspath(os.getcwd())
    AssetsDir = os.path.join(CurrentDir, "Assets")
    ModelsDir = os.path.join(AssetsDir, "Models")
    model_name = "llama-2-7b-chat.Q4_K_M.gguf"
    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )

    input_folder_path = r"core_tests\data\TestCaseStandardization"
    additional_requirements = ""

    usecase = TestCaseStandardizer(
        llm = llm,
        input_folder_path = input_folder_path,
        additional_requirements = additional_requirements,
        form_data = ["Test Case Identifier", "Test Case Name", "Test Case Description"],
        model_name = "Azure Open AI GPT 3.5 Turbo",
        llm_guard = False
    )

    try:
        usecase.execute_and_save_result(output_dir="Assets", report_format="md")
    except Exception as e:
        print(f"Results Saving Failed...{str(e)}")
        pass


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()
