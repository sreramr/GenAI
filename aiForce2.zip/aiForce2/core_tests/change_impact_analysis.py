import os
import shutil

from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import DocArrayInMemorySearch
from langchain.embeddings import OpenAIEmbeddings, HuggingFaceEmbeddings
from langchain.vectorstores import OpenSearchVectorSearch, Chroma, ElasticsearchStore
from langchain.schema.document import Document
from langchain.llms import CTransformers

from core.usecases.development.change_impact_analysis import ChangeImpactAnalyzer
from core.data_store.utils import load_document_to_vector_store
from core.data.connectors.tfs import TFSConnector
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel

CurrentDir = os.path.abspath(os.getcwd())
AssetsDir = os.path.join(CurrentDir, "Assets")
ModelsDir = os.path.join(AssetsDir, "Models")

output_dir = "core_tests/results/change_impact_analysis"
model_name = "llama-2-7b-chat.Q4_K_M.gguf"
# model_name = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})

    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )


    embeddings = OpenAIEmbeddings(
        deployment='embedding',
        chunk_size=15
    )

    # ModelName = "multi-qa-MiniLM-L6-cos-v1"
    # embeddings = HuggingFaceEmbeddings(model_name=os.path.join(ModelsDir, ModelName))

    code_db = DocArrayInMemorySearch.from_params(embedding=embeddings)
    req_db = DocArrayInMemorySearch.from_params(embedding=embeddings)
    feature_db = DocArrayInMemorySearch.from_params(embedding=embeddings)
    testcase_db = DocArrayInMemorySearch.from_params(embedding=embeddings)
    testsuite_db = DocArrayInMemorySearch.from_params(embedding=embeddings)
    defect_db = DocArrayInMemorySearch.from_params(embedding=embeddings)

    # Get code files from TFS
    # tfs_connector = TFSConnector(
    #     url=os.getenv("AZURE_DEVOPS_URL"),
    #     pat=os.getenv("AZURE_DEVOPS_PAT"),
    #     project="DataEngineering",
    #     repository="DataEngineering",
    # )

    # tfs_code_dir = "graviton/Xenius/server/Utility"
    # code_dir = "core_tests/data/tfs_files"

    # if os.path.exists(code_dir):
    #     shutil.rmtree(code_dir)
    # os.makedirs(code_dir, exist_ok=True)

    # tfs_connector.download_code_file_dir(dir=tfs_code_dir, target_dir=code_dir)

    code_dir = r"core_tests\data\Python Code"
    req_file = r"core_tests\data\ImpactAnalysis\Existing_Requirement.xlsx"
    feature_file = r"core_tests\data\ImpactAnalysis\Feature_Mapping.xlsx"
    testcase_file = r"core_tests\data\ImpactAnalysis\TestCaseInfo.xlsx"
    testsuite_file = r"core_tests\data\ImpactAnalysis\Test_Suite.xlsx"
    defect_file = r"core_tests\data\ImpactAnalysis\Defects_Info.xlsx"

    load_document_to_vector_store(
        vector_store=code_db,
        llm=llm,
        data_type="code",
        code_dir=code_dir,
        language="python"
    )

    load_document_to_vector_store(
        vector_store=req_db,
        llm=llm,
        data_type="requirement",
        input_file=req_file
    )

    load_document_to_vector_store(
        vector_store=feature_db,
        llm=llm,
        data_type="feature",
        input_file=feature_file
    )

    load_document_to_vector_store(
        vector_store=testcase_db,
        llm=llm,
        data_type="testcase",
        input_file=testcase_file
    )

    load_document_to_vector_store(
        vector_store=defect_db,
        llm=llm,
        data_type="defect",
        input_file=defect_file
    )

    usecase = ChangeImpactAnalyzer(
        llm=llm,
        code_retriever=code_db.as_retriever(),
        requirement_retriever=req_db.as_retriever(),
        feature_retriever=feature_db.as_retriever(),
        testcase_retriever=testcase_db.as_retriever(),
        testsuite_retriever=None,
        defect_retriever=defect_db.as_retriever()
    )

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    result = usecase.execute_and_save_result(
        change_request="Xenius - Add OTP authentication support for User login and Password reset functionality.", output_dir=output_dir)  # saves result
    
    ## Result saving into vector db code start from here
    embeddings = OpenAIEmbeddings(
        deployment='embedding'
    )

    # ModelName = "multi-qa-MiniLM-L6-cos-v1"
    # embeddings = HuggingFaceEmbeddings(model_name=os.path.join(ModelsDir, ModelName))

    vector_db = OpenSearchVectorSearch(
        opensearch_url="http://localhost:9200",
        index_name="cia_results",
        embedding_function=embeddings,
    )

    # vector_db = ElasticsearchStore(
    #     es_url="http://localhost:9200",
    #     index_name="cia_results",
    #     embedding_function=embeddings,
    # )
    
    # CHROMA_DB_PERSIST_DIR =  "Assets/chroma_db"
    # vector_db = Chroma(persist_directory=CHROMA_DB_PERSIST_DIR,
    #             collection_name="cia_results",
    #             embedding_function=embeddings)

    result_docs = [Document(
        page_content=result_summary.content,
        metadata={"filename": result_summary.title}
    ) for result_summary in result.report.detailed_report_list]

    ids = vector_db.add_documents(result_docs)
    return result

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()