from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from core.usecases.testing.test_script_optimization import TestScriptOptimizer
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
import os
from dotenv import load_dotenv

load_dotenv()

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=3000,
    #     temperature=0.1
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})
    

    emb = OpenAIEmbeddings(
        deployment='embedding',
        chunk_size=15
    )
    input_folder_path = r"core_tests\data\TestScriptOpt"
    llm_guard_run = False

    tso = TestScriptOptimizer(
        llm=llm,
        emb=emb,
        input_folder_path=input_folder_path,
        additional_requirements="",
        llm_guard_run=llm_guard_run
    )

    tso.execute_and_save_result(output_dir="Assets/TSO")

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()