from langchain.chat_models import AzureChatOpenAI
from langchain.llms import CTransformers
from core.usecases.testing.test_case_optimization.main import TestCaseOptimization
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
import os
from dotenv import load_dotenv

load_dotenv()

def execute_usecase():
    print("Test Case Optimization... core_tests")
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})

    CurrentDir = os.path.abspath(os.getcwd())
    AssetsDir = os.path.join(CurrentDir, "Assets")
    ModelsDir = os.path.join(AssetsDir, "Models")
    model_name = "llama-2-coder-7b.Q4_K_M.gguf"
    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )
    
    input_testcaseinfo_csv_path = r"core_tests\data\Test Case Optimization\TestCaseInfo__NT_TCG_18-12-2023_11-20-16.csv"
    input_csv_group_path = r"core_tests\data\Test Case Optimization\TestCase_Info_Group__NT_TCGP_18-12-2023_11-28-48.csv"

    usecase = TestCaseOptimization(
        llm=llm,
        input_csv_group_path=input_csv_group_path,
        input_testcaseinfo_csv_path=input_testcaseinfo_csv_path,
        model_name = "Azure Open AI GPT 3.5 Turbo",
        llm_guard = False,
        similarity_threshold=0.8
    )

    try:
        usecase.execute_and_save_result(output_dir="Assets")
    except Exception as e:
        print(f"Results Saving Failed...{str(e)}")
        pass


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()
