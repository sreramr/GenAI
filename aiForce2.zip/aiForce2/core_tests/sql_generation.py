import os

from langchain.chat_models import AzureChatOpenAI
from langchain.llms import CTransformers
from core.utilts import common_utility as common_utils
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
from core.usecases.development.sql_generation import SQLGenerator

CurrentDir = os.path.abspath(os.getcwd())
AssetsDir = os.path.join(CurrentDir, "Assets")
ModelsDir = os.path.join(AssetsDir, "Models")


input_folder_path = r"core_tests\data\SQLGeneration" # Root input folder path [Root folder contains api, req, guideline file]
req_filename = "SQL_Gen_requirements.txt" # Requirement file name [Either requirement file/additional_requirements]
guideline_filename = None # Guidelines file name [Optional]
additional_requirements = "" # Additional requirements [Either requirement file/additional_requirements]
llm_guard_run = False # LLM Guard Check 
EXEC_LIST = {"is_generate_technicaldocs" : True}  # EXEC LIST : Based on values running below additional section
output_dir = "core_tests/results/sql_generation"
DEFAULT_EXTENSION = "txt"

model_name = "llama-2-7b-chat.Q4_K_M.gguf"
# model_name = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})

    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )
  
   
    sql_gen = SQLGenerator(
                llm=llm,
                input_folder_path=input_folder_path,
                req_filename=req_filename,
                guideline_filename=guideline_filename,
                additional_requirements=additional_requirements,
                llm_guard_run=llm_guard_run,
                exec_list = EXEC_LIST
            )

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    result = sql_gen.execute_and_save_result(output_dir=output_dir)  # saves result
    for detail_section in result.report.detailed_report_list:
        common_utils.save_output_file(output_dir, detail_section.title.strip(), DEFAULT_EXTENSION, detail_section.content)
    return result


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    print("\n\nSQL Generation Started\n\n")
    result = execute_usecase()
    data = result.report
    # print(data)
    print("\n\nSQL Generation Ended\n\n")
