import os
import shutil
import re
from langchain.chat_models import AzureChatOpenAI
from langchain.llms import CTransformers

from core.usecases.development.unit_test_case_generation.main import UnitTestCaseGenerator
from core.utilts import common_utility as common_utils
from core.data.connectors.tfs import TFSConnector
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel

GEN_UNITTEST_CHECKER = "\*\*\*Generated Unit Test Case:\*\*\*"
GEN_UNITTEST_SPLITTER = "***Generated Unit Test Case:***"

input_folder_path = r"core_tests\data\UnitTestCase"
llm_guard_run = False
guideline_filename = "unittest_guidelines.txt"
output_dir = "Assets/unittestcase_generation"

model_name = "llama-2-7b-chat.Q4_K_M.gguf"
# model_name = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})

    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )

    # Get code files from TFS
    # tfs_connector = TFSConnector(
    #     url=os.getenv("AZURE_DEVOPS_URL"),
    #     pat=os.getenv("AZURE_DEVOPS_PAT"),
    #     project="DataEngineering",
    #     repository="DataEngineering",
    # )

    # tfs_code_dir = "graviton/Xenius/server/Utility"
    # code_dir = "core_tests/data/tfs_files"

    # if os.path.exists(code_dir):
    #     shutil.rmtree(code_dir)
    # os.makedirs(code_dir, exist_ok=True)

    # # tfs_connector.download_code_file_dir(dir=tfs_code_dir, target_dir=code_dir)
    # tfs_connector.download_file(path=tfs_code_dir + "/adls_utility.py", target_filepath=code_dir + "/adls_utility.py")
    # input_folder_path = code_dir

    unittest_gen = UnitTestCaseGenerator(
        llm=llm,
        input_folder_path=input_folder_path,
        guideline_filename=guideline_filename,
        additional_requirements="",
        llm_guard_run=llm_guard_run,
    )

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    result = unittest_gen.execute_and_save_result(output_dir=output_dir)  # saves result

    for detail_section in result.report.detailed_report_list: 
                title = detail_section.title
                content = detail_section.content
              
                if re.search(GEN_UNITTEST_CHECKER, content):
                    save_results_to_files(output_dir, title, content)
    return result


def save_results_to_files(output_dir, title, content):
    file_relpath = ""
    file_name_ext = os.path.splitext(title)
    file_basename = file_name_ext[0]
    ext_val = file_name_ext[1]
    unitestcase_content = content.split(GEN_UNITTEST_SPLITTER, 1)[1]
    unitestcases = unitestcase_content.split("```")
    final_unitestcases = []
    for unit_testcase in unitestcases:
        if len(unit_testcase.strip().replace("\n","")) >5:
            final_unitestcases.append(unit_testcase)
  
    split_num = 0
    for unittestcase in final_unitestcases:
        result_file_name = ''
        if len(final_unitestcases) > 1:
                split_num = split_num +1
                result_file_name = file_basename.strip() + "_unittest_part_"+str(split_num) + ext_val
        else:
            result_file_name = file_basename.strip() + "_unittest" + ext_val

        common_utils.save_output_file(output_dir, result_file_name, ext_val, str(unittestcase))    

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()
