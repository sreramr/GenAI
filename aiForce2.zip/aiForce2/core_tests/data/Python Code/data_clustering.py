"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import pandas as pd
import os
from sklearn.cluster import KMeans, DBSCAN

LABEL_COLUMN_NAME = "Default Label"
CUSTOM_LABEL_COLUMN_NAME = "Custom Label"
LABELLED_FILENAME_PREFIX = "Labelled_"

def save_file(file, filedir):
    os.makedirs(filedir, exist_ok=True)
    filepath = os.path.join(filedir, file.name)

    with open(filepath,"wb+") as f:
        for chunk in file.chunks():
            f.write(chunk)

    return filepath


def read_file_as_df(filepath, delimiter=None, selected_columns=None):
    file_type = os.path.basename(filepath).split(".")[-1]
    
    if(file_type=="csv" or file_type=="tsv"):
        df = pd.read_csv(filepath)
       
    elif(file_type=="json"):
        df = pd.read_json(filepath)
       
    else:
        raise TypeError("Invalid File type")
    
    if(selected_columns):
        df = df[selected_columns]

    return df


def read_file_with_pagination_df(filepath, page, page_size):
    df = read_file_as_df(filepath)
    offset = page_size * (page-1)
    df_page = df.iloc[ offset : offset+page_size ]
    return df_page


def infer_file_schema(filepath):
    df = read_file_as_df(filepath)
    data_types = { key: str(value) for key, value in dict(df.dtypes).items()}
    numeric_dtypes = ["int", "int32", "int64", "number", "float", "float32","float64"]
    non_numeric_fields = {}
    for column, dtype in data_types.items():
        if dtype not in numeric_dtypes:
            non_numeric_fields[column] = dtype 

    schema = {
        "total_records": df.shape[0],
        "columns": list(df.columns),
        "data_types":data_types,
        "non_numeric_columns" : non_numeric_fields
    }
    return schema


def run_clustering(algorithm, parameters, data_filepath, selected_columns):
    X = read_file_as_df(data_filepath, selected_columns= selected_columns)

    if algorithm == "K-Means":
        model = KMeans(**parameters)
        y_labels = model.fit_predict(X)

    elif algorithm == "DBSCAN":
        model = DBSCAN(**parameters)
        y_labels = model.fit_predict(X)

    else:
        raise ValueError("Algorithm - {} is not implemented".format(algorithm))

    X[LABEL_COLUMN_NAME] = pd.DataFrame(y_labels)

    dirname = os.path.dirname(data_filepath)
    filename =LABELLED_FILENAME_PREFIX + os.path.basename(data_filepath)
    labelled_filepath = os.path.join(dirname, filename)
    X.to_csv(labelled_filepath, index=False)
    return labelled_filepath, X[LABEL_COLUMN_NAME].unique().tolist()


def apply_labels(clustered_filepath, labels_map,  default_label_column = LABEL_COLUMN_NAME, custom_label_column= CUSTOM_LABEL_COLUMN_NAME):
    df = read_file_as_df(clustered_filepath)
    df[custom_label_column] = df[default_label_column].astype("str").map(labels_map).fillna(" ")
    df.to_csv(clustered_filepath,index=False)
    return clustered_filepath