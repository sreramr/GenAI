"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
from datetime import datetime
import json
import os
from threading import Thread
from Utility import SDVModelTraining as modeltrain_util
cwdPath = os.path.abspath(os.getcwd())
SDV_path = os.path.join(cwdPath, "SDV")
SDVMulti_path = os.path.join(cwdPath, "SDV_MULTI")
SDV_modelpath = os.path.join(SDV_path, "sdv_models")
SDVMulti_modelpath = os.path.join(SDVMulti_path, "sdv_models")


def create_synthetic_data_generate_table():
    query = '''CREATE TABLE IF NOT EXISTS public."synthetic_data_generation"(id serial primary key NOT NULL,
    model_name VARCHAR NOT NULL, model_type VARCHAR NOT NULL, model_file VARCHAR NOT NULL, record_count INT, 
    status VARCHAR, file_object BYTEA NULL, start_time timestamp, end_time timestamp)'''
    postgres_connection.execute_create_query(query)


def get_synthetic_data_list():
    create_synthetic_data_generate_table()
    query = '''select row_number() OVER (ORDER BY sdg.id DESC) AS slno, sdg.Id,sdg.model_name,sdg.model_type,sdg.model_file,sdg.record_count,sdg.status,sdg.start_time,sdg.end_time, coalesce(sv.train_file,'') as train_file ,CASE WHEN score=1 THEN 'Yes' ELSE 'No' END as differentially_private FROM 
    public."synthetic_data_generation"sdg LEFT OUTER JOIN sdv_models sv ON sdg.model_file = sv.sdv_model ORDER BY sdg.Id desc'''
    response = postgres_connection.execute_get_query(query, [])
    return response["data"]


def remove_generated_record(generated_id):
    try:
        query = '''DELETE FROM public."synthetic_data_generation" WHERE "id"=%s '''
        postgres_connection.execute_delete_query(query=query, data_obj=[generated_id])
        return 1
    except:
        return 0


def get_modal_by_type(model_type):
    if model_type == 'Multi Table':
        query = """select sdv_model from public."rel_sdv_models" where status='Completed'"""
    else:
        query = """select sdv_model from public."sdv_models" where status='Completed'"""
    ret = postgres_connection.execute_get_query(query, [])
    result = []
    for row in ret["data"]:
        if model_type == 'Multi Table':
            # if os.path.exists(os.path.join(SDVMulti_modelpath, row["sdv_model"])):
            result.append(row["sdv_model"])
        else:
            # if os.path.exists(os.path.join(SDV_modelpath, row["sdv_model"])):
            result.append(row["sdv_model"])
    return result


def insert_synthetic_data_list(data):
    sql = """INSERT INTO public."synthetic_data_generation"("model_name","model_type","model_file","record_count","status","start_time")
    values(%s,%s,%s,%s,%s,%s) """
    postgres_connection.execute_insert_query(query=sql, data_obj=data)

    sql = """SELECT "id" from public."synthetic_data_generation";"""
    response = postgres_connection.execute_get_query(query=sql, data_obj="")

    max = 0
    for row in response["data"]:
        if int(row['id']) > max:
            max = int(row['id'])
    return max


def get_file_name_for_model(model_name):
    select_table_sql = """SELECT train_file FROM public.sdv_models WHERE sdv_model = '""" + \
        model_name + """'"""
    results = postgres_connection.execute_get_query(
        query=select_table_sql, data_obj='')
    return results["data"][0]["train_file"]


def update_synthetic_data_list(param):
    sql = """Update public."synthetic_data_generation" set end_time='""" + \
        param[0] + """',status='""" + param[1] + \
        """' where id=""" + str(param[2]) + """;"""
    response = postgres_connection.execute_update_query(
        query=sql)
    return response


def synth_data_generation(request):
    generated_id = request.POST['generate_id']
    row_numbers = request.POST['number_of_rows']
    model_selected = request.POST['model_name']
    data_type = request.POST['model_type']
    
    # if int(generated_id) > 0:
    #     generate_util.remove_generated_record(generated_id)
    if data_type == 'Single Table':
        try:
            model_file_path = os.getcwd() + "/SDV/sdv_models/" + model_selected
            single_dataset_thread = Thread(target=modeltrain_util.generate_sdv_data,
                                           args=(model_file_path, model_selected, int(row_numbers), data_type))
            single_dataset_thread.start()
            return "Success"
            
        except Exception as e:
            return "Failed"
    else:
        try:
            model_file_path = os.getcwd() + "/SDV_MULTI/sdv_models/" + model_selected
            multi_dataset_thread = Thread(target=modeltrain_util.generate_sdv_data_multi,
                                           args=(model_file_path, model_selected, int(row_numbers), data_type))
            multi_dataset_thread.start()
            return "Success"
        except Exception as e:
            return "Failed"


def generate_synthetic_data(request):
   
    model_selected = request.POST.get('model_name')
    row_numbers = int(request.POST.get('no_rows'))
    data_type = request.POST.get('output_type')
    base_ur= request.scheme+"://"+request.get_host()
    file_exnsion = model_selected.split('.')[1]
    if file_exnsion == "pkl": 
        if row_numbers > 0:
            if data_type == 'SingleTable':
                model_file_path = os.getcwd() + "/SDV/sdv_models/" + model_selected
                path = os.path.exists(model_file_path)
                
                if path:
                    try:
                        model_file_path = os.getcwd() + "/SDV/sdv_models/" + model_selected
                        dataset= modeltrain_util.generate_sdv_single_data(model_file_path, model_selected, int(row_numbers),base_ur)
                        
                    except Exception as e:
                        dataset =  {'Status':'Failed','Message':'Data Not Generated successfully !!','Result':" "}
                else:
                    dataset ={'Status':'Failed','Message':"File "+model_selected+"is not present" ,'Result':" "}
            elif data_type == 'MultiTable':
                model_file_path = os.getcwd() + "/SDV_MULTI/sdv_models/" + model_selected
                path = os.path.exists(model_file_path)
                if path:
                    try:
                        model_file_path = os.getcwd() + "/SDV_MULTI/sdv_models/" + model_selected
                        dataset = modeltrain_util.generate_sdv_multi_data(model_file_path, model_selected, int(row_numbers), base_ur)
                        
                    except Exception as e:
                        dataset = {'Status':'Failed','Message':'Data Not Generated successfully !!','Result':" "}
                else:
                    dataset ={'Status':'Failed','Message':"File "+model_selected+" is not present" ,'Result':" "}
            else:
                    dataset ={'Status':'Failed','Message':data_type+" is not a valid Out put Data Use MultiTable or SingleTable" ,'Result':" "}
        else:
            dataset ={'Status':'Failed','Message':"File "+model_selected+" insufficient Data" ,'Result':" "}
        
        return dataset
    else:
        dataset ={'Status':'Failed','Message':"Model type is Only .pkl" ,'Result':" "}
    return dataset