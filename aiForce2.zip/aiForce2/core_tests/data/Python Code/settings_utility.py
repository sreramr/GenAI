"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
from datetime import datetime
import json
from datetime import datetime


def createtable():
    create_query = ''' CREATE TABLE IF NOT EXISTS public."setting_values"(id serial primary key NOT NULL,
        azure_subscription_id varchar  NULL, iot_hub_name varchar  NULL,
        iot_connection_string varchar  NULL, event_hub_name varchar  NULL,
        event_hub_connection_string varchar NULL, azure_storage_connection_string varchar NULL,
        aws_access_key varchar NULL, aws_secret_key varchar NULL,
        aws_region varchar NULL, aws_stream_name varchar NULL) '''
    postgres_connection.execute_create_query(create_query)


def get_settings_alldetails():
    createtable()

    query = '''select azure_subscription_id,iot_hub_name,iot_connection_string,event_hub_name,
        event_hub_connection_string,azure_storage_connection_string,
        aws_access_key,aws_secret_key,aws_region,aws_stream_name from public."setting_values"'''
    ret = postgres_connection.execute_get_query(query,[])
    return ret

def get_settings_count():
    query = '''SELECT count(*) from public."setting_values"'''
    count = 0
    ret = postgres_connection.execute_get_query(query,[])
    if ret['message'] == 'Success':
        count = int(ret['data'][0]['count'])
    return count


def save_settings_details(request):
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    selectedTab = json_req['selectedTab']
    count = get_settings_count()
    if selectedTab == 0:
        azuresubscriptionid = json_req['azuresubscriptionid']
        iothubname = json_req['iothubname']
        iotconnectionstring = json_req['iotconnectionstring']
        eventhubname = json_req['eventhubname']
        eventhubconnectionstring = json_req['eventhubconnectionstring']

        data_obj = (azuresubscriptionid, iothubname, iotconnectionstring, eventhubname, eventhubconnectionstring)
        if count == 0:
            query = 'INSERT INTO public."setting_values" (azure_subscription_id,iot_hub_name,iot_connection_string,event_hub_name,event_hub_connection_string) VALUES (%s,%s,%s,%s,%s)'
        else:
            query = 'Update public."setting_values" set azure_subscription_id =%s, iot_hub_name=%s, iot_connection_string=%s, event_hub_name=%s, event_hub_connection_string=%s'

    else:
        awsaccesskeyid = json_req['awsaccesskeyid']
        awssecretkeyid = json_req['awssecretkeyid']
        awsregion = json_req['awsregion']
        datastreamname = json_req['datastreamname']

        data_obj = (awsaccesskeyid, awssecretkeyid, awsregion, datastreamname)
        if count == 0:
            query = 'INSERT INTO public."setting_values" (aws_access_key,aws_secret_key,aws_region,aws_stream_name ) VALUES (%s,%s,%s,%s)'
        else:
            query = 'Update public."setting_values" set aws_access_key=%s, aws_secret_key=%s, aws_region=%s, aws_stream_name=%s'
    ret = postgres_connection.execute_insert_query(query, data_obj)
    return ret





######## ANOMALY DETECTION SETTINGS #######

def create_ads_settings():
    create_query = '''CREATE TABLE IF NOT EXISTS public."ads_settings"
                    (
                        id serial primary key NOT NULL,
                        ads_type character varying,
                        azure_url character varying,
                        azure_subscription_id character varying
                    )'''
    postgres_connection.execute_create_query(create_query)

def get_anomaly_detection_settings():
    create_ads_settings()

    query = '''select ads_type,azure_url,azure_subscription_id from public."ads_settings"'''
    ret = postgres_connection.execute_get_query(query,[])
    return ret


def get_settings_anomaly_count():
    create_ads_settings()
    query = '''SELECT count(*) from public."ads_settings"'''
    count = 0
    ret = postgres_connection.execute_get_query(query,[])
    if ret['message'] == 'Success':
        count = int(ret['data'][0]['count'])
    return count
    
def save_anomaly_detection_setting(request):
    create_ads_settings()
    count = get_settings_anomaly_count()
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    service_type = json_req['service_type']
    if service_type =="Azure Cognitive Services":
        url = json_req['url']
        azure_subcription_id = json_req['azure_subcription_id']
        data_obj = (service_type, url, azure_subcription_id)
        if count == 0:
                query = 'INSERT INTO public."ads_settings" (ads_type,azure_url,azure_subscription_id) VALUES (%s,%s,%s)'
                ret = postgres_connection.execute_insert_query(query, data_obj)
        else:
                query = 'Update public."ads_settings" set ads_type =%s, azure_url=%s,azure_subscription_id=%s'
                ret = postgres_connection.execute_insert_query(query, data_obj)
    else:
        if count == 0:
                query = 'INSERT INTO public."ads_settings" (ads_type) VALUES (%s)'
                ret = postgres_connection.execute_insert_query(query, [service_type])
        else:
                query = 'Update public."ads_settings" set ads_type =%s'
                ret = postgres_connection.execute_insert_query(query, [service_type])
    return ret

    