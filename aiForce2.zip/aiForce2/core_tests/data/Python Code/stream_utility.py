﻿"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
from datetime import datetime
import json
from datetime import datetime


def get_cloudtype_details():
    select_table_sql = '''select distinct(cloud_type) from public.cloud_servicetype_details;'''
    results=postgres_connection.execute_get_query(query=select_table_sql,data_obj=[])
    res = []
    if results is not None:
        for row in results["data"]:
            res.append(row["cloud_type"])
    return res


def get_cloudservicetype_details(cloud_type):
    select_table_sql = """select cloud_service_type from public.cloud_servicetype_details where cloud_type='""" + cloud_type + """'"""
    results=postgres_connection.execute_get_query(query=select_table_sql,data_obj=[])
    res = []
    if results is not None:
        for row in results["data"]:
            res.append(row["cloud_service_type"])
    return res


def get_hub_connection_details():
    data = {}
    sql_statement = 'select iot_hub_name,iot_connection_string,event_hub_name,event_hub_connection_string,aws_access_key,aws_secret_key,aws_region,aws_stream_name from public.setting_values'
    results=postgres_connection.execute_get_query(query=sql_statement,data_obj=[])
    for row in results['data']:
        data['iot_hub_name'] = row['iot_hub_name']
        data['iot_connection_string'] = row['iot_connection_string']
        data['event_hub_name'] = row['event_hub_name']
        data['event_hub_connection_string'] = row['event_hub_connection_string']
        data['aws_access_key'] = row['aws_access_key']
        data['aws_secret_key'] = row['aws_secret_key']
        data['aws_region'] = row['aws_region']
        data['aws_stream_name'] = row['aws_stream_name']
    return json.dumps(data)

def get_Validationtask_details():
    data = {}
    sql_statement = '''select td.tag_name,td.task_name,td.is_predefined,td.predefined_tag_json_format,rt.status FROM public.tag_data td inner join 
                       public.regex_tasks rt on td.task_name=rt.task_name'''
                      
    results=postgres_connection.execute_get_query(sql_statement, [])
    return results["data"]
