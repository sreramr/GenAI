"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
import urllib.parse
import json
from DataQualityCheck.db_utils import datasource as datasource_db_utilities
from DataQualityCheck.ge_utils import datasource, data_context, validation, expectations
from azure.storage.filedatalake import DataLakeServiceClient
import os
from abc import ABC, abstractmethod
import pandas as pd
import shutil
from sqlalchemy import inspect
import ssl

cwdPath = os.path.abspath(os.getcwd())
localfolder_rootpath = os.path.join(cwdPath, "DataSource")

local_file = "Local File"
database_type = "Database"
datalake = "Data Lake"
datawarehouse = "Data Warehouse"
mssql = "MSSQL"
mysql = "MySQL"
postgresql = "PostgreSQL"
azure_synapse = "Azure Synapse DWH"
actian_avalanche = "Actian Avalanche DWH"
snowflake = "Snowflake DWH"


######################################################################################
############################## UNIFIED DATA CONNECTOR CLASSES ########################
######################################################################################
class BaseDataConnector(ABC):
    def __init__(self) -> None:
        pass

    def check_connection(self):
        pass

    @abstractmethod
    def list_data_assets(self):
        pass

    @abstractmethod
    def get_data(self, data_asset):
        pass


class LocalFileDataConnector(BaseDataConnector):
    def __init__(self, files_dir) -> None:
        super().__init__()
        self.files_dir = files_dir

    def list_data_assets(self):
        file_list = []
        for root, dirs, files in os.walk(self.files_dir):
            if files:
                files1 = [os.path.join(root, file) for file in files]
                file_list += [os.path.relpath(file, self.files_dir) for file in files1]
        return file_list

    def get_data(self, data_asset: str):
        filepath = os.path.join(self.files_dir, data_asset)
        file_data = ""
        with open(filepath, "rb") as f:
            file_data = f.read()
        return file_data


class SQLAlchemyDataConnector(BaseDataConnector):
    def __init__(self, conn_str) -> None:
        super().__init__()
        self.conn_str = conn_str

    def __create_engine(self):
        engine = create_engine(self.conn_str)
        return engine

    def list_data_assets(self) -> list:
        engine = self.__create_engine()
        tables = engine.table_names()
        return tables

    def get_data(self, data_asset: str) -> pd.DataFrame:
        engine = self.__create_engine()
        df = pd.read_sql_table(table_name=data_asset, con=engine)
        return df


#########################################################################################
########################## UNIFIED DATA CONNECTOR UTILS #################################
#########################################################################################
def unified_data_connector(datasource_id):
    query = '''SELECT * from public."datasource" WHERE datasource_id=%s'''
    result = postgres_connection.execute_get_query(query, [datasource_id])
    datasource_dict = result["data"][0]
    datasource_type = datasource_dict["datasource_type"]

    if (datasource_type == database_type):
        conn_str = datasource_dict["connection_details"]
        return SQLAlchemyDataConnector(conn_str=conn_str)

    elif (datasource_type == local_file):
        datasource_name = datasource_dict["datasource_name"]
        files_dir = os.path.join(cwdPath, "DataSource", datasource_name)
        return LocalFileDataConnector(files_dir=files_dir)
    elif (datasource_type == datawarehouse):
        conn_str = datasource_dict["connection_details"]
        return SQLAlchemyDataConnector(conn_str=conn_str)
    else:
        raise ValueError("Invalid/Unsupported datasource type: {}".format(datasource_type))


def list_data_assets(datasource_id):
    data_connector = unified_data_connector(datasource_id)
    data_assets = data_connector.list_data_assets()
    return data_assets


def get_data_asset_content(datasource_id, data_asset):
    data_connector = unified_data_connector(datasource_id)
    data = data_connector.get_data(data_asset)
    return data


#########################################################################################
########################## DATASOURCE ONBOARDING ########################################
#########################################################################################
def save_localfiles(request, datasource_name):
    isExist = os.path.exists(localfolder_rootpath)
    if not isExist:
        os.makedirs(localfolder_rootpath)
    local_ds_path = os.path.join(localfolder_rootpath, datasource_name)
    isDSExist = os.path.exists(local_ds_path)
    if not isDSExist:
        os.makedirs(local_ds_path)
    uploadedLocalFile = request.FILES.getlist('uploadedLocalFile')
    for file in uploadedLocalFile:
        handle_uploaded_file(path=local_ds_path + "/", file=file)
    return {"Status": "Success"}


def delete_local_file(datasource_name):
    local_ds_path = os.path.join(localfolder_rootpath, datasource_name)
    isDSExist = os.path.exists(local_ds_path)
    if isDSExist:
        shutil.rmtree(local_ds_path)


def handle_uploaded_file(path, file):
    with open(path + file.name, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
        return path + file.name


def save_test_datasource(request):
    connection_details = ""
    test_status = {}
    final_response = {}
    json_body = request.POST.dict()

    datasource_name = json_body['datasource_name']
    is_datasource_exists = check_datasource_exists(datasource_name)
    final_response['is_datasource_exists'] = is_datasource_exists
    if is_datasource_exists != True:
        datasource_type = json_body['datasource_type']
        datasource_subtype = json_body['datasource_subtype'] if datasource_type != local_file else ""
        action_type = json_body['action_type']

        if datasource_type == local_file:
            test_status = save_localfiles(request, datasource_name)
        elif datasource_type == database_type:
            if datasource_subtype == mssql or datasource_subtype == mysql or datasource_subtype == postgresql:
                username = json_body['username']
                password = json_body['password']
                host = json_body['host']
                port = json_body['port']
                database = json_body['database']

                connection_details = create_connectiondetails_db(datasource_subtype, username, password, host, port,
                                                                 database)
                test_status = test_database_connection(connection_details, host, datasource_subtype)
        elif datasource_type == datalake:
            storage_account_name = json_body['storage_account_name']
            storage_account_key = json_body['storage_account_key']
            container_name = json_body['container_name']

            connection_details = create_connectiondetails_datalake(storage_account_name, storage_account_key)
            test_status = test_datalake_connection(connection_details, container_name)
        elif datasource_type == datawarehouse:
            connection_details = create_connectiondetails_datawarehouse(datasource_subtype, json_body)
            test_status = test_datawarehouse_connection(connection_details, datasource_subtype)
        else:
            test_status = {"Status": "Success"}

        final_response['is_tested'] = True if test_status['Status'] == "Success" else False
        final_response['test_errmsg'] = test_status['Message'] if test_status['Status'] == "Failed" else ""

        if action_type == "SAVE":
            if test_status['Status'] == "Success":
                del json_body['action_type']
                conn_metadata = json.dumps(json_body, indent=4) if datasource_type != local_file else json.dumps({})
                datasource_obj = (
                datasource_name, datasource_type, datasource_subtype, connection_details, conn_metadata)
                insert_response = insert_datasource(datasource_obj)
                final_response['is_saved'] = True if insert_response == "Success" else False
                ###### DQC DATASOURCE START ########
                context = data_context.create_context()
                files = request.FILES.getlist('files')
                ret = datasource.create_datasource(context, json_body, files)
                datasource_list = datasource_db_utilities.get_datasource_list()
                final_response['duplicate'] = False
                final_response['datasources'] = datasource_list
                final_response['status'] = ret
                final_response['actual_datasource'] = get_datasource_list()
                #### DQC DATASOURCE END ######

    return final_response


####################################################################################################
#################################### CREATE CONNECTION  DETAILS ####################################
#################################################################################################### 
def create_connectiondetails_db(datasource_subtype, username, password, host, port, database):
    driver_details = ""
    msdriver = ""
    if datasource_subtype == mssql:
        driver_details = "mssql+pyodbc"
        msdriver = "?driver=ODBC+Driver+17+for+SQL+Server&autocommit=True"
    elif datasource_subtype == mysql:
        driver_details = "mysql+pymysql"
    elif datasource_subtype == postgresql:
        driver_details = "postgresql+pg8000"
    final_password = urllib.parse.quote_plus(password)
    connection_details = driver_details + "://" + username + ":" + final_password + "@" + host + ":" + port + "/" + database + msdriver
    return connection_details


def create_connectiondetails_datalake(storage_account_name, storage_account_key):
    connection_details = "DefaultEndpointsProtocol=https;AccountName=" + storage_account_name + ";AccountKey=" + storage_account_key + ";EndpointSuffix=core.windows.net"
    return connection_details


def create_connectiondetails_datawarehouse(datasource_subtype, json_body):
    connection_details = ""
    if datasource_subtype == azure_synapse:
        username = json_body['username']
        password = json_body['password']
        host = json_body['host']
        port = json_body['port']
        database = json_body['database']
        driver_details = "mssql+pyodbc"
        final_password = urllib.parse.quote_plus(password)
        connection_details = driver_details + "://" + username + "@" + host + ":" + final_password + "@" + host + ":" + port + "/" + database + "?driver=ODBC+Driver+17+for+SQL+Server&autocommit=True"
    elif datasource_subtype == snowflake:
        username = json_body['username']
        password = json_body['password']
        account_name = json_body['host']
        schema = json_body['schema']
        role_name = json_body['role']
        database = json_body['database']
        warehouse_name = json_body['warehousename']
        driver_details = "snowflake"
        final_password = urllib.parse.quote_plus(password)
        connection_details = driver_details + "://" + username + ":" + final_password + "@" + account_name + "/" + \
        database + "/" + schema + "?warehouse=" + warehouse_name + "&role=" + role_name
    
    return connection_details


####################################################################################################
#################################### TEST  DATABASE  CONNECTION ####################################
#################################################################################################### 

def test_database_connection(connection_details, host, datasource_subtype):
    if datasource_subtype == postgresql and host !="localhost" :
         ssl_context = ssl.create_default_context()
         engine = create_engine(connection_details, client_encoding='utf8', connect_args={"ssl_context": ssl_context})
    else:
        engine = create_engine(connection_details)
    try:
        final_data = {}
        conn = engine.connect()
        table_list = engine.table_names()
        final_data["Status"] = "Success"
        final_data["Tables"] = table_list
        final_data["Message"] = ""
        conn.close()
        return final_data
    except SQLAlchemyError or Exception as err:
        final_data = {}
        final_data["Status"] = "Failed"
        final_data["Tables"] = []
        final_data["Message"] = str(err.__cause__)
        return final_data


def test_datalake_connection(connection_details, container_name):
    try:
        final_data = {}
        list_containers = []
        service_client = DataLakeServiceClient.from_connection_string(connection_details)
        list_file_systems = service_client.list_file_systems()
        for container_info in list_file_systems:
            list_containers.append(container_info.name)
        if container_name in list_containers:
            list_files = []
            file_system_client = service_client.get_file_system_client(file_system=container_name)
            paths = file_system_client.get_paths()
            for path in paths:
                if not path.is_directory:
                    table_name = path.name.split("/")[0]
                    if table_name not in list_files:
                        list_files.append(table_name)
            final_data["Status"] = "Success"
            final_data["Tables"] = list_containers
            final_data["Message"] = ""
        else:
            final_data["Status"] = "Failed"
            final_data["Tables"] = []
            final_data["Message"] = "Container Not Available"
        return final_data
    except Exception as e:
        final_data = {}
        final_data["Status"] = "Failed"
        final_data["Tables"] = []
        final_data["Message"] = str(e)
        return final_data


def test_datawarehouse_connection(connection_details, datasource_subtype):
    if datasource_subtype == azure_synapse:
            engine = create_engine(connection_details).execution_options(isolation_level="AUTOCOMMIT")
    elif datasource_subtype == snowflake:
        engine = create_engine(connection_details)
    else:
        engine = None
    try:
        final_data = {}
        conn = engine.connect()
        inspector = inspect(engine)
        schemas = inspector.get_schema_names()
        table_list = []
        for schema in schemas:
            for table_name in inspector.get_table_names(schema=schema):
                table_list.append(table_name)

        final_data["Status"] = "Success"
        final_data["Tables"] = table_list
        final_data["Message"] = ""
        conn.close()
        return final_data
    except SQLAlchemyError or Exception as err:
        final_data = {}
        print("DATAWAREHOUSE CONNECTION ERROR :>>", err.__cause__)
        final_data["Status"] = "Failed"
        final_data["Tables"] = []
        final_data["Message"] = str(err.__cause__)
        return final_data
    
    


####################################################################################################
####################################### DATABASE  CONNECTION #######################################
####################################################################################################    

def createtable_datasource():
    query = '''CREATE TABLE IF NOT EXISTS public."datasource"
            (
                datasource_id serial NOT NULL,
                datasource_name character varying(100),
                datasource_type character varying(100),
                datasource_subtype character varying(100),
                connection_details character varying(1000),
                connection_metadata json,
                active_status bit(1),
                expiry_date date
            )'''
    postgres_connection.execute_create_query(query)


def insert_datasource(datasource_obj):
    insert_query = '''INSERT INTO public."datasource"(datasource_name, datasource_type, datasource_subtype, connection_details, connection_metadata) VALUES (%s, %s, %s, %s, %s)  '''
    ret = postgres_connection.execute_insert_query(insert_query, datasource_obj)
    return ret


def check_datasource_exists(name):
    query = '''SELECT COUNT(*) from public."datasource" WHERE lower(datasource_name)=(%s)'''
    ret = postgres_connection.execute_get_query(query, [name.lower()])
    result = int(ret["data"][0]["count"])
    if (result > 0):
        return True
    else:
        return False


def get_datasource_list():
    createtable_datasource()
    query = '''SELECT row_number() OVER (ORDER BY datasource_id DESC) as slno,datasource_id, datasource_name, datasource_type, datasource_subtype,
                connection_details, connection_metadata from public."datasource"'''
    ret = postgres_connection.execute_get_query(query, [])
    return ret


def delete_datasource(request):
    datasource_name = request.GET['datasource_name']
    datasource_type = request.GET['datasource_type']
    if datasource_type == local_file:
        delete_local_file(datasource_name)

    context = data_context.create_context()
    status = datasource.delete_datasource(context, datasource_name)
    delete_query = '''DELETE FROM public."datasource" WHERE datasource_name=(%s)'''
    ret = postgres_connection.execute_delete_query(delete_query, [datasource_name])
    return ret
