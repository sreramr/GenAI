"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
import json
from datetime import datetime
from sdv.metadata import Metadata
import os
import pandas as pd
import hashlib


def createtable_user_management():
    create_query = '''CREATE TABLE IF NOT EXISTS public."user_management"(
                        id serial primary key NOT NULL,
                        user_name varchar(100) NULL,
                        email_id varchar(100) NULL,
                        unique_keys varchar(100) NULL,
                        role varchar(100) NULL,
                        security_question varchar(100) NULL,
                        security_answer varchar(100) NULL,
                        password varchar(100) NULL,
                        old_password varchar(100) NULL
                    )'''
    postgres_connection.execute_create_query(create_query)
    
def get_user_data():
    createtable_user_management()
    # query = """select * from public.user_management"""
    query="""select row_number() over (order by "id" DESC) as slno, id ,user_name,email_id,unique_keys,role,security_question,security_answer,password,old_password from 
public."user_management" order by "id" DESC"""
    ret = postgres_connection.execute_get_query(query,[])
    
    return ret

def check_useremail_exists(email_id):
    is_exists = False
    query = """SELECT COUNT(email_id) FROM public.user_management WHERE email_id = %s"""
    response = postgres_connection.execute_get_query(query, [email_id])
    email_count = int(response['data'][0]['count'])
    if(email_count > 0):
        is_exists = True

    return is_exists


def get_user_add(request):
    createtable_user_management()

    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    user_name = json_req['user_name']
    email_id = json_req['email_id']
    Unique_key = json_req['Unique_key']
    password = json_req['password']
    role = json_req['Role']
    ActionType = json_req['Type']

    if ActionType == "Add":
        data_obj = [user_name,email_id,Unique_key,password,role]
        query = '''INSERT INTO public."user_management"(user_name,email_id,unique_keys,password,role) 
        values(%s,%s,%s,%s,%s)'''
        ret = postgres_connection.execute_insert_query(query, data_obj) 
    else:
        data_obj = [user_name,email_id,password, role,Unique_key]
        query = '''Update public."user_management" set user_name=%s,email_id=%s, password=%s,role=%s where unique_keys=%s'''
        ret = postgres_connection.execute_insert_query(query, data_obj)    
    return ret

def delete_user_data(request):
    id = request.GET['id']
    print('username',id)
    query = """DELETE FROM public.user_management WHERE id = (%s)"""
    ret = postgres_connection.execute_delete_query(query,[id])
    return ret

def checkUserAuthorized(user_name,password):
    createtable_user_management()
    hashed_pass = str(hashlib.md5(password.encode()).hexdigest())
    data_obj = [user_name.lower(),password]
    query="""SELECT * FROM user_management WHERE LOWER(user_name) = %s AND password= %s """
    ret = postgres_connection.execute_get_query(query,data_obj)
    return ret

def updatepassword(request):
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)
    try:
        req_body = request.body.decode('utf-8')
        json_req = json.loads(req_body)
        oldpass = json_req['params']['old_password']
        newpass = json_req['params']['new_password']  
        mail = json_req['params']['user_mail']
        oldpassword=str(hashlib.md5(oldpass.encode()).hexdigest())
        newpassword=str(hashlib.md5(newpass.encode()).hexdigest())
        query1 = """select password from public."Users" where user_mail='""" + str(mail) +"""'""";
        ret1 = postgres_connection.execute_get_query(query1,'')
        if ret1['data'][0]['password'] == oldpassword:
            query2 = """UPDATE public."Users" SET password = '{0}' where user_mail = '{1}'""".format(
                newpassword, mail)
            ret2 = postgres_connection.execute_update_query(query2)
            if ret2 == "Success":
                return {"msg":"Password Updated Successfully" , "status":"Success"}
            else:
                return {"msg":"Failed to update password" , "status":"Failed"}
        else:
            return {"msg":"Old Password is incorrect", "status":"Failed"}
    
    except Exception as e:
        print(e)
        return {"msg": "Failed to update password", "status":"Failed"}
    
def createNewUser(name,email_id,role,password,securityQuestion,securityAnswer,Unique_keys):
    createtable_user_management()
    u_key = """select count(email_id) from public.user_management where email_id = %s"""
    get_unique_keys = postgres_connection.execute_get_query(u_key,[email_id])
    unique_keys = int(get_unique_keys['data'][0]['count'])
    if unique_keys == 0:
        data_obj = [name,email_id,role,password,securityQuestion,securityAnswer,Unique_keys]
        query = '''INSERT INTO public."user_management"(user_name,email_id,role,password,security_question,security_answer,unique_keys) 
        values(%s,%s,%s,%s,%s,%s,%s)'''
        ret = postgres_connection.execute_insert_query(query, data_obj)
    else:
        ret = "User Allready exist"
    return ret

def get_user_details(user_name,email_id):
    data_obj = [user_name,email_id]
    query="""SELECT security_question FROM user_management where user_name = %s AND email_id= %s """
    ret = postgres_connection.execute_get_query(query,data_obj)
    len_val = len(ret['data'])
    if len_val ==0:
       result =  {"data": [], "message": "Fail"}
    else:
       result = ret

    return result
def get_user_security_ans(user_name,email_id,securityAnswer):
    data_obj = [user_name,email_id]
    query="""SELECT security_answer FROM user_management where user_name = %s AND email_id= %s"""
    ret = postgres_connection.execute_get_query(query,data_obj)
    if ret['data'][0]['security_answer']==securityAnswer:
       result =  ret
    else:
       result = {"data": [], "message": "Fail"}

    return result
def update_user_password(user_name,email_id,new_password):
    data_obj = [user_name,email_id]
    query1="""SELECT password FROM user_management where user_name = %s AND email_id= %s """
    old_pass = postgres_connection.execute_get_query(query1,data_obj)
    old_password = old_pass['data'][0]['password']
    data_obj2 = [new_password,old_password,user_name,email_id]
    query2 = '''Update public."user_management" set password=%s,old_password=%s where user_name=%s And email_id=%s'''
    ret = postgres_connection.execute_insert_query(query2, data_obj2)

    return ret

def update_change_password(user_name,email_id,new_password,old_password):
    data_obj2 = [new_password,old_password,user_name,email_id]
    query2 = '''Update public."user_management" set password=%s,old_password=%s where user_name=%s And email_id=%s'''
    ret = postgres_connection.execute_insert_query(query2, data_obj2)

    return ret
def user_user_details(email_id):
    query = """select password from public.user_management where email_id = %s"""
    ret= postgres_connection.execute_get_query(query,[email_id])
    print (ret)
    return ret['data'][0]['password']    
    