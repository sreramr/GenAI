"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
import json
from datetime import datetime
from sdv.metadata import Metadata
import os
import pandas as pd

def createtable():
    create_query = '''CREATE TABLE IF NOT EXISTS public."sdv_models"(
                    id serial primary key NOT NULL,
                    start_time TIMESTAMP NULL,
                    train_file varchar(100) NULL,
                    sdv_model varchar(100) NULL,
                    end_time TIMESTAMP NULL,
                    status varchar(100) NULL,
                    score real NULL,
                    model_object BYTEA NULL
                )'''
    postgres_connection.execute_create_query(create_query)
    
def get_sdv_models_list():
    createtable()
    query = '''select sdv_model, status from public."sdv_models" where status='Completed' 
            order by id desc'''
    ret = postgres_connection.execute_get_query_modellist(query,[],'single')
    return ret

def insert_sdv_model(start_time, train_file, final_modelname, status, differential_private):
    data_obj = (start_time,train_file, final_modelname, status, differential_private)
    query = '''insert into public."sdv_models" (start_time, train_file, sdv_model, status,score) values(%s, %s,%s,%s,%s)'''
    ret = postgres_connection.execute_insert_query(query, data_obj)

    select_query = '''SELECT max(id) from public."sdv_models";'''
    ret_select = postgres_connection.execute_get_query(select_query,[])
    sdv_model_id = 0
    if ret_select['message'] == 'Success':
        sdv_model_id = int(ret_select['data'][0]['max']) 
    return sdv_model_id

def get_sdv_model_object(model_name):
    select_query = "SELECT model_object FROM sdv_models WHERE sdv_model=%s"
    results = postgres_connection.execute_sql_query(select_query,[model_name])
    if(len(results)==0):
        raise ValueError("Model not found in DB for model_name={}".format(model_name))
    return results[0]["model_object"]

def update_sdv_model(end_time, status, sdv_model_id, model_object=None):
    data_obj = (end_time, status, model_object, sdv_model_id)
    query = '''Update public."sdv_models" set end_time=%s,status=%s, model_object=%s where id=%s'''
    ret = postgres_connection.execute_insert_query(query, data_obj)
    return ret

def get_defaultmodelname(request):
    createtable()
    prefix_modelname = request.GET['prefix_modelname']
    query = '''select max(split_part(split_part(sdv_model,'.pkl',1),'_',2)::integer) from  public.sdv_models where split_part(split_part(sdv_model,'.pkl',1),'_',1) =%s and split_part(split_part(sdv_model,'.pkl',1),'_',2) ~ '^[0-9\.]+$' '''
    ret = postgres_connection.execute_get_query(query,[prefix_modelname])
    return ret

def get_modelname_exists(request):
    modelname = request.GET['modelname']
    query = '''select count(*) from public.sdv_models where split_part(sdv_model,'.pkl',1)=(%s)'''
    ret = postgres_connection.execute_get_query(query,[modelname])
    return ret


def get_trainedmodel_list():
    query = """select row_number() OVER (ORDER BY id DESC) AS slno,id,start_time, train_file, sdv_model,end_time,status from public.sdv_models where score=0"""
    ret = postgres_connection.execute_get_query_modellist(query,[],'single')
    return ret

def delete_trainedmodel(request):
    id = request.GET['id']
    query = '''DELETE from public.sdv_models where id =%s'''
    ret = postgres_connection.execute_delete_query(query,[id])
    return ret

###################################################################################################
########################################### MULTI TABLE ###########################################
###################################################################################################

def createtable_multi():
    create_query = '''CREATE TABLE IF NOT EXISTS public."rel_sdv_models"(
                        id serial primary key NOT NULL,
                        start_time TIMESTAMP NULL,
                        meta_file varchar(100) NULL,
                        sdv_model varchar(100) NULL,
                        end_time TIMESTAMP NULL,
                        status varchar(100) NULL,
                        model_object BYTEA
                    )'''
    postgres_connection.execute_create_query(create_query)

def get_defaultmodelname_multi(request):
    createtable_multi();
    prefix_modelname = request.GET['prefix_modelname']
    query = '''select max(split_part(split_part(sdv_model,'.pkl',1),'_',2)::integer) from  public.rel_sdv_models where split_part(split_part(sdv_model,'.pkl',1),'_',1) =%s and split_part(split_part(sdv_model,'.pkl',1),'_',2) ~ '^[0-9\.]+$' '''
    ret = postgres_connection.execute_get_query(query,[prefix_modelname])
    return ret

def get_modelname_exists_multi(request):
    modelname = request.GET['modelname']
    query = '''select count(*) from public.rel_sdv_models where split_part(sdv_model,'.pkl',1)=(%s)'''
    ret = postgres_connection.execute_get_query(query,[modelname])
    return ret

def get_trainedmodel_list_multi():
    query = '''select row_number() OVER (ORDER BY id DESC) AS slno,id,start_time, meta_file, sdv_model,end_time,status from public.rel_sdv_models'''
    ret = postgres_connection.execute_get_query_modellist(query,[],'multi')
    return ret

def insert_sdv_model_multi(start_time, meta_file, final_modelname, status):
    data_obj = (start_time,meta_file, final_modelname, status)
    query = '''insert into public."rel_sdv_models" (start_time, meta_file, sdv_model, status) values(%s, %s,%s,%s)'''
    ret = postgres_connection.execute_insert_query(query, data_obj)

    select_query = '''SELECT max(id) from public."rel_sdv_models";'''
    ret_select = postgres_connection.execute_get_query(select_query,[])
    sdv_model_id = 0
    if ret_select['message'] == 'Success':
        sdv_model_id = int(ret_select['data'][0]['max']) 
    return sdv_model_id

def get_sdv_model_object_multi(model_name):
    select_query = "SELECT model_object FROM rel_sdv_models WHERE sdv_model=%s"
    results = postgres_connection.execute_sql_query(select_query,[model_name])
    if(len(results)==0):
        raise ValueError("Model not found in DB for model_name={}".format(model_name))
    return results[0]["model_object"]

def update_sdv_model_multi(end_time, status, sdv_model_id, model_object=None):
    data_obj = (end_time, status, model_object, sdv_model_id)
    query = '''Update public."rel_sdv_models" set end_time=%s,status=%s, model_object=%s where id=%s'''
    ret = postgres_connection.execute_insert_query(query, data_obj)
    return ret

def delete_trainedmodel_multi(request):
    id = request.GET['id']
    query = '''DELETE from public.rel_sdv_models where id =%s'''
    ret = postgres_connection.execute_delete_query(query,[id])
    return ret


def create_synthetic_data_generate_table():
    query = '''CREATE TABLE IF NOT EXISTS public."synthetic_data_generation"(id serial primary key NOT NULL,
    model_name VARCHAR NOT NULL, model_type VARCHAR NOT NULL, model_file VARCHAR NOT NULL, record_count INT, 
    status VARCHAR, file_object BYTEA NULL, start_time timestamp, end_time timestamp)'''
    postgres_connection.execute_create_query(query)
###################################################################################################
########################################## GENERATE DATA ##########################################
###################################################################################################
def insert_synthetic_data_list(data):
    create_synthetic_data_generate_table()
    data_obj = data
    query = '''INSERT INTO public."synthetic_data_generation"(model_name,model_type,model_file,record_count,status,start_time) 
    values(%s,%s,%s,%s,%s,%s)'''
    ret = postgres_connection.execute_insert_query(query, data_obj)

    select_query = '''SELECT max(id) from public."synthetic_data_generation";'''
    ret_select = postgres_connection.execute_get_query(select_query,[])
    sdv_model_id = 0
    if ret_select['message'] == 'Success':
        sdv_model_id = int(ret_select['data'][0]['max']) 
    return sdv_model_id

def get_file_name_for_model(model_name):
    select_query = '''SELECT train_file FROM public.sdv_models WHERE sdv_model = %s'''
    ret_select = postgres_connection.execute_get_query(select_query,[model_name])
    if ret_select['message'] == 'Success':
        return ret_select['data'][0]['train_file']
    

def get_synth_generated_file_object(id):
    select_query = '''SELECT file_object FROM public.synthetic_data_generation WHERE id = %s'''
    results = postgres_connection.execute_sql_query(select_query,[id])
    if len(results) > 0:
        return results[0]["file_object"]
    else:
        raise ValueError("No records found with id={id} in synthetic_data_generation".format(id=id))
    

def update_synthetic_data_list(data):
    data_obj = data
    query = '''Update public."synthetic_data_generation" set end_time=%s,status=%s, file_object=%s where id=%s'''
    ret = postgres_connection.execute_insert_query(query, data_obj)
    return ret


def insert_differntiate_sdv_model(start_time, train_file, final_modelname, status, differential_private):
    data_obj = (start_time,train_file, final_modelname, status, differential_private)
    query = '''insert into public."sdv_models" (start_time, train_file, sdv_model, status,score) values(%s, %s,%s,%s,%s)'''
    ret = postgres_connection.execute_insert_query(query, data_obj)

    select_query = '''SELECT max(id) from public."sdv_models";'''
    ret_select = postgres_connection.execute_get_query(select_query,[])
    sdv_model_id = 0
    if ret_select['message'] == 'Success':
        sdv_model_id = int(ret_select['data'][0]['max']) 
    return sdv_model_id


def get_trainedmodel_list_differnetial():
    query = """select row_number() OVER (ORDER BY id DESC) AS slno,id,start_time, train_file, sdv_model,end_time,status from public.sdv_models where score=1"""
    ret = postgres_connection.execute_get_query_modellist(query,[],'single')
    return ret


### delete record for valid_atask page
def delete_validtaskrecord(request):
   
    id = request.GET['id']
  
    query = '''DELETE FROM public.tag_data where task_name = %s'''
    ret = postgres_connection.execute_delete_query(query,[id])
    return ret

####################################################################################
############################### Save Metadata ######################################
####################################################################################
def save_metadata_json(metadata_json, metapath, file_paths, parse:bool= False):
    if not parse:
        with open(metapath, "w") as file:
            json.dump(metadata_json,file, indent=2)
        return metadata_json


    # RECREATION
    tables = {}
    for file_path in file_paths:
        file_basename = os.path.basename(file_path)
        file_name, file_type = os.path.splitext(file_basename)

        if file_type == ".json":
            tables[file_name] = pd.read_json(file_path)
        else:
            tables[file_name] = pd.read_csv(file_path)
        # default csv reader
    
    def add_table_to_metadata(table_name,tables, metadata:Metadata, metadata_json):
        is_root_table = True
        parent = None
        foreign_key = None

        for field,value in metadata_json["tables"][table_name]["fields"].items():
            if value.get("ref"):
                is_root_table = False
                parent = value["ref"]["table"]
                foreign_key = field
                if parent not in metadata.get_tables():
                    add_table_to_metadata(parent, tables, metadata, metadata_json)
        
        if is_root_table:
            metadata.add_table(
                name=table_name,
                data=tables[table_name],
                primary_key= metadata_json["tables"][table_name]["primary_key"]
            )
        else:
            metadata.add_table(
                name=table_name,
                data=tables[table_name],
                primary_key= metadata_json["tables"][table_name]["primary_key"],
                parent= parent,
                foreign_key= foreign_key
            )

    metadata = Metadata()
    for table_name in tables:
        if table_name not in metadata.get_tables():
            add_table_to_metadata(table_name, tables, metadata, metadata_json)

    metadata_json = metadata.to_dict()

    with open(metapath, "w") as file:
        json.dump(metadata_json,file, indent=2)

    return metadata_json
    