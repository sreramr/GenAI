"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
from datetime import datetime
import json
from datetime import datetime


def dataset_counts():
    data = {}
    query1 = """SELECT (select count(*) from public.sdv_models where status='Completed' ) as single_model_count,
        (select count(*)  from public.rel_sdv_models where status='Completed') as rel_model_count,
        (select count(*) from public."synthetic_data_generation" where "status"='Completed' and "model_type"='Single Table') as single_model_generated ,
        (select count(*) from public."synthetic_data_generation" where "status"='Completed' and "model_type"='Multi Table') as multiple_model_generated
        ;"""
    results = postgres_connection.execute_get_query(query=query1, data_obj='')
    if results is not None:
        data['single_model_count'] = results["data"][0]["single_model_count"]
        data['rel_model_count'] = results["data"][0]["rel_model_count"]
        data['single_model_generated'] = results["data"][0]["single_model_generated"]
        data['multiple_model_generated'] = results["data"][0]["multiple_model_generated"]
    else:
        data['single_model_count'] = 0
        data['rel_model_count'] = 0
        data['single_model_generated'] = 0
        data['multiple_model_generated'] = 0
    return data


def get_recent_sdv_models(data=None):
    sql = """select row_number() OVER (ORDER BY id DESC) AS slno, id,train_file, sdv_model from public.sdv_models order by id desc limit 5"""
    response = postgres_connection.execute_get_query_modellist(sql, [], 'single')
    return response["data"]


def get_recent_rel_sdv_models(data=None):
    sql = """select row_number() OVER (ORDER BY id DESC) AS slno, id,meta_file,sdv_model from public.rel_sdv_models where status='Completed' order by id desc limit 5"""
    response = postgres_connection.execute_get_query_modellist(sql, [], 'multi')
    return response["data"]
