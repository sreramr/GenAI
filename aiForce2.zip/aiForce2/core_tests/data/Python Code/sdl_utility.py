"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import itertools
import json
from datetime import datetime
from json import JSONEncoder

import numpy

from Utility import postgres_conn as postgres_connection
from azure.storage.filedatalake import DataLakeServiceClient
import os
from detect_delimiter import detect
import pandas as pd
import io
import pandavro as pdx
from Utility import adls_utility as adls_util
from Utility import adx_utility as adx_util


def create_domain_object_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_domain_objects(id serial primary key NOT NULL, object_name 
    VARCHAR NOT NULL, database_name VARCHAR NOT NULL, host_name VARCHAR NULL, port VARCHAR NULL, user_name VARCHAR 
    NULL, password VARCHAR NULL, access_level VARCHAR NOT NULL, provider_name VARCHAR NOT NULL, storage_name VARCHAR 
    NULL, storage_key VARCHAR NULL, is_active boolean default(true), created_at VARCHAR NOT NULL, 
    updated_at VARCHAR NULL, datasource_name VARCHAR) '''
    postgres_connection.execute_create_query(query)


def get_domain_objects():
    create_domain_object_table()
    query = '''select row_number() OVER (ORDER BY created_at DESC) as slno, * from public.sdl_domain_objects'''
    response = postgres_connection.execute_get_query(query, [])
    return response


def create_providers_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_storage_providers(id serial primary key NOT NULL, provider_name 
        VARCHAR NOT NULL)'''
    postgres_connection.execute_create_query(query)


def get_providers():
    create_providers_table()
    query = '''select provider_name from public.sdl_storage_providers'''
    response = postgres_connection.execute_get_query(query, [])
    return response


def initialize_storage_account(storage_account_name, storage_account_key):
    try:
        global service_client
        service_client = DataLakeServiceClient(account_url="{}://{}.dfs.core.windows.net".format(
            "https", storage_account_name), credential=storage_account_key)
    except Exception as e:
        print(e)


def get_container_list(storage_name, access_key):
    list_containers = []
    initialize_storage_account(storage_name, access_key)
    list_file_systems = service_client.list_file_systems()
    for container_info in list_file_systems:
        list_containers.append(container_info.name)
    return list_containers


def get_file_list(db_name):
    list_files = []
    file_system_client = service_client.get_file_system_client(file_system=db_name)
    paths = file_system_client.get_paths()
    for path in paths:
        if not path.is_directory:
            table_name = path.name.split("/")[0]
            if table_name not in list_files:
                list_files.append(table_name)
    return list_files


def obj_dict(obj):
    return obj.__dict__


class Object:
    def toJSON(self):
        return json.dumps(self, default=lambda o: o.__dict__,
                          sort_keys=True, indent=4)


class Fields:
    def __init__(self, name, type, selected, alias_name, mask, accesslevel, access_controlled):
        self.FieldName = name
        self.DataType = type
        self.IsSelected = selected
        self.AliasName = alias_name
        self.Mask = mask
        self.AccessLevel = accesslevel
        self.AccessControlled = access_controlled


def retrieve_columns_of_adls_file(path, db_name):
    file_system_client = service_client.get_file_system_client(db_name)
    file_client = file_system_client.get_file_client(path.name)
    file_ext = os.path.basename(path.name).split('.', 1)[1]
    if file_ext in ["csv", "tsv"]:
        with open("adls_file/csv_file.txt", "wb") as my_file:
            download = file_client.download_file()
            download.readinto(my_file)
        with open('adls_file/csv_file.txt', 'r') as file:
            data = file.read()
        row_delimiter = detect(text=data, default=None, whitelist=[',', ';', ':', '|', '\t'])
        processed_df = pd.read_csv('adls_file/csv_file.txt', sep=row_delimiter)
    if file_ext == "parquet":
        download = file_client.download_file()
        stream = io.BytesIO()
        download.readinto(stream)
        processed_df = pd.read_parquet(stream, engine='pyarrow')
    if file_ext == "avro":
        with open("adls_file/avro_file.avro", "wb") as my_file:
            download = file_client.download_file()
            download.readinto(my_file)
        processed_df = pdx.read_avro("adls_file/avro_file.avro")
    column_list = []
    for key, val in dict(processed_df.dtypes).items():
        if str(val) == 'object':
            try:
                pd.to_datetime(processed_df[str(key)])
                column_list.append({"column_name": str(key), 'data_type': 'datetime64'})
            except ValueError:
                column_list.append({"column_name": str(key), 'data_type': 'string'})
                pass
        else:
            column_list.append({"column_name": str(key), 'data_type': str(val)})
    return column_list


def get_tables_schema_list(db_name, table_list):
    table_field_obj = Object()
    table_field_obj.data = []
    table_list = json.loads(table_list)
    file_system_client = service_client.get_file_system_client(file_system=db_name)
    paths = file_system_client.get_paths()
    for table in table_list:
        for path in paths:
            if not path.is_directory:
                table_name = path.name.split("/")[0]
                if table_name == table:
                    column_dict = retrieve_columns_of_adls_file(path, db_name)
                    tf_obj = Object()
                    tf_obj.TableName = str(table).strip()
                    tf_obj.AliasName = ""
                    tf_obj.Fields = []
                    for item in column_dict:
                        tf_obj.Fields.append(
                            Fields(str(item['column_name']), str(item['data_type']), False, "", "NA", "Public",
                                   False))
                    table_field_obj.data.append(tf_obj)
                    break
    return json.dumps(table_field_obj, default=obj_dict)


def create_table_details_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_table_details(id serial primary key NOT NULL, object_id 
        INT NOT NULL, table_name VARCHAR NOT NULL, alias_name VARCHAR NULL, created_at VARCHAR NOT NULL, 
        updated_at VARCHAR NULL) '''
    postgres_connection.execute_create_query(query)


def create_field_details_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_field_details(id serial primary key NOT NULL, table_id 
            INT NOT NULL, field_name VARCHAR NOT NULL, data_type VARCHAR NOT NULL, is_selected boolean default(false),
            alias_name VARCHAR NULL, mast_encrypt VARCHAR NULL, access_level VARCHAR NOT NULL, 
            access_controlled boolean default(false), created_at VARCHAR NOT NULL, updated_at VARCHAR NULL) '''
    postgres_connection.execute_create_query(query)


def create_join_details_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_join_details(id serial primary key NOT NULL, object_id 
                INT NOT NULL, left_table VARCHAR NOT NULL, right_table VARCHAR NOT NULL, join_type VARCHAR NOT NULL,
                left_field VARCHAR NULL, right_field VARCHAR NULL, condition VARCHAR NOT NULL) '''
    postgres_connection.execute_create_query(query)


def create_where_details_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_where_details(id serial primary key NOT NULL, object_id 
                    INT NOT NULL, table_name VARCHAR NOT NULL, field_name VARCHAR NOT NULL, condition VARCHAR NOT NULL,
                    compare_value VARCHAR NOT NULL) '''
    postgres_connection.execute_create_query(query)


def insert_domain_object(request_data):
    create_domain_object_table()
    create_table_details_table()
    create_field_details_table()
    create_join_details_table()
    create_where_details_table()
    domain_object_obj = (request_data["ObjectName"], request_data["database_name"], request_data["AccessLevel"],
                         request_data["data_store_connection"]["provider_name"],
                         request_data["data_store_connection"]["storage_account_name"],
                         request_data["data_store_connection"]["storage_access_key"], datetime.now(),
                         request_data["data_store_connection"]["datasource_name"])
    insert_query = '''INSERT INTO public.sdl_domain_objects(object_name, database_name, access_level, provider_name, 
    storage_name, storage_key, created_at, datasource_name) VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id;'''
    ins_object_result = postgres_connection.execute_insert_query_get_id(insert_query, domain_object_obj)
    for table in request_data["table_and_fields"]:
        table_obj = (ins_object_result, table["TableName"], table["AliasName"], datetime.now())
        insert_query = '''INSERT INTO public.sdl_table_details(object_id, table_name, alias_name, created_at) 
        VALUES(%s, %s, %s, %s) RETURNING id;'''
        ins_table_result = postgres_connection.execute_insert_query_get_id(insert_query, table_obj)
        field_list = []
        for field in table["Fields"]:
            field_obj = (ins_table_result, field["FieldName"], field["DataType"], field["IsSelected"],
                         field["AliasName"], field["Mask"], field["AccessLevel"], field["AccessControlled"],
                         datetime.now())
            field_list.append(field_obj)
        insert_query = '''INSERT INTO public.sdl_field_details(table_id, field_name, data_type, is_selected,
        alias_name, mast_encrypt, access_level, access_controlled, created_at) 
        VALUES(%s, %s, %s, %s,%s, %s, %s, %s, %s)'''
        ins_field_result = postgres_connection.execute_insertmany_query(insert_query, field_list)
    join_list = []
    for join in request_data["join_details"]:
        join_obj = (ins_object_result, join["leftTable"], join["rightTable"], join["joinCategory"], join["leftField"],
                    join["rightField"], join["joinCondition"])
        join_list.append(join_obj)
    if len(join_list) > 0:
        insert_query = '''INSERT INTO public.sdl_join_details(object_id, left_table, right_table, join_type,
            left_field, right_field, condition) VALUES(%s, %s, %s, %s, %s, %s, %s)'''
        ins_join_result = postgres_connection.execute_insertmany_query(insert_query, join_list)
    where_list = []
    for where in request_data["where_details"]:
        where_obj = (ins_object_result, where["tableName"], where["fieldName"], where["condition"],
                     where["entered_value"])
        where_list.append(where_obj)
    if len(where_list) > 0:
        insert_query = '''INSERT INTO public.sdl_where_details(object_id, table_name, field_name, condition,
                    compare_value) VALUES(%s, %s, %s, %s, %s)'''
        ins_where_result = postgres_connection.execute_insertmany_query(insert_query, where_list)
    return True


def get_join_details_by_object_id(domain_object_id):
    query = '''select * from public.sdl_join_details WHERE object_id = %s'''
    response = postgres_connection.execute_get_query(query, [domain_object_id])
    return response["data"]


def get_where_details_by_object_id(domain_object_id):
    query = '''select * from public.sdl_where_details WHERE object_id = %s'''
    response = postgres_connection.execute_get_query(query, [domain_object_id])
    return response["data"]


def get_domain_object_details(domain_object_id):
    query = '''select * from public.sdl_table_details WHERE object_id = %s'''
    response = postgres_connection.execute_get_query(query, [domain_object_id])
    table_field_obj = Object()
    table_field_obj.field_data = []
    for table in response["data"]:
        tf_obj = Object()
        tf_obj.TableId = table["id"]
        tf_obj.TableName = table["table_name"]
        tf_obj.AliasName = table["alias_name"]
        tf_obj.Fields = []
        query = '''select * from public.sdl_field_details WHERE table_id = %s'''
        response = postgres_connection.execute_get_query(query, [table["id"]])
        for field_row in response["data"]:
            tf_obj.Fields.append(
                Fields(field_row["field_name"], field_row["data_type"], field_row["is_selected"],
                       field_row["alias_name"], field_row["mast_encrypt"], field_row["access_level"],
                       field_row["access_controlled"]))
        table_field_obj.field_data.append(tf_obj)
        table_field_obj.join_data = get_join_details_by_object_id(domain_object_id)
        table_field_obj.where_data = get_where_details_by_object_id(domain_object_id)
    return json.dumps(table_field_obj, default=obj_dict)


def get_user_list():
    query = '''select * from public.user_management'''
    response = postgres_connection.execute_get_query(query, [])
    return response["data"]


def create_object_level_permission_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_object_level_permission(id serial primary key NOT NULL, 
    user_id INT, object_id INT, access_level VARCHAR, is_allowed boolean default(true))'''
    postgres_connection.execute_create_query(query)


def delete_object_level_permission(user_id, object_id):
    query = '''DELETE FROM public.sdl_object_level_permission WHERE user_id=%s and object_id=%s'''
    postgres_connection.execute_delete_query(query, [user_id, object_id])


def execute_object_level_permission(request_data):
    create_object_level_permission_table()
    delete_object_level_permission(request_data["user_id"], request_data["object_id"])
    object_level_data = (request_data["user_id"], request_data["object_id"], request_data["accesstype"],
                         request_data["permission"] == "Allow")
    insert_query = '''INSERT INTO public.sdl_object_level_permission(user_id, object_id, access_level, is_allowed) 
    VALUES (%s, %s, %s, %s)'''
    ins_object_result = postgres_connection.execute_insert_query(insert_query, object_level_data)
    return ins_object_result == "Success"


def get_domain_objects_by_user(user_id):
    query = """SELECT bod.id, bod.object_name, coalesce(op.access_level, bod.access_level) as access_level FROM 
        sdl_domain_objects bod LEFT OUTER JOIN sdl_object_level_permission op ON bod.id = op.object_id AND op.user_id=%s
        WHERE (op.user_id = %s AND op.is_allowed=True) OR bod.access_level='Public'"""
    response = postgres_connection.execute_get_query(query, [user_id, user_id])
    return response["data"]


def get_row_access_cont_field(object_id):
    query = '''SELECT fd.id as field_id, fd.field_name FROM public.sdl_field_details fd 
    INNER JOIN public.sdl_table_details td ON fd.table_id = td.id 
    INNER JOIN sdl_domain_objects sd ON td.object_id = sd.id
    WHERE fd.access_controlled = True AND sd.id=%s'''
    response = postgres_connection.execute_get_query(query, [object_id])
    return response["data"]


def get_adls_store_details_by_field_id(field_id):
    query = '''SELECT td.table_name, sd.storage_name, sd.database_name, sd.storage_key, fd.field_name, 
    sd.id as object_id
    FROM public.sdl_field_details fd
    INNER JOIN public.sdl_table_details td ON fd.table_id = td.id
    INNER JOIN sdl_domain_objects sd ON td.object_id = sd.id
    WHERE fd.id = %s'''
    response = postgres_connection.execute_get_query(query, [field_id])
    return response["data"]


def create_row_permission_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_row_permission_details(id serial primary key NOT NULL,
    user_id INT NOT NULL, field_id INT NOT NULL, field_value VARCHAR NOT NULL, is_allowed boolean default(true))'''
    postgres_connection.execute_create_query(query)


def get_row_permission_details(user_id, field_id):
    create_row_permission_table()
    query = """Select field_value from public.sdl_row_permission_details where user_id=%s and field_id = %s 
    and is_allowed = True"""
    response = postgres_connection.execute_get_query(query, [user_id, field_id])
    return response["data"]


class NumpyArrayEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, numpy.ndarray):
            return obj.tolist()
        return JSONEncoder.default(self, obj)


def get_row_access_cont_field_value(field_id, user_id):
    adls_store_details = get_adls_store_details_by_field_id(field_id)
    storage_name = adls_store_details[0]["storage_name"]
    storage_key = adls_store_details[0]["storage_key"]
    container_name = adls_store_details[0]["database_name"]
    field_name = adls_store_details[0]["field_name"]
    parent_folder_name = adls_store_details[0]["table_name"]
    object_id = adls_store_details[0]["object_id"]
    field_val_df = adls_util.get_field_value_from_adls(storage_name, storage_key, container_name, parent_folder_name,
                                                       [str(field_name)])
    row_permission_details = get_row_permission_details(user_id, field_id)
    permitted_values = []
    for row in row_permission_details:
        permitted_values.append(row["field_value"])
    list_values = [field_val_df[field_name].unique() for col_name in field_val_df.columns]
    encoded_numpy_data = json.loads(json.dumps(list_values, cls=NumpyArrayEncoder))[0]
    field_values = []
    for item in encoded_numpy_data:
        if item in permitted_values:
            field_values.append({"field_value": item, "is_selected": True})
        else:
            field_values.append({"field_value": item, "is_selected": False})
    return field_values


def delete_row_permission_if_exist(user_id, field_id):
    query = '''DELETE FROM public.sdl_row_permission_details WHERE user_id=%s and field_id=%s'''
    postgres_connection.execute_delete_query(query, [user_id, field_id])


def execute_row_level_permission(request_data):
    create_row_permission_table()
    user_id = request_data["user_id"]
    field_id = request_data["field_id"]
    field_values = json.loads(request_data["field_values"])
    delete_row_permission_if_exist(user_id, field_id)
    row_permission_list = []
    for field in field_values:
        row_obj = (user_id, field_id, field["field_value"])
        row_permission_list.append(row_obj)
    if len(row_permission_list) > 0:
        insert_query = '''INSERT INTO public.sdl_row_permission_details(user_id, field_id, field_value) 
        VALUES(%s, %s, %s)'''
        postgres_connection.execute_insertmany_query(insert_query, row_permission_list)
    return True


def create_column_level_permission_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_column_permission_details(id serial primary key NOT NULL,
    user_id INT NOT NULL, field_id INT NOT NULL, is_allowed boolean default(true))'''
    postgres_connection.execute_create_query(query)


def get_col_permission_data(user_id, object_id):
    query = '''SELECT cp.field_id FROM public.sdl_column_permission_details cp
    INNER JOIN public.sdl_field_details fd ON cp.field_id = fd.id
    INNER JOIN public.sdl_table_details td ON fd.table_id = td.id
    INNER JOIN public.sdl_domain_objects sd ON td.object_id = sd.id
    WHERE cp.user_id = %s AND sd.id=%s AND cp.is_allowed=True'''
    response = postgres_connection.execute_get_query(query, [user_id, object_id])
    return response["data"]


def set_field_access_level(field_access_level, usr_obj_access_level, permitted_field_ids, field_id):
    if field_access_level == "Public":
        return True
    elif usr_obj_access_level == "Private":
        return True
    elif field_access_level == "Protected" and usr_obj_access_level == "Protected":
        return True
    elif field_id in permitted_field_ids:
        return True
    else:
        return False


def get_object_attributes_for_permission(object_id, user_id, usr_obj_access_level):
    create_column_level_permission_table()
    query = '''SELECT fd.id as field_id, fd.field_name, fd.access_level
    FROM public.sdl_domain_objects sd
    INNER JOIN public.sdl_table_details td ON sd.id = td.object_id
    INNER JOIN public.sdl_field_details fd ON td.id = fd.table_id
    WHERE fd.is_selected=True and sd.id=%s'''
    field_list = postgres_connection.execute_get_query(query, [object_id])
    col_permission = get_col_permission_data(user_id, object_id)
    permitted_col_field_ids = []
    for col in col_permission:
        permitted_col_field_ids.append(col["field_id"])
    col_list = []
    for field in field_list["data"]:
        col_list.append({
            "user_id": user_id,
            "field_id": field["field_id"],
            "field_name": field["field_name"],
            "field_access_level": field["access_level"],
            "is_selected": set_field_access_level(field["access_level"], usr_obj_access_level,
                                                  permitted_col_field_ids, field["field_id"])
        })
    return col_list


def delete_column_level_permission(user_id, field_id):
    query = '''DELETE FROM public.sdl_column_permission_details WHERE user_id=%s AND field_id=%s'''
    postgres_connection.execute_delete_query(query, [user_id, field_id])


def execute_column_level_permission(request_data):
    field_attrs = json.loads(request_data["field_attrs"])
    col_perm_list = []
    for field in field_attrs:
        delete_column_level_permission(field["user_id"], field["field_id"])
        col_permission_obj = (field["user_id"], field["field_id"], field["is_selected"])
        col_perm_list.append(col_permission_obj)
    insert_query = '''INSERT INTO public.sdl_column_permission_details(user_id, field_id, is_allowed) 
        VALUES(%s, %s, %s)'''
    postgres_connection.execute_insertmany_query(insert_query, col_perm_list)
    return True


def get_userdetails_by_user_key(user_key):
    query = '''select * from public.user_management where unique_keys =%s'''
    response = postgres_connection.execute_get_query(query, [user_key])
    return response["data"]


def get_business_object_data_by_name(object_name):
    sql = """select object_name, id from public.sdl_domain_objects where object_name = %s"""
    response = postgres_connection.execute_get_query(sql, [object_name])
    return response["data"]


def create_sdl_adx_function_details_table():
    query = '''CREATE TABLE IF NOT EXISTS public.sdl_adx_function_details(id serial primary key NOT NULL,
    user_id INT NOT NULL, object_id INT NOT NULL, function_name VARCHAR)'''
    postgres_connection.execute_create_query(query)


def get_adx_functions_by_user_and_object_id(user_id, object_id):
    create_sdl_adx_function_details_table()
    sql = '''SELECT function_name FROM public.sdl_adx_function_details WHERE object_id=%s AND user_id=%s'''
    response = postgres_connection.execute_get_query(sql, [object_id, user_id])
    if len(response["data"]) > 0:
        return response["data"][0]["function_name"]
    else:
        return None


def insert_adx_function(user_id, object_id, function_name):
    query = '''INSERT INTO public.sdl_adx_function_details(user_id, object_id, function_name) VALUES(%s,%s,%s)'''
    return postgres_connection.execute_insert_query(query, (user_id, object_id, function_name))


def get_business_object_data_for_user_by_id(object_id, user_id):
    try:
        sql = f"select * from public.sdl_domain_objects where id = '{object_id}'"
        response = postgres_connection.execute_get_query(sql, [])
        return response["data"]
    except Exception as e:
        print(e)
        return []


def get_tables_data_for_user_by_detail_id(object_id, user_id):
    sql = """select * from public.sdl_table_details where object_id = %s"""
    response = postgres_connection.execute_get_query(sql, [object_id])
    return response["data"]


def get_fields_for_user_by_object_id(object_id, user_id):
    print(object_id, user_id)
    sql = """SELECT DISTINCT fd.*, fd.access_level as field_access_level,COALESCE(ob.access_level,fd.access_level) as UserAccessLevel, 
    td.table_name FROM sdl_field_details fd INNER JOIN sdl_table_details td ON fd.table_id = td.id 
    INNER JOIN sdl_domain_objects bod ON bod.id = td.object_id LEFT OUTER JOIN sdl_object_level_permission ob 
    ON bod.id = ob.object_id AND ob.user_id=%s LEFT OUTER JOIN sdl_column_permission_details cp 
    on fd.id = cp.field_id AND cp.user_id=%s WHERE bod.id = %s AND fd.is_selected=True 
    AND (((ob.access_level IS NULL AND fd.access_level in('Public')) OR (ob.access_level IS NOT NULL AND ob.user_id = %s)) 
    AND ((ob.access_level IN ('Public') AND fd.access_level IN('Public','Protected')) 
    OR (ob.access_level IN('Private','Protected')) OR (ob.access_level IS NULL)) OR (cp.is_allowed=True))"""
    response = postgres_connection.execute_get_query(sql, [user_id, user_id, object_id, user_id])
    return response["data"]


def get_joins_by_detail_id(object_id):
    sql = '''select * from public.sdl_join_details where object_id = %s'''
    response = postgres_connection.execute_get_query(sql, [object_id])
    return response["data"]


def get_where_clauses_by_detail_id(object_id):
    sql = '''select DISTINCT wd.*, fd.data_type from public.sdl_where_details wd INNER JOIN 
    sdl_field_details fd ON ((wd.field_name=fd.field_name AND fd.alias_name='') OR (wd.field_name=fd.alias_name AND 
    fd.alias_name!='')) AND fd.is_selected=False AND wd.object_id=%s INNER JOIN sdl_table_details td ON 
    td.id=fd.table_id AND td.object_id=%s '''
    response = postgres_connection.execute_get_query(sql, [object_id, object_id])
    return response["data"]


def get_row_permission_for_user_by_detail_id(object_id, user_id):
    query = '''SELECT td.table_name, fd.field_name, rp.field_value, fd.alias_name FROM sdl_row_permission_details rp INNER JOIN 
    sdl_field_details fd ON rp.field_id = fd.id INNER JOIN sdl_table_details td ON fd.table_id = td.id WHERE 
    rp.is_allowed = True AND rp.user_id = %s AND td.object_id = %s '''
    response = postgres_connection.execute_get_query(query, [user_id, object_id])
    return response["data"]


def get_kusto_query_json_for_user_object(user_id, object_id):
    query_obj = Object()
    is_sql = True
    obj_data = get_business_object_data_for_user_by_id(object_id, user_id)
    if len(obj_data) > 0:
        obj_data = obj_data[0]
        query_obj.DatabaseName = obj_data["database_name"]
        query_obj.Tables = []
        table_list = get_tables_data_for_user_by_detail_id(object_id, user_id)
        for table in table_list:
            if is_sql:
                query_obj.Tables.append(f'tbl_{table["table_name"]}')
            else:
                query_obj.Tables.append(obj_data["database_name"] + '.' + table["table_name"])
        query_obj.Fields = []
        field_list = get_fields_for_user_by_object_id(object_id, user_id)
        for field in field_list:
            field_obj = Object()
            field_obj.TableName = f'tbl_{field["table_name"]}'
            field_obj.FieldName = field["field_name"]
            field_obj.DataType = field["data_type"]
            field_obj.Alias = field["alias_name"]
            # field["field_name"] if field["alias_name"] == '' else field["alias_name"]
            field_obj.Mask = field["mast_encrypt"]
            field_obj.AccessLevel = field["field_access_level"]
            query_obj.Fields.append(field_obj)
        query_obj.Joins = []
        join_list = get_joins_by_detail_id(object_id)
        for join in join_list:
            join_obj = Object()
            join_obj.LeftTable = f'tbl_{join["left_table"]}'
            join_obj.JoinType = join["join_type"]
            join_obj.RightTable = f'tbl_{join["right_table"]}'
            join_obj.Condition = "="
            join_obj.LeftColumn = join["left_field"]
            join_obj.RightColumn = join["right_field"]
            query_obj.Joins.append(join_obj)
        query_obj.Where = []
        where_list = get_where_clauses_by_detail_id(object_id)
        for where in where_list:
            where_obj = Object()
            where_obj.TableName = f'tbl_{where["table_name"]}'
            where_obj.columnName = where["field_name"]
            where_obj.Condition = where["condition"]
            where_obj.Value = "'" + where["compare_value"] + "'" if where["data_type"] == "string" else where["compare_value"]
            query_obj.Where.append(where_obj)
        query_obj.RowPermission = []
        row_permission_list = get_row_permission_for_user_by_detail_id(object_id, user_id)
        for row_permission in row_permission_list:
            row_obj = Object()
            row_obj.TableName = f'tbl_{row_permission["table_name"]}'
            row_obj.ColumnName = row_permission["field_name"]
            row_obj.Value = row_permission["field_value"]
            row_obj.AliasName = row_permission["field_name"] if row_permission["alias_name"] == '' else row_permission[
                "alias_name"]
            query_obj.RowPermission.append(row_obj)
    query_json = json.dumps(query_obj, default=obj_dict)
    return query_json


def get_user_access_level_on_object(object_id, user_id):
    query = '''select COALESCE(access_level, '') as access_level from sdl_object_level_permission where is_allowed = 
    True and object_id =%s and user_id = %s '''
    response = postgres_connection.execute_get_query(query, [object_id, user_id])
    return response["data"]


def get_kusto_join_type(param):
    if param == "Inner Join":
        return "inner"
    elif param == "Left Join":
        return "leftouter"
    elif param == "Right Join":
        return "rightouter"
    elif param == "Cross Join":
        return "inner"
    elif param == "Full Join":
        return "fullouter"


def create_kusto_query(query_json, object_access_level, object_id, user_id, function_name, filter_data):
    json_data = json.loads(query_json)
    join_list = json_data["Joins"]
    dynamic_query = ".create-or-alter function with (docstring = 'User Based Semantico Domain Object', " \
                    "folder='Graviton') " + function_name + "(){ let  mask_data=(column_data:string)  {strcat (substring(" \
                                                            "column_data, 0,1),(replace_string(column_data,column_data,'****')), strcat (substring(column_data, 5) ))}; " \
                                                            "external_table('"
    if len(join_list) > 0:
        first_join_clause = join_list[0]
        dynamic_query += first_join_clause["LeftTable"] + "')"
        dynamic_query += f'|join kind={get_kusto_join_type(first_join_clause["JoinType"])} '
        right_table = first_join_clause["RightTable"]
        left_column = first_join_clause["LeftColumn"]
        if first_join_clause["Condition"] == "=":
            first_join_clause["Condition"] = "=="
        join_cond = first_join_clause["Condition"]
        right_column = first_join_clause["RightColumn"]
        dynamic_query += f"external_table('{right_table}') on $left.{left_column}{join_cond}$right.{right_column}"
        for join in join_list[1:]:
            right_table = join["RightTable"]
            left_column = join["LeftColumn"]
            if join["Condition"] == "=":
                join["Condition"] = "=="
            join_cond = join["Condition"]
            dynamic_query += f'|join kind={get_kusto_join_type(join["JoinType"])} '
            dynamic_query += f"external_table('{right_table}') on $left.{left_column}{join_cond}$right.{right_column}"
    else:
        dynamic_query += json_data["Tables"][0] + "')"

    duplicate_fields = []
    select_fields = []
    for field in json_data["Fields"]:
        if field["FieldName"] in duplicate_fields:
            field["FieldName"] = field["FieldName"] + str(duplicate_fields.count(field["FieldName"]))
            duplicate_fields.append(field["FieldName"])
        else:
            duplicate_fields.append(field["FieldName"])
        field["Alias"] = field["FieldName"] if field["Alias"] == '' else field["Alias"]

    user_access_level_obj = get_user_access_level_on_object(object_id, user_id)
    user_access_level = object_access_level
    if len(user_access_level_obj) > 0:
        user_access_level = user_access_level_obj[0]["access_level"]
    if user_access_level == "Public":
        for field in json_data["Fields"]:
            field_access_level = str(field["AccessLevel"])
            if field_access_level == "Protected":
                field["FieldName"] = f'hash_md5({field["FieldName"]})'
    if user_access_level == "Protected":
        for field in json_data["Fields"]:
            field_access_level = str(field["AccessLevel"])
            if field_access_level == "Private":
                field["FieldName"] = f'hash_md5({field["FieldName"]})'

    for field in json_data["Fields"]:
        if user_access_level != 'Private':
            field_mask_encrypt = str(field["Mask"])
            if field_mask_encrypt == "Encrypt":
                field["Alias"] = f'{field["Alias"]}=hash_md5({field["FieldName"]})'
            elif field_mask_encrypt == "Mask":
                field["Alias"] = f'{field["Alias"]}=mask_data({field["FieldName"]})'
            else:
                field["Alias"] = f'{field["Alias"]}={field["FieldName"]}'
        else:
            field["Alias"] = f'{field["Alias"]}={field["FieldName"]}'
        select_fields.append(field["Alias"])
    dynamic_query += f'|project {",".join(select_fields)}'

    where_list = json_data["Where"]
    if len(where_list) > 0:
        first_where_clause = where_list[0]
        sql_text = ' |where '
        if first_where_clause["Condition"] == "=":
            first_where_clause["Condition"] = "=="
        sql_text += first_where_clause["columnName"] + first_where_clause["Condition"] + first_where_clause["Value"]
        for clause in where_list[1:]:
            sql_text += " and " + clause["columnName"] + clause["Condition"] + clause["Value"]
        dynamic_query += sql_text
    row_permission_list = json_data["RowPermission"]
    print(row_permission_list)
    if len(row_permission_list) > 0:
        if len(where_list) > 0:
            sql_text = ' and '
        else:
            sql_text = ' |where '
        key_group = lambda x: x["AliasName"]
        for key, group in itertools.groupby(row_permission_list, key_group):
            group_json = json.dumps(list(group))
            group_data = json.loads(group_json)
            sql_text += key + " in ('" + "','".join(data["Value"] for data in group_data) + "')"
        dynamic_query += sql_text
    dynamic_query += "}"
    return dynamic_query


def get_data_from_adls(user_key, object_name, filter_data, api_response=False):
    user_data = get_userdetails_by_user_key(user_key)
    if user_data is None:
        return {"data": [], "message": "Invalid User", "result": "Fail"}
    else:
        user_id = user_data[0]["id"]
    object_data = get_business_object_data_by_name(object_name)
    if object_data is None:
        return {"data": [], "message": "Invalid Object Name", "result": "Fail"}
    else:
        object_id = object_data[0]["id"]
    function_data = get_adx_functions_by_user_and_object_id(user_id, object_id)
    if function_data is None:
        import uuid
        function_name = str(uuid.uuid4()).replace("-", "_")
        insert_adx_function(user_id, object_id, function_name)
    else:
        function_name = function_data
    query_json = get_kusto_query_json_for_user_object(user_id, object_id)
    domain_object_detail_obj = get_business_object_data_for_user_by_id(object_id, user_id)
    object_access_level = domain_object_detail_obj[0]["access_level"]
    dynamic_query = create_kusto_query(query_json, object_access_level,
                                       object_id, user_id, function_name, filter_data)
    print(dynamic_query)
    try:
        adx_util.execute_kusto_query(dynamic_query)
        print("function created")
        if filter_data is not None and filter_data != "":
            function_name += " | where " + filter_data
        result_data_frame = adx_util.retrieve_data_from_adx(function_name)
    except Exception as e:
        print(e)
        result_data_frame = pd.DataFrame(["Error occurred while executing kusto query. Please check if Azure Data "
                                          "Explorer cluster is in running state."], columns=["Result"])
    if api_response:
        return result_data_frame
    return {"data": result_data_frame.head(100).to_html(classes='rwd-table',
                                                        justify='left', index=False),
            "result_count": len(result_data_frame), "result": "success"}


def handle_object_active_inactive(request_data):
    object_id = request_data["object_id"]
    is_active = request_data["is_active"]
    query = f'UPDATE public.sdl_domain_objects SET is_active={is_active} WHERE id={object_id}'
    postgres_connection.execute_update_query(query)
    return True


def remove_domain_object(request_data):
    object_id = request_data["object_id"]
    query = f'DELETE FROM sdl_domain_objects WHERE id={object_id}'
    postgres_connection.execute_delete_all_query(query)
    return True


def get_datalake_datasource():
    query = "SELECT * FROM public.datasource WHERE datasource_subtype='ADLS Gen 2'"
    response = postgres_connection.execute_get_query(query, [])
    return response["data"]
