"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
from datetime import datetime
import json
import os
import random
import pandas as pd
from detect_delimiter import detect
import pandavro as pdx
from avro.datafile import DataFileReader
from avro.io import DatumReader
from pyarrow.parquet import ParquetFile
import pyarrow as pa
import numpy as np
from LabelDataset import labelling_utils as utils


def handle_uploaded_file(path, file):
    with open(path + file.name, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
        return path + file.name, file.name.split(".")[1]


def save_uploaded_file(request):
    selectedDataFile = request.FILES['selectedDataFile']
    delimiter = request.POST['delimiter']
    file_path, file_ext = handle_uploaded_file(
        path='LabelDataset/uploaded_files/', file=selectedDataFile)
    size_take = 100
    if file_ext in ["csv", "tsv"]:
        num_records = sum(1 for line in open(file_path)) - 1
        if num_records > size_take:
            skip = sorted(random.sample(
                range(1, num_records + 1), num_records - size_take))
        else:
            skip = 0
        with open(file_path, 'r') as file:
            data = file.readline(10)
        row_delimiter = detect(text=data, default=None, whitelist=[
                               ',', ';', ':', '|', '\t', ' '])
        if delimiter != "null":
            row_delimiter = delimiter
        file_content = pd.read_csv(file_path, sep=row_delimiter, quotechar="'", escapechar="/", engine='python',
                                   skiprows=skip)
    elif file_path.endswith(".json"):
        file_content = pd.read_json(file_path)
    elif file_path.endswith(".avro"):
        reader = DataFileReader(open(file_path, "rb"), DatumReader())
        schema = json.loads(reader.meta.get('avro.schema').decode('utf-8'))
        file_content = pdx.read_avro(file_path, schema=schema, na_dtypes=True)
    elif file_path.endswith(".parquet"):
        pf = ParquetFile(file_path)
        take_rows = next(pf.iter_batches(batch_size=size_take))
        file_content = pa.Table.from_batches([take_rows]).to_pandas()
    else:
        try:
            file_content = pd.read_csv(file_path, sep=delimiter)
        except:
            raise ValueError("Invalid file format")

    column_list = []
    for key, val in dict(file_content.dtypes).items():
        if str(val) == 'object':
            try:
                pd.to_datetime(file_content[str(key)])
                column_list.append(
                    {"column_name": str(key), 'data_type': 'datetime64'})
            except ValueError:
                column_list.append(
                    {"column_name": str(key), 'data_type': 'string'})
                pass
        else:
            column_list.append(
                {"column_name": str(key), 'data_type': str(val)})
    return file_content.to_json(orient="records", date_format='iso'), column_list


def get_sample_result_of_individual_rule(request):
    rule_json = json.loads(request.POST['rule_json'])
    file_path = request.POST.get("file_path")
    label_list = json.loads(request.POST['label_list'])
    default_label = request.POST.get("default_label")
    response = utils.get_sample_result_of_individual_rule(rule_json, file_path, label_list, default_label)
    return response.to_json(orient="records", date_format='iso')
   

def apply_rule(request):
    rule_list = json.loads(request.POST['rule_list'])
    file_path = request.POST.get('file_path')
    label_list = json.loads(request.POST['label_list'])
    default_label = request.POST.get("default_label")
    response = utils.label_dataset(rule_list, file_path, label_list, default_label)
    return response.to_json(orient="records", date_format='iso')


def download_result(filename):
    rootpath = "LabelDataset/result_files/"
    full_filepath = os.path.join(rootpath,filename)
    file_exists = os.path.exists(full_filepath)
    if file_exists == False:
        response = "Failed"
        return response, 0
    else:
        downloadfile_content = open(full_filepath, 'rb')
        return downloadfile_content, 1


def get_sample_result_of_individual_rule_ver2(request):
    rule_json = json.loads(request.POST['rule_json'])
    file_path = request.POST.get("file_path")
    label_list = json.loads(request.POST['label_list'])
    default_label = request.POST.get("default_label")
    response = utils.get_sample_result_of_individual_rule_ver2(rule_json, file_path, label_list, default_label)
    return response.to_json(orient="records", date_format='iso')


def get_label_list(label_json):
    label_list = []
    label_weightage = []
    for item in label_json:
        label_list.append(item["label_name"])
        if item["label_weightage"] != "":
            weightage_perc = float(item["label_weightage"]) / 100
            label_weightage.append(np.around(weightage_perc, 2))
        else:
            label_weightage.append(1 / len(label_json))
    return label_list, label_weightage


def apply_rule_ver2(request):
    rule_list = json.loads(request.POST['rule_list'])
    file_path = request.POST.get("file_path")
    label_json = json.loads(request.POST['label_list'])
    label_list, label_weightage = get_label_list(label_json)
    not_satisfy_label = request.POST.get("default_label")
    include_proba = request.POST.get("include_prob") == 'true'
    response = utils.label_dataset_ver2(rule_list, file_path, label_list, not_satisfy_label, label_weightage,
                                        include_proba)
    return response


def upload_and_read_labelled_file(request):
    selectedDataFile = request.FILES['selectedDataFile']
    delimiter = request.POST['delimiter']
    file_path, file_ext = handle_uploaded_file(
        path='LabelDataset/autolabel_uploads/', file=selectedDataFile)
    size_take = 100
    if file_ext in ["csv", "tsv"]:
        num_records = sum(1 for line in open(file_path)) - 1
        if num_records > size_take:
            skip = sorted(random.sample(
                range(1, num_records + 1), num_records - size_take))
        else:
            skip = 0
        with open(file_path, 'r') as file:
            data = file.readline(10)
        row_delimiter = detect(text=data, default=None, whitelist=[
                               ',', ';', ':', '|', '\t', ' '])
        if delimiter != "null":
            row_delimiter = delimiter
        file_content = pd.read_csv(file_path, sep=row_delimiter, quotechar="'", escapechar="/", engine='python',
                                   skiprows=skip)
    elif file_path.endswith(".json"):
        file_content = pd.read_json(file_path)
    elif file_path.endswith(".avro"):
        reader = DataFileReader(open(file_path, "rb"), DatumReader())
        schema = json.loads(reader.meta.get('avro.schema').decode('utf-8'))
        file_content = pdx.read_avro(file_path, schema=schema, na_dtypes=True)
    elif file_path.endswith(".parquet"):
        pf = ParquetFile(file_path)
        take_rows = next(pf.iter_batches(batch_size=size_take))
        file_content = pa.Table.from_batches([take_rows]).to_pandas()
    else:
        try:
            file_content = pd.read_csv(file_path, sep=delimiter)
        except:
            raise ValueError("Invalid file format")

    column_list = []
    for key, val in dict(file_content.dtypes).items():
        if str(val) == 'object':
            try:
                pd.to_datetime(file_content[str(key)])
                column_list.append(
                    {"column_name": str(key), 'data_type': 'datetime64'})
            except ValueError:
                column_list.append(
                    {"column_name": str(key), 'data_type': 'string'})
                pass
        else:
            column_list.append(
                {"column_name": str(key), 'data_type': str(val)})
    return file_content.to_json(orient="records", date_format='iso'), column_list


def get_label_and_weightage(request):
    delimiter = request.POST.get("delimiter")
    file_path = request.POST.get("file_path")
    marked_label_column = request.POST.get('marked_label_column')
    label_list_with_weightage = utils.get_label_and_weightage(file_path, marked_label_column, delimiter)
    return label_list_with_weightage