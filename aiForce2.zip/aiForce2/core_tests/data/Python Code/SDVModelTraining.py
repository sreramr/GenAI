"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import json
from datetime import datetime
from pydoc import resolve
from threading import Thread
import pandas as pd
from parser import ParserError
import cloudpickle
import os
from sdv.tabular import GaussianCopula, CTGAN, CopulaGAN, TVAE
import sys
from Utility import sdvmodels_utility as sdvmodels_util
import configparser
import glob
import shutil
from sdv import Metadata
from sdv.relational import HMA1
import math
from faker import Faker
import re
from snsynth import Synthesizer
from django.templatetags.static import static
# from opendp.smartnoise.synthesizers.mwem import MWEMSynthesizer
# from opendp.smartnoise.synthesizers.quail import QUAILSynthesizer
# from opendp.smartnoise.synthesizers.pytorch.pytorch_synthesizer import PytorchDPSynthesizer
# from opendp.smartnoise.synthesizers.preprocessors.preprocessing import GeneralTransformer
# from diffprivlib.models import LogisticRegression as DPLR
# from opendp.smartnoise.synthesizers.pytorch.nn.patectgan import PATECTGAN

from DataQualityCheck.ge_utils.data_context import create_context
from great_expectations.core.batch import BatchRequest
from .datasource_utility import get_data_asset_content
from io import StringIO

fake = Faker()
cwdPath = os.path.abspath(os.getcwd())
sdv_path = os.path.join(cwdPath, "SDV")
uploadfile_path = os.path.join(sdv_path, "uploaded_files")
config_path = os.path.join(cwdPath, "config")
logfile_path = os.path.join(sdv_path, "log_files")
modeltypesjsonpath = os.path.join(config_path, "modeltypes.json")


def start_singlemodel_training(request):
    sdvmodels_util.createtable()
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']

    modelname = json_req['modelname']
    algorithm = json_req['algorithm']
    batchsize = json_req['batchsize']
    epoch = json_req['epoch']
    epsilon = float(json_req['epsilon'])
    preprocessor_eps  = epsilon/2 # prepocessor budget 50 % of epsilon
    filepath = json_req['filepath']
    masking_details = json_req['masking_details']
    constraints_details = json_req['constraints_details']
    primarykey_details = json_req['primarykey_details']
    datatype_details = json_req['datatype_details']

    filename = filepath.rsplit('/', 1)[-1]

    if len(datatype_details) !=0:
        datatype_details = datatype_details[filename]
        update_uploaded_file_datatype_change(filepath, datatype_details)

    create_constraints(constraints_details)
    if len(masking_details) !=0:
        masking_columnlist = []
        masking_details = masking_details[filename]
        for column in masking_details.keys():
            masking_type = masking_details[column]
            if masking_type != "No Masking Selected":
                masking_columnlist.append(column)

        if len(masking_columnlist) > 0:
            update_uploaded_file_as_anonymized(filepath, masking_details)

    model_type_json = pd.read_json(modeltypesjsonpath, typ='series')
    model_type = model_type_json[algorithm]

    train_thread = Thread(target=single_table_sdv_model_training,
                          args=(filepath, modelname, model_type, batchsize, epoch, primarykey_details, epsilon, preprocessor_eps))
    train_thread.start()
    ret = {}
    ret['data'] = "data"
    ret['message'] = "Success"
    return ret


def single_table_sdv_model_training(file_path, model_name, model_type, batch_size, epoch_size, primarykey_details, epsilon, preprocessor_eps):
    # checking if file format is valid or not
    if file_path.endswith(".csv"):
        train_df = pd.read_csv(file_path)
    elif file_path.endswith(".json"):
        train_df = pd.read_json(file_path)
        train_df = pd.json_normalize(train_df.to_dict("records"))
    elif file_path.endswith(".tsv"):
        train_df = pd.read_table(file_path)
    else:
        raise ValueError("Invalid train file format")

    train_file = os.path.basename(file_path)

    # train_df = train_df.head(100)  # trimming training data to reduce time
    datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    differential_private = 1
    if model_type == 'GaussianCopula' or model_type == 'CopulaGAN' or model_type == 'TVAE' or model_type == 'CTGAN':
        differential_private = 0
    sdv_model_id = sdvmodels_util.insert_sdv_model(datetime_now, train_file, model_name + ".pkl", "In-Progress", differential_private)
    try:
        field_trans_dict = get_transformer_by_dtype(train_df)
        exec(open(os.path.join(sdv_path, 'constraints_data.txt')).read())
        constraints = eval('return_constraints()')
        log = open(os.path.join(logfile_path, model_name+".txt"), "w")
        stdout = sys.stdout
        sys.stdout = log
       
        if model_type == 'GaussianCopula':
            if primarykey_details != "": 
                model = GaussianCopula(primary_key=primarykey_details, field_transformers=field_trans_dict, constraints=constraints)
            else:
                model = GaussianCopula(field_transformers=field_trans_dict, constraints=constraints)
        elif model_type == 'CopulaGAN':
            if primarykey_details != "": 
                model = CopulaGAN(primary_key=primarykey_details, field_transformers=field_trans_dict, cuda=True,
                              verbose=True, batch_size=int(batch_size), epochs=int(epoch_size), constraints=constraints)
            else:
                model = CopulaGAN(field_transformers=field_trans_dict, cuda=True,
                              verbose=True, batch_size=int(batch_size), epochs=int(epoch_size), constraints=constraints)
        elif model_type == 'TVAE':
            if primarykey_details != "":
                model = TVAE(primary_key=primarykey_details, field_transformers=field_trans_dict, epochs=int(epoch_size), batch_size=int(batch_size),
                         constraints=constraints)
            else:
                model = TVAE(field_transformers=field_trans_dict, epochs=int(epoch_size), batch_size=int(batch_size),
                         constraints=constraints)
        elif model_type == 'CTGAN':
            if primarykey_details != "":
                model = CTGAN(primary_key=primarykey_details, verbose=True, cuda=False, batch_size=int(batch_size), epochs=int(epoch_size),
                          field_transformers=field_trans_dict, constraints=constraints)
            else:
                model = CTGAN(verbose=True, cuda=False, batch_size=int(batch_size), epochs=int(epoch_size),
                          field_transformers=field_trans_dict, constraints=constraints)
        # Differential Privacy Algorithms Code Start
        elif model_type == 'MST' or  model_type == 'PAC-Synth':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, epsilon=epsilon, verbose=True)
        elif model_type == 'MWEM':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, epsilon=epsilon, verbose=True)
        elif model_type == "DP-CTGAN" or model_type == 'PATE-CTGAN':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, 
                epsilon= epsilon,
                batch_size=int(batch_size), epochs=int(epoch_size),
                verbose=True)
        elif model_type == 'PATE-GAN':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, epsilon=epsilon, batch_size=int(batch_size))
        # elif model_type == "QUAIL":
        #     def QuailClassifier(epsilon):
        #         return DPLR(epsilon=epsilon, data_norm=5.02)

        #     def QuailSynth(epsilon):
        #         return PytorchDPSynthesizer(preprocessor=None,
        #                         gan=PATECTGAN(loss='cross_entropy', batch_size=50, pack=1, sigma=5.0))

        #     model = QUAILSynthesizer(3.0, QuailSynth, QuailClassifier, target='married', eps_split=0.8)

           
        else:
            # FALLBACK MODEL = default CTGAN
            if primarykey_details != "":
                model = CTGAN(primary_key=primarykey_details, verbose=True, cuda=False, batch_size=int(batch_size), epochs=int(epoch_size),
                          field_transformers=field_trans_dict, constraints=constraints)
            else:
                model = CTGAN(verbose=True, cuda=False, batch_size=int(batch_size), epochs=int(epoch_size),
                          field_transformers=field_trans_dict, constraints=constraints)

        if model_type == 'GaussianCopula' or model_type == 'CopulaGAN' or model_type == 'TVAE' or model_type == 'CTGAN':
            model.fit(train_df)
        elif model_type == 'MWEM':
            train_df = train_df.drop(['income', 'age'], axis=1)
            model.fit_sample(train_df, preprocessor_eps=preprocessor_eps)
        # elif model_type == 'QUAIL':
        #     model.fit(train_df)
        else:
            model.fit(train_df, preprocessor_eps=preprocessor_eps)
        log.close()
        sys.stdout = stdout

        sample_df = model.sample(100)
        sample_df.to_csv("SDV/new_files/"+model_name +
                            "_" + train_file, index=False)
        # if file_path.endswith(".tsv"):
        #     sample_df.to_csv("SDV/new_files/"+model_name +
        #                     "_" + train_file, index=False, sep='\t')
        # elif file_path.endswith(".csv"):
        #     sample_df.to_csv("SDV/new_files/"+model_name +
        #                     "_" + train_file, index=False)
        # else:
        #     sample_df.to_json("SDV/new_files/"+model_name +
        #                     "_" + train_file, index=False, orient='records')
        with open("SDV/sdv_models/" + model_name + ".pkl", 'wb') as f:
            cloudpickle.dump(model, f)
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_sdv_model(datetime_now, "Completed", sdv_model_id, model_object= cloudpickle.dumps(model))
        return "model saved successfully"
       
    except Exception as e:
        failed_log_path = os.path.join("SDV/failed_log_files",model_name+".txt")
        if os.path.exists(failed_log_path):
            os.remove(failed_log_path)
        failed_log_file = open(failed_log_path,"w")#write mode
        failed_log_file.write(str(e))
        failed_log_file.close()
      
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_sdv_model(datetime_now, "Failed", sdv_model_id)
        return "model generation failed"


def get_transformer_by_dtype(train_df):
    trans_dict = {}
    for col in train_df:
        data_type = train_df[col].dtype.name
        if 'int' in data_type:
            trans_dict[col] = 'integer'
        elif 'float' in data_type:
            trans_dict[col] = 'float'
        elif 'bool' in data_type:
            trans_dict[col] = 'boolean'
        elif 'datetime' in data_type:
            trans_dict[col] = 'datetime'
        elif 'object' in data_type:
            try:
                pd.to_datetime(train_df[col].head(10))
                trans_dict[col] = 'datetime'
            except (ParserError, ValueError, OverflowError):
                # trans_dict[col] = 'categorical'
                pass
        else:
            trans_dict[col] = 'categorical'
    return trans_dict


def handle_uploaded_file(path, file):
    with open(path + file.name, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
        return path + file.name

def check_save_files(request):
    selectedDataFile = request.FILES['selectedDataFile']
   
    file_path= handle_uploaded_file(path='SDV/uploaded_files/', file=selectedDataFile)
    response = {}
    column_list = []
    datatype_list = []
    if file_path.endswith(".csv"):
        file_content = pd.read_csv(file_path)    
    elif file_path.endswith(".json"):
        file_content_df = pd.read_json(file_path)
        file_content = pd.json_normalize(file_content_df.to_dict("records"))
    else:
        raise ValueError("Invalid train file format")

    file_length = len(file_content.index)
    if file_length <=10 :
        return "INVALID_FILE"
    else:
        columns = list(file_content.columns)
        for column in columns:
            column_list.append(column)

        for key,val in dict(file_content.dtypes).items():
            if str(val) == 'object':
                try:
                    pd.to_datetime(file_content[str(key)])
                    datatype_list.append({"columnname": str(key), 'data_type': 'datetime64', 'org_datatype': 'datetime64'})
                except ValueError:
                    datatype_list.append({"columnname": str(key), 'data_type': 'string', 'org_datatype': 'string'})
                    pass
            else:
                datatype_list.append({"columnname": str(key), 'data_type': str(val), 'org_datatype': str(val)})

        response['column_list'] = column_list
        response['datatype_list'] = datatype_list
        response['file_path'] = file_path
        response['file_length'] = len(file_content.index)
        response['file_name'] = selectedDataFile.name
        return response

def unified_datasource_data_download(datasource, data_asset:str):
    # selectedDataFile = request.FILES['selectedDataFile']
    #######################################################
    data = get_data_asset_content(datasource_id=datasource, data_asset=data_asset)
    file_path= os.path.join('SDV/uploaded_files/', data_asset)
    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    if isinstance(data, pd.DataFrame):
        file_path += ".csv"
        data.to_csv(file_path, index=False)

    elif isinstance(data, bytes):
        with open(file_path, "+wb") as f:
            f.write(data)
    else:
        raise TypeError("Invalid data type")
    ######################################################
    response = {}
    column_list = []
    datatype_list = []
    if file_path.endswith(".csv"):
        file_content = pd.read_csv(file_path)    
    elif file_path.endswith(".json"):
        file_content_df = pd.read_json(file_path)
        file_content = pd.json_normalize(file_content_df.to_dict("records"))
    else:
        raise ValueError("Invalid train file format")

    file_length = len(file_content.index)
    if file_length <=10 :
        return "INVALID_FILE"
    else:
        columns = list(file_content.columns)
        for column in columns:
            column_list.append(column)

        for key,val in dict(file_content.dtypes).items():
            if str(val) == 'object':
                try:
                    pd.to_datetime(file_content[str(key)])
                    datatype_list.append({"columnname": str(key), 'data_type': 'datetime64', 'org_datatype': 'datetime64'})
                except ValueError:
                    datatype_list.append({"columnname": str(key), 'data_type': 'string', 'org_datatype': 'string'})
                    pass
            else:
                datatype_list.append({"columnname": str(key), 'data_type': str(val), 'org_datatype': str(val)})

        response['column_list'] = column_list
        response['datatype_list'] = datatype_list
        response['file_path'] = file_path
        response['file_length'] = len(file_content.index)
        response['file_name'] = os.path.basename(file_path)
        return response

###################################################################################################
########################################### MULTI TABLE ###########################################
###################################################################################################

def check_save_files_multi(request):
    selectedDataFile = request.FILES.getlist('selectedDataFile')
    selectedMetaFile = request.FILES['selectedMetaFile']
   
    array_selectedDataFile_path = []
    array_selectedDataFileName = []
    array_selectedDataFileColumns = []
    array_datatype_list = []
    array_file_length = []
  
    meta_file_path = handle_uploaded_file(path='SDV_MULTI/meta_files/', file=selectedMetaFile)
    for file in selectedDataFile:
        file_path = handle_uploaded_file(path='SDV_MULTI/uploaded_files/', file=file)
        if file_path.endswith(".csv"):
            file_content = pd.read_csv(file_path)
        elif file_path.endswith(".json"):
            file_content = pd.read_json(file_path)
        else:
            raise ValueError("Invalid train file format")
        datatype_list = []
        for key,val in dict(file_content.dtypes).items():
            if str(val) == 'object':
                try:
                    pd.to_datetime(file_content[str(key)])
                    datatype_list.append({"columnname": str(key), 'data_type': 'datetime64', 'org_datatype': 'datetime64'})
                except ValueError:
                    datatype_list.append({"columnname": str(key), 'data_type': 'string', 'org_datatype': 'string'})
                    pass
            else:
                datatype_list.append({"columnname": str(key), 'data_type': str(val), 'org_datatype': str(val)})

        array_datatype_list.append(datatype_list)
        array_selectedDataFileName.append(file.name)
        array_selectedDataFileColumns.append(list(file_content.columns))
        array_selectedDataFile_path.append(file_path)
        array_file_length.append(len(file_content.index))

    response = {}

    response['meta_file_path'] = meta_file_path
    response['file_names'] = array_selectedDataFileName
    response['file_paths'] = array_selectedDataFile_path
    response['column_lists'] = array_selectedDataFileColumns
    response['datatype_lists'] = array_datatype_list
    response['file_lengths'] = array_file_length
    return response

def unified_datasource_data_download_multi(datasource_id, data_assets):
    selectedDataFile = data_assets
    selectedMetaFile = StringIO("{}")
   
    array_selectedDataFile_path = []
    array_selectedDataFileName = []
    array_selectedDataFileColumns = []
    array_datatype_list = []
    array_file_length = []
  
    meta_file_path = 'SDV_MULTI/meta_files/metadata.json'
    os.makedirs(os.path.dirname(meta_file_path), exist_ok=True)
    with open(meta_file_path, "w+") as f: f.write("{}")
    
    for file in selectedDataFile:
        #######################################
        data = get_data_asset_content(datasource_id, file)
        file_path = os.path.join('SDV_MULTI/uploaded_files/', file)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        if isinstance(data, pd.DataFrame):
            file_path += ".csv"
            data.to_csv(file_path, index=False)

        elif isinstance(data, bytes):
            with open(file_path, "+wb") as f:
                f.write(data)
        else:
            raise TypeError("Invalid data type")
        ##########################################
        if file_path.endswith(".csv"):
            file_content = pd.read_csv(file_path)
        elif file_path.endswith(".json"):
            file_content = pd.read_json(file_path)
        else:
            raise ValueError("Invalid train file format")
        datatype_list = []
        for key,val in dict(file_content.dtypes).items():
            if str(val) == 'object':
                try:
                    pd.to_datetime(file_content[str(key)])
                    datatype_list.append({"columnname": str(key), 'data_type': 'datetime64', 'org_datatype': 'datetime64'})
                except ValueError:
                    datatype_list.append({"columnname": str(key), 'data_type': 'string', 'org_datatype': 'string'})
                    pass
            else:
                datatype_list.append({"columnname": str(key), 'data_type': str(val), 'org_datatype': str(val)})

        array_datatype_list.append(datatype_list)
        array_selectedDataFileName.append(os.path.basename(file))
        array_selectedDataFileColumns.append(list(file_content.columns))
        array_selectedDataFile_path.append(file_path)
        array_file_length.append(len(file_content.index))

    response = {}

    response['meta_file_path'] = meta_file_path
    response['file_names'] = array_selectedDataFileName
    response['file_paths'] = array_selectedDataFile_path
    response['column_lists'] = array_selectedDataFileColumns
    response['datatype_lists'] = array_datatype_list
    response['file_lengths'] = array_file_length
    return response


def start_multimodel_training(request):
    sdvmodels_util.createtable_multi()

    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']

    modelname = json_req['modelname']
    filepaths = json_req['filepath']
    metapath = json_req['metapath']
    masking_details = json_req['masking_details']
    datatype_details = json_req['datatype_details']

    if len(datatype_details) !=0:
        for file_path in filepaths:
            filename = file_path.rsplit('/', 1)[-1]
            if filename in datatype_details:
                datatype_details = datatype_details[filename]
                update_uploaded_file_datatype_change(file_path, datatype_details)

    if len(masking_details) != 0:
        for file_path in filepaths:
            filename = file_path.rsplit('/', 1)[-1]
            if filename in masking_details:
                masking_columnlist = []
                for column in masking_details[filename].keys():
                    masking_type = masking_details[filename][column]
                    if masking_type != "No Masking Selected":
                        masking_columnlist.append(column)

                if len(masking_columnlist) > 0:
                    update_uploaded_file_as_anonymized(
                        file_path, masking_details[filename])

    rel_train_thread = Thread(target=multi_table_sdv_model_training,
                              args=(filepaths, metapath, modelname,))
    rel_train_thread.start()

    ret = {}
    ret['data'] = "data"
    ret['message'] = "Success"
    return ret


def multi_table_sdv_model_training(array_selectedDataFile_path, meta_file_path, model_name):
    # checking if file format is valid or not
    df_list = {}
    for file_path in array_selectedDataFile_path:
        if file_path.endswith(".csv"):
            train_df = pd.read_csv(file_path)
            # train_df = train_df.head(100)  # trimming training data to reduce time
            name = os.path.basename(file_path)[:-4]
            df_list[name] = train_df
        elif file_path.endswith(".json"):
            train_df = pd.read_json(file_path)
            # train_df = train_df.head(100)  # trimming training data to reduce time
            name = os.path.basename(file_path)[:-5]
            df_list[name] = train_df
        else:
            raise ValueError("Invalid train file format")

    loaded = Metadata(meta_file_path)
    meta_filename = os.path.basename(meta_file_path)
    datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    model_id = sdvmodels_util.insert_sdv_model_multi(datetime_now, meta_filename, model_name + ".pkl", "In-Progress")
    try:
        model = HMA1(loaded)
        model.fit(df_list)
        new_data = model.sample(num_rows=100)
        generated_data = []
        i = 1

        if not os.path.exists(os.getcwd() + "/SDV_MULTI/new_files/"+model_name):
            os.makedirs(os.getcwd() + "/SDV_MULTI/new_files/"+model_name)

        for data in new_data:
            generated_data.append(new_data[data].to_json())
            new_data[data].to_json(os.getcwd(
            ) + "/SDV_MULTI/new_files/"+model_name+"/"+str(data) + ".json")
            i = i + 1

        path_rem = os.path.join(
            os.getcwd() + '/SDV_MULTI/new_files/'+model_name+'.zip')
        if os.path.exists(path_rem):
            os.remove(path_rem)

        make_archive(os.getcwd() + "/SDV_MULTI/new_files/" +
                     model_name, path_rem)

        model.save("SDV_MULTI/sdv_models/" + model_name + ".pkl")
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_sdv_model_multi(
            datetime_now, "Completed", model_id,model_object= cloudpickle.dumps(model))
        return "model saved successfully"
    except Exception as e:
        failed_log_path = os.path.join("SDV_MULTI/failed_log_files",model_name+".txt")
        if os.path.exists(failed_log_path):
            os.remove(failed_log_path)
        failed_log_file = open(failed_log_path,"w")#write mode
        failed_log_file.write(e)
        failed_log_file.close()
       
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_sdv_model_multi(datetime_now, "Failed", model_id)
        return "model training failed"


def make_archive(source, destination):
    base = os.path.basename(destination)
    name = base.split('.')[0]
    format = base.split('.')[1]
    archive_from = os.path.dirname(source)
    archive_to = os.path.basename(source.strip(os.sep))
    shutil.make_archive(name, format, archive_from, archive_to)
    shutil.move('%s.%s' % (name, format), destination)


###################################################################################################
########################################## GENERATE DATA ##########################################
###################################################################################################


def generate_sdv_data(model_path, sel_model_name, num_rows, data_type):
    model_name = sel_model_name.split(".")[0]
    datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    generated_id = sdvmodels_util.insert_synthetic_data_list(
        (model_name, data_type, sel_model_name, num_rows, "In-Progress", datetime_now))
    model_name = sel_model_name.split(".")[0]
    file_name = sdvmodels_util.get_file_name_for_model(sel_model_name)
    file_type = file_name.split('.')[1]
    file_name_woext = file_name.split('.')[0]
    try:
        try:
            loaded = GaussianCopula.load(model_path)
        except:
            model_blob = sdvmodels_util.get_sdv_model_object(sel_model_name)
            loaded = cloudpickle.loads(model_blob)
            
        if num_rows > 500000:
            div_part = num_rows / 500000
            div_part = math.ceil(div_part)
            num, div = num_rows, int(div_part)
            supported_rownum_list = [num // div + (1 if x < num % div else 0) for x in range(div)]
            count = 0
            for num in supported_rownum_list:
                gen_df = loaded.sample(num)
                gen_df.to_csv("SDV/splited_files/" + model_name + "_" + str(num) + "_" + str(count) + ".csv", index=False)
                count = count + 1
            splited_file_path = "SDV/splited_files/"
            all_filenames = glob.glob(os.path.join(splited_file_path, "*.csv"))
            combined_csv = pd.concat([pd.read_csv(f) for f in all_filenames])
            combined_csv.to_csv("SDV/generated_files/" + model_name + "_" +file_name_woext+"_"+ str(num_rows) + ".csv", index=False)
            for f in all_filenames:
                os.remove(f)
        else:
            
            sample_df = loaded.sample(num_rows)
            if file_type == "csv":
                sample_df.to_csv("SDV/generated_files/" + model_name + "_"+file_name_woext+"_" + str(num_rows) + ".csv", index=False)
            elif file_type == "tsv":
                sample_df.to_csv("SDV/generated_files/" + model_name + "_"+file_name_woext+"_" + str(num_rows) + ".tsv", index=False, sep='\t')            
            else:
                sample_df.to_json("SDV/generated_files/" + model_name + "_" +file_name_woext+"_"+ str(num_rows) + ".json", orient="records")
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        with open("SDV/generated_files/" + model_name + "_" +file_name_woext+"_"+ str(num_rows) + ".csv", "rb") as f:
            file_object_binary = f.read()
        sdvmodels_util.update_synthetic_data_list((datetime_now, "Completed", file_object_binary, generated_id))
        return "Data Generated successfully !!"
    except Exception as e:
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_synthetic_data_list((datetime_now, "Failed", None, generated_id))
        return "Data generation failed !!"	
		
def generate_sdv_data_multi(model_path, sel_model_name, num_rows, data_type):
    model_name = sel_model_name.split(".")[0]
    datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    generated_id = sdvmodels_util.insert_synthetic_data_list(
        (model_name, data_type, sel_model_name, num_rows, "In-Progress", datetime_now))
    model_name = sel_model_name.split(".")[0]
    try:
        try:
            loaded = HMA1.load(model_path)
        except:
            model_blob = sdvmodels_util.get_sdv_model_object_multi(sel_model_name)
            loaded = cloudpickle.loads(model_blob)

        sample_df = loaded.sample(num_rows=num_rows)
        relational_data_filespath = 'SDV_MULTI/relational_data_files/'
        shutil.rmtree(relational_data_filespath)

        if not os.path.exists(os.getcwd() +"/SDV_MULTI/relational_data_files/"+model_name+ "_" + str(num_rows)):
            os.makedirs(os.getcwd() +"/SDV_MULTI/relational_data_files/"+model_name+ "_" + str(num_rows))
      
        for df in sample_df:
            sample_df[df].to_csv("SDV_MULTI/relational_data_files/"+model_name + "_" + str(num_rows) +"/"+df+".csv", index=False)
          
        path_rem = os.path.join(os.getcwd() + '/SDV_MULTI/generated_files/' + model_name + "_" + str(num_rows) + ".zip")
        if os.path.exists(path_rem):
            os.remove(path_rem)
        make_archive(os.getcwd() + "/SDV_MULTI/relational_data_files/"+model_name + "_" + str(num_rows), path_rem)
        
        generated_files_zip_binary = b''
        with open(path_rem, "rb") as zip_binary_file:
            generated_files_zip_binary = zip_binary_file.read()

        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_synthetic_data_list((datetime_now, "Completed", generated_files_zip_binary, generated_id))
        return "Data Generated Successfully!"
    except Exception as e:
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_synthetic_data_list((datetime_now, "Failed", None, generated_id))
        return "Data generation failed!"


###################################################################################################
######################################## ANONYMIZE UTILITY ########################################
###################################################################################################

def anonymize_uploaded_data(uploaded_df, masking_details):
    
    mask_type_json = pd.read_json("config/masking_type.json", typ='series')
    for column in masking_details.keys():
        column_name = column
        masking_type = masking_details[column]
        if masking_type != "No Masking Selected":
            masking_value = mask_type_json[masking_type]
            if 'Faker' in masking_value:
                uploaded_df = anonymize_using_faker(uploaded_df, masking_value, column_name)
            else:
                uploaded_df = anonymize_using_regex(uploaded_df, masking_value, column_name)
    return uploaded_df


def anonymize_using_faker(uploaded_df, masking_value, column_name):
    masking_val = masking_value.replace("Faker_", "")
    if column_name in uploaded_df:
        original = uploaded_df[column_name].tolist()
        duplicate = []
        temp = {}
        for val in original:
            if val not in temp:
                temp[val] = getattr(fake, masking_val)()
        for val in original:
            duplicate.append(temp[val])
        uploaded_df[column_name] = duplicate
    return uploaded_df


def anonymize_using_regex(uploaded_df, masking_value, column_name):
    if column_name in uploaded_df:
        original = uploaded_df[column_name].tolist()
        duplicate = []
        temp = {}
        for val in original:
            if val not in temp:
                temp[val] = re.sub(masking_value, "*", str(val))
        for val in original:
            duplicate.append(temp[val])
        uploaded_df[column_name] = duplicate
    return uploaded_df


def update_uploaded_file_as_anonymized(file_path, masking_details):
    if file_path.endswith(".csv"):
        uploaded_df = pd.read_csv(file_path)
    elif file_path.endswith(".json"):
        uploaded_df = pd.read_json(file_path)
    else:
        raise ValueError("Invalid train file format")
    anonymized_df = anonymize_uploaded_data(uploaded_df, masking_details)
    anonymized_df.to_csv(file_path, header=True, index=False)


def update_uploaded_json_file_as_anonymized(file_path, masking_details):
    uploaded_df = pd.read_json(file_path)
    anonymized_df = anonymize_uploaded_data(uploaded_df, masking_details)
    anonymized_df.to_json(file_path)

def update_uploaded_file_datatype_change(file_path, datatype_details):
    if file_path.endswith(".csv"):
        uploaded_df = pd.read_csv(file_path)
        updated_df = uploaded_df.astype(datatype_details, errors='ignore')
        updated_df.to_csv(file_path, header=True, index=False)
    elif file_path.endswith(".json"):
        uploaded_df = pd.read_json(file_path)
        updated_df = uploaded_df.astype(datatype_details, errors='ignore')
        updated_df.to_json(file_path)
    else:
        raise ValueError("Invalid train file format")


def create_constraints(columnFormulas):
    # create dynamic scripts - started from here
    constraints_value = '\tconstraints = ['
    column_formula_value = ''
    column_formula_calc_value = ''
    import_value = '\tfrom sdv.constraints import ColumnFormula \n'
    import_value += '\tfrom sdv.constraints import Unique \n'
    import_value += '\timport pandas as pd \n'
    import_value += '\tfrom datetime import datetime \n\n'
    final_constraints_code = ''
    if len(columnFormulas) == 0:
        constraints_value += ']'
    else:
        if len(columnFormulas) != 0:
            for i in range(len(columnFormulas)):
                final_columnName = columnFormulas[i]['columnName'].replace(" ","_")
                constraints_value += final_columnName + '_constraints,'

                column_formula_value += '\t' + final_columnName + '_constraints = ColumnFormula(column =\'' + \
                                        columnFormulas[i][
                                            'columnName'] + '\', formula = ' + final_columnName + '_constraints_ColumnFormula, handling_strategy = \'transform\')'
                column_formula_value += '\n\n'

                final_formula = columnFormulas[i]['Formula']
                column_formula_calc_value += '\tdef ' + final_columnName + '_constraints_ColumnFormula(data):'
                column_formula_calc_value += '\n\t\t return ' + final_formula
                column_formula_calc_value += '\n\n'

        if constraints_value.endswith(','):
            constraints_value = constraints_value.rstrip(constraints_value[-1])
            constraints_value += ']'
        else:
            constraints_value += ']'

    # create Final Constraints scripts - started from here
    final_constraints_code += 'def return_constraints():\n'
    final_constraints_code += import_value + '\n'
    final_constraints_code += column_formula_calc_value + '\n'
    final_constraints_code += column_formula_value + '\n'
    final_constraints_code += constraints_value + '\n'
    final_constraints_code += '\treturn constraints \n'
    final_constraints_code += 'return_constraints()'
    # create Final Constraints scripts - Ended from here

    # write dynamic scripts into output.py
    f = open(os.path.join(sdv_path, 'constraints_data.txt'), 'w')
    f.write(final_constraints_code)
    f.close()


def generate_sdv_single_data(model_path, sel_model_name, num_rows, base_ur):
    model_name = sel_model_name.split(".")[0]
    model_name = sel_model_name.split(".")[0]
    file_name = sdvmodels_util.get_file_name_for_model(sel_model_name)
    file_type = file_name.split('.')[1]
    file_name_woext = file_name.split('.')[0]
    if not os.path.exists(os.getcwd() +"/xenius_ui/static/sdv_api/SDV/generated_files"):
        os.makedirs(os.getcwd() +"/xenius_ui/static/sdv_api/SDV/generated_files")
        
    try:
        loaded = GaussianCopula.load(model_path)
        sample_df = loaded.sample(num_rows)
        
        if file_type == "csv":
            sample_df.to_csv("xenius_ui/static/sdv_api/SDV/generated_files/" + model_name + "_"+file_name_woext+"_" + str(num_rows) + ".csv", index=False)
        elif file_type == "tsv":
            sample_df.to_csv("xenius_ui/static/sdv_api/SDV/generated_files/" + model_name + "_"+file_name_woext+"_" + str(num_rows) + ".tsv", index=False, sep='\t')            
        else:
            sample_df.to_json("xenius_ui/static/SDV/generated_files/" + model_name + "_" +file_name_woext+"_"+ str(num_rows) + ".json", orient="records")
        result = base_ur+"/static/sdv_api/SDV/generated_files/" + model_name + "_" +file_name_woext+"_"+ str(num_rows)+"."+file_type
        response = {'Status':'Success','Message':'Data Generated successfully !!','Result':result}
        return response
    except Exception as e:
        response = {'Status':'Failed','Message':'Data generation failed !!','Result':''}
        return response	
		
def generate_sdv_multi_data(model_path, sel_model_name, num_rows, base_ur):
    model_name = sel_model_name.split(".")[0]
    
    
    model_name = sel_model_name.split(".")[0]
    if not os.path.exists(os.getcwd() +"/xenius_ui/static/sdv_api/SDV_MULTI/relational_data_files"):
        os.makedirs(os.getcwd() +"/xenius_ui/static/sdv_api/SDV_MULTI/relational_data_files")
        os.makedirs(os.getcwd() +"/xenius_ui/static/sdv_api/SDV_MULTI/generated_files")
    
    try:
        loaded = HMA1.load(model_path)
        sample_df = loaded.sample(num_rows=num_rows)
        relational_data_filespath = 'xenius_ui/static/sdv_api/SDV_MULTI/relational_data_files/'
        shutil.rmtree(relational_data_filespath)

        if not os.path.exists(os.getcwd() +"/xenius_ui/static/sdv_api/SDV_MULTI/relational_data_files/"+model_name+ "_" + str(num_rows)):
            os.makedirs(os.getcwd() +"/xenius_ui/static/sdv_api/SDV_MULTI/relational_data_files/"+model_name+ "_" + str(num_rows))
      
        for df in sample_df:
            sample_df[df].to_csv("xenius_ui/static/sdv_api/SDV_MULTI/relational_data_files/"+model_name + "_" + str(num_rows) +"/"+df+"_"+str(num_rows)+ ".csv", index=False)
        path_rem = os.path.join(os.getcwd() + '/xenius_ui/static/sdv_api/SDV_MULTI/generated_files/' + model_name + "_" + str(num_rows) + ".zip")
        
        make_archive(os.getcwd() + "/xenius_ui/static/sdv_api/SDV_MULTI/relational_data_files/"+model_name + "_" + str(num_rows), path_rem)
        result = base_ur+'/static/sdv_api/SDV_MULTI/generated_files/' + model_name + "_" + str(num_rows) + ".zip"
        response = {'Status':'Success','Message':'Data Generated successfully !!','Result':result}
        return response
        
    except Exception as e:
        print(e)
        response = {'Status':'Success','Message':'Data generation failed!','Result':''}
        return response
       
def start_differntial_training(request):
    sdvmodels_util.createtable()
    req_body = request.body.decode('utf-8')
    
    json_req = json.loads(req_body)['params']
    modelname = json_req['modelname']
    algorithm = json_req['algorithm']
    batchsize = json_req['batchsize']
    epoch = json_req['epoch']
    epsilon = float(json_req['epsilon'])
    preprocessor_eps  = epsilon/2 # prepocessor budget 50 % of epsilon
    filepath = json_req['filepath']
    masking_details = json_req['masking_details']
    # constraints_details = json_req['constraints_details']
    datatype_details = json_req['datatype_details']

    filename = filepath.rsplit('/', 1)[-1]
    
    if len(datatype_details) !=0:
        datatype_details = datatype_details[filename]
        update_uploaded_file_datatype_change(filepath, datatype_details)

    # create_constraints(constraints_details)
    if len(masking_details) !=0:
        masking_columnlist = []
        masking_details = masking_details[filename]
        for column in masking_details.keys():
            masking_type = masking_details[column]
            if masking_type != "No Masking Selected":
                masking_columnlist.append(column)

        if len(masking_columnlist) > 0:
            update_uploaded_file_as_anonymized(filepath, masking_details)

    model_type_json = pd.read_json(modeltypesjsonpath, typ='series')
    model_type = model_type_json[algorithm]
    train_thread = Thread(target=differntial_training_single_table_sdv_model_training,
                          args=(filepath, modelname, model_type, batchsize, epoch,  epsilon, preprocessor_eps))
    train_thread.start()
    ret = {}
    ret['data'] = "data"
    ret['message'] = "Success"
    return ret

def differntial_training_single_table_sdv_model_training(file_path, model_name, model_type, batch_size, epoch_size,epsilon, preprocessor_eps):
    # checking if file format is valid or not
    if file_path.endswith(".csv"):
        train_df = pd.read_csv(file_path)
    elif file_path.endswith(".json"):
        train_df = pd.read_json(file_path)
        train_df = pd.json_normalize(train_df.to_dict("records"))
    elif file_path.endswith(".tsv"):
        train_df = pd.read_table(file_path)
    else:
        raise ValueError("Invalid train file format")

    train_file = os.path.basename(file_path)

    # train_df = train_df.head(100)  # trimming training data to reduce time
    datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    differential_private = 1
    if model_type == 'GaussianCopula' or model_type == 'CopulaGAN' or model_type == 'TVAE' or model_type == 'CTGAN':
        differential_private = 0
    sdv_model_id = sdvmodels_util.insert_differntiate_sdv_model(datetime_now, train_file, model_name + ".pkl", "In-Progress", differential_private)
    try:
        field_trans_dict = get_transformer_by_dtype(train_df)
        exec(open(os.path.join(sdv_path, 'constraints_data.txt')).read())
        constraints = eval('return_constraints()')
        log = open(os.path.join(logfile_path, model_name+".txt"), "w")
        stdout = sys.stdout
        sys.stdout = log
       
        if model_type == 'GaussianCopula':
          
                model = GaussianCopula(field_transformers=field_trans_dict, constraints=constraints)
        elif model_type == 'CopulaGAN':
           
                model = CopulaGAN(field_transformers=field_trans_dict, cuda=True,
                              verbose=True, batch_size=int(batch_size), epochs=int(epoch_size), constraints=constraints)
        elif model_type == 'TVAE':
            
                model = TVAE(field_transformers=field_trans_dict, epochs=int(epoch_size), batch_size=int(batch_size),
                         constraints=constraints)
        elif model_type == 'CTGAN':
            
                model = CTGAN(verbose=True, cuda=False, batch_size=int(batch_size), epochs=int(epoch_size),
                          field_transformers=field_trans_dict, constraints=constraints)
        # Differential Privacy Algorithms Code Start
        elif model_type == 'MST' or  model_type == 'PAC-Synth':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, epsilon=epsilon, verbose=True)
        elif model_type == 'MWEM':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, epsilon=epsilon, verbose=True)
        elif model_type == "DP-CTGAN" or model_type == 'PATE-CTGAN':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, 
                epsilon= epsilon,
                batch_size=int(batch_size), epochs=int(epoch_size),
                verbose=True)
        elif model_type == 'PATE-GAN':
            finalModelType = model_type.replace("-","").lower()
            model = Synthesizer.create(finalModelType, epsilon=epsilon, batch_size=int(batch_size))
        
        else:
           
                model = CTGAN(verbose=True, cuda=False, batch_size=int(batch_size), epochs=int(epoch_size),
                          field_transformers=field_trans_dict, constraints=constraints)

        if model_type == 'GaussianCopula' or model_type == 'CopulaGAN' or model_type == 'TVAE' or model_type == 'CTGAN':
            model.fit(train_df)
        elif model_type == 'MWEM':
            train_df = train_df.drop(['income', 'age'], axis=1)
            model.fit_sample(train_df, preprocessor_eps=preprocessor_eps)
       
        else:
            model.fit(train_df, preprocessor_eps=preprocessor_eps)
        log.close()
        sys.stdout = stdout

        sample_df = model.sample(100)
        sample_df.to_csv("SDV/new_files/"+model_name +
                            "_" + train_file, index=False)
      
        with open("SDV/sdv_models/" + model_name + ".pkl", 'wb') as f:
            cloudpickle.dump(model, f)
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_sdv_model(datetime_now, "Completed", sdv_model_id, model_object=cloudpickle.dumps(model))
        return "model saved successfully"
       
    except Exception as e:
        failed_log_path = os.path.join("SDV/failed_log_files",model_name+".txt")
        if os.path.exists(failed_log_path):
            os.remove(failed_log_path)
        failed_log_file = open(failed_log_path,"w")#write mode
        failed_log_file.write(str(e))
        failed_log_file.close()
      
        datetime_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sdvmodels_util.update_sdv_model(datetime_now, "Failed", sdv_model_id)
        return "model generation failed"