
# Test Script for MED_IS_REQ06

# Open the operational software
Start-Process -FilePath "C:\Program Files\OperationalSoftware\OperationalSoftware.exe"

# Send 'Y' key and press enter
[System.Windows.Forms.SendKeys]::SendWait('Y{ENTER}')

# Check if the confirmation text is displayed
$confirmationText = Get-Content -Path "C:\Program Files\OperationalSoftware\Confirmation.txt"
if ($confirmationText -eq "Please 'Enter' to confirm") {
    Write-Host "Test Passed: Confirmation text is displayed"
} else {
    Write-Host "Test Failed: Confirmation text is not displayed"
}

# Close the operational software
Stop-Process -Name "OperationalSoftware"

