
# Test Script for Requirement MED_IS_REQ01

# Launch the operational instrument software
Start-Process -FilePath "operational_instrument_software.exe"

# Wait for the software to start
Start-Sleep -Seconds 5

# Get the text displayed at the top right location of the screen
$displayedText = Get-Text -Location "topRight"

# Check if the displayed text is "Main"
if ($displayedText -eq "Main") {
    Write-Host "Test Passed: The operational instrument software displayed the text 'Main' at the top right location of the screen."
} else {
    Write-Host "Test Failed: The operational instrument software did not display the text 'Main' at the top right location of the screen."
}
