
# Test Script for Requirement MED_IS_REQ04

# Launch the operational software
Start-Process -FilePath "C:\Program Files\OperationalSoftware\OperationalSoftware.exe"

# Wait for the software to launch
Start-Sleep -Seconds 5

# Simulate pressing the enter key
[System.Windows.Forms.SendKeys]::SendWait("{ENTER}")

# Wait for the software to display the message
Start-Sleep -Seconds 2

# Get the text displayed on the screen
$displayText = Get-TextDisplayedOnScreen -X 500 -Y 500 -Width 500 -Height 50

# Verify if the displayed text is "Please enter serial number"
Assert-Equals -Expected "Please enter serial number" -Actual $displayText

# Close the operational software
Stop-Process -Name "OperationalSoftware"

# Test Pass
Write-Host "Test Passed: The operational software displayed 'Please enter serial number' on pressing the enter key."

# Test Fail
# Write-Host "Test Failed: The operational software did not display 'Please enter serial number' on pressing the enter key."
