
# Test Script for Requirement MED_IS_REQ03

# Import necessary modules
Import-Module Pester

# Define the function to test the button press
Function Test-ButtonPress {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$buttonPressed
    )

    # Simulate button press
    $buttonPressed = "F4"

    # Check if the prompt is displayed
    $promptDisplayed = $false
    if ($buttonPressed -eq "F4") {
        $promptDisplayed = $true
    }

    # Assert that the prompt is displayed
    $promptDisplayed | Should Be $true
}

# Describe the test case
Describe "Test Button Press for MED_IS_REQ03" {
    Context "When F4 button is pressed" {
        It "Should display the prompt 'Save configuration and reset'" {
            Test-ButtonPress -buttonPressed "F4"
        }
    }
}

# Run the test
Invoke-Pester -OutputFormat NUnitXml -OutputFile TestResults.xml

# Check if the test passed or failed
$testResults = [xml](Get-Content TestResults.xml)
$testResult = $testResults.'test-results'.result
if ($testResult -eq "Failed") {
    Write-Host "Test Failed"
} else {
    Write-Host "Test Passed"
}
