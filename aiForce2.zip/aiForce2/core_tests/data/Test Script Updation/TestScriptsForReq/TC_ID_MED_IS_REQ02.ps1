
# Test Script for MED_IS_REQ02

# Open the device and wait for it to start
# Press the right arrow four times to reach the boot menu
# Check if the quiet boot is enabled at the screen location 100,50

# Open the device and wait for it to start
Start-Device

# Press the right arrow four times to reach the boot menu
Press-RightArrow -Count 4

# Check if the quiet boot is enabled at the screen location 100,50
$quietBootEnabled = Get-ScreenLocation -X 100 -Y 50
Assert-Equal -Actual $quietBootEnabled -Expected "Enabled"

# Reporting
if ($quietBootEnabled -eq "Enabled") {
    Write-Host "Test Pass"
} else {
    Write-Host "Test Fail"
}
