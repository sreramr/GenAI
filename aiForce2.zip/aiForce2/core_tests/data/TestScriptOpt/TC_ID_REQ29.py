
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.implicitly_wait(10)

# Test Elixir Integration
def test_elixir_integration():
    # Navigate to Xenius landing page
    driver.get("https://www.xenius.com/")
    # Click on Elixir box
    elixir_box = driver.find_element_by_css_selector "#elixir-box"
    elixir_box.click()
    # Wait for Elixir landing page to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "#elixir-landing-page")))
    # Verify landing page heading and text
    landing_page_heading = driver.find_element_by_css_selector "#landing-page-heading"
    landing_page_text = driver.find_element_by_css_selector "#landing-page-text"
    assert landing_page_heading.text == "Elixir Integration in Xenius"
    assert landing_page_text.text == "Unstructured Data Parsing"
    # Click on Get Started button
    get_started_button = driver.find_element_by_css_selector "#get-started-button"
    get_started_button.click()
    # Wait for Elixir to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "#elixir-landing-page")))
    # Verify Elixir landing page heading and text
    elixir_landing_page_heading = driver.find_element_by_css_selector "#elixir-landing-page-heading"
    elixir_landing_page_text = driver.find_element_by_css_selector "#elixir-landing-page-text"
    assert elixir_landing_page_heading.text == "Elixir Integration in Xenius"
    assert elixir_landing_page_text.text == "Unstructured Data Parsing"
    # Close Elixir
    driver.find_element_by_css_selector "#close-elixir-button").click()

# Test Training Task
def test_training_task():
    # Navigate to Training Task page
    driver.get("https://www.xenius.com/training-task/")
    # Click on Create Task button
    create_task_button = driver.find_element_by_css_selector "#create-task-button"
    create_task_button.click()
    # Wait for wizard to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "#wizard-container")))
    # Complete wizard
    wizard = driver.find_element_by_css_selector "#wizard"
    wizard.find_element_by_css_selector "#step1").click()
    wizard.find_element_by_css_selector "#step2").click()
    wizard.find_element_by_css_selector "#step3").click()
    # Verify Training Task page
    training_task_page = driver.find_element_by_css_selector "#training-task-page"
    assert training_task_page.text == "Training Task"
    # Close Training Task
    driver.find_element_by_css_selector "#close-task-button").click()

# Test Data Task
def test_data_task():
    # Navigate to Data Task page
    driver.get("https://www.xenius.com/data-task/")
    # Click on Create Task button
    create_task_button = driver.find_element_by_css_selector "#create-task-button"
    create_task_button.click()
    # Wait for wizard to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "#wizard-container")))
    # Complete wizard
    wizard = driver.find_element_by_css_selector "#wizard"
    wizard.find_element_by_css_selector "#step1").click()
    wizard.find_element_by_css_selector "#step2").click()
    wizard.find_element_by_css_selector "#step3").click()
    # Verify Data Task page
    data_task_page = driver.find_element_by_css_selector "#data-task-page"
    assert data_task_page.text == "Data Task"
    # Close Data Task
    driver.find_element_by_css_selector "#close-task-button").click()

# Summary
passed = True
assert passed
