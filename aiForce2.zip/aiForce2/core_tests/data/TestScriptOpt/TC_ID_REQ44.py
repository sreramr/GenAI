
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/user-management")

# Test 1: User Table
def test_user_table():
    # Click on the new L0 menu
    menu = driver.find_element_by_link_text("Settings and Generated Datasets")
    menu.click()
    # Wait for the user table to load
    wait = WebDriverWait(driver, 10)
    user_table = wait.until(EC.presence_of_table_containing_elements(By.CSS_SELECTOR, ".user-table"))
    # Verify table contents
    assert len(user_table.find_elements_by_tag_name("tr")) > 0
    assert user_table.find_element_by_tag_name("th").text == "S.No"
    assert user_table.find_element_by_tag_name("th").text == "User Name"
    assert user_table.find_element_by_tag_name("th").text == "Email ID"
    assert user_table.find_element_by_tag_name("th").text == "User Metadata"

# Test 2: User Details Popup
def test_user_details_popup():
    # Click on a user in the table
    user = user_table.find_element_by_css_selector(".user-table > tr > td:nth-child(1) > a")
    user.click()
    # Wait for the user details popup to load
    wait = WebDriverWait(driver, 10)
    popup = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".user-popup")))
    # Verify popup contents
    assert popup.find_element_by_tag_name("h2").text == "User Details"
    assert popup.find_element_by_tag_name("table").find_element_by_tag_name("tr").text == "Number of Rules on DQC"
    assert popup.find_element_by_tag_name("table").find_element_by_tag_name("tr").text == "Number of Objects in Semantic Data Layer"
    assert popup.find_element_by_tag_name("table").find_element_by_tag_name("tr").text == "SDG Models Trained"

# Test 3: Add User Button
def test_add_user_button():
    # Click on the Add User button
    add_user_button = driver.find_element_by_link_text("Add User")
    add_user_button.click()
    # Wait for the user details popup to load
    wait = WebDriverWait(driver, 10)
    popup = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".user-popup")))
    # Verify popup contents
    assert popup.find_element_by_tag_name("h2").text == "User Details"
    assert popup.find_element_by_tag_name("table").find_element_by_tag_name("tr").text == "Number of Rules on DQC"
    assert popup.find_element_by_tag_name("table").find_element_by_tag_name("tr").text == "Number of Objects in Semantic Data Layer"
    assert popup.find_element_by_tag_name("table").find_element_by_tag_name("tr").text == "SDG Models Trained"

# Test 4: User Save and Redirect
def test_user_save_and_redirect():
    # Fill out user details form and submit
    user_form = driver.find_element_by_css_selector(".user-form")
    user_form.find_element_by_name("user_name").send_keys("Test User")
    user_form.find_element_by_name("email_id").send_keys("test@example.com")
    user_form.find_element_by_name("password").send_keys("password123")
    user_form.find_element_by_name("key").send_keys("1234567890")
    user_form.submit()
    # Wait for the user to be redirected to the user management landing page
    wait = WebDriverWait(driver, 10)
    assert driver.current_url == "https://www.xenius.com/user-management"

# Summary
The test script covers the following functionalities:

* Verifying the user table contents
* Opening the user details popup and verifying its contents
* Clicking on the Add User button and verifying the user details popup contents
* Filling out the user details form and submitting it
* Verifying the user is redirected to the user management landing page after submission

The test script passes.
