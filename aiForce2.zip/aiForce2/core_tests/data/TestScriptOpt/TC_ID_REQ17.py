
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up the test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/login")

# Click on the New User link
new_user_link = driver.find_element_by(By.XPATH, "//a[contains(text(), 'New User')]")
new_user_link.click()

# Verify the pop-up form appears
pop_up_form = driver.find_element_by(By.XPATH, "//div[contains(text(), 'New User')]")
assert pop_up_form.is_displayed, "Pop-up form did not appear"

# Fill in the form fields
username_input = pop_up_form.find_element_by(By.XPATH, "//input[@name='username']")
username_input.send_keys("test_username")

email_input = pop_up_form.find_element_by(By.XPATH, "//input[@name='email']")
email_input.send_keys("test_email@example.com")

password_input = pop_up_form.find_element_by(By.XPATH, "//input[@name='password']")
password_input.send_keys("test_password")

# Submit the form
pop_up_form.find_element_by(By.XPATH, "//button[contains(text(), 'Create Account')]").click()

# Verify the success message appears
success_message = driver.find_element_by(By.XPATH, "//div[contains(text(), 'Account created successfully')]")
assert success_message.is_displayed, "Success message did not appear"

# Refresh the page and log in
driver.get("https://www.xenius.com/login")
driver.find_element_by(By.XPATH, "//button[contains(text(), 'Log in')]").click()

# Verify the user is logged in
driver.find_element_by(By.XPATH, "//div[contains(text(), 'Logged in as test_username')]").is_displayed
