
import pytest
from appium import webdriver
from appium.webdriver.common.touch_action import tap
from appium.webdriver.common.wait import wait

# Set up the test environment
driver = webdriver.Remote('http://localhost:4723/wd/hub')
driver.implicitly_wait(10) # Wait for the page to load

# Navigate to the Data Source menu
driver.find_element_by_link_text('Data Source').click()
driver.implicitly_wait(10) # Wait for the page to load

# Verify the menu is displayed
assert driver.find_element_by_link_text('Data Source').is_enabled()

# Click on the Data Source menu
driver.find_element_by_link_text('Data Source').click()
driver.implicitly_wait(10) # Wait for the page to load

# Verify the landing page is displayed
assert driver.current_url == '/datasource'

# Verify the table of existing data sources is displayed
table = driver.find_element_by_css_selector '#data-source-table'
assert table.is_enabled()

# Verify the table has the correct columns
assert table.find_element_by_css_selector('th').text == 'S.No'
assert table.find_element_by_css_selector('th').text == 'Data source Name'
assert table.find_element_by_css_selector('th').text == 'Data source Type'

# Verify the delete button is displayed
delete_button = driver.find_element_by_css_selector('#delete-button')
assert delete_button.is_enabled()

# Verify the test connection button is displayed
test_connection_button = driver.find_element_by_css_selector('#test-connection-button')
assert test_connection_button.is_enabled()

# Test the delete button
driver.find_element_by_css_selector('#delete-button').click()
driver.implicitly_wait(10) # Wait for the delete confirmation dialog to appear
assert driver.find_element_by_css_selector('#delete-confirmation-dialog').is_enabled()

# Test the test connection button
driver.find_element_by_css_selector('#test-connection-button').click()
driver.implicitly_wait(10) # Wait for the test connection confirmation dialog to appear
assert driver.find_element_by_css_selector('#test-connection-confirmation-dialog').is_enabled()

# Close the test
driver.quit()
