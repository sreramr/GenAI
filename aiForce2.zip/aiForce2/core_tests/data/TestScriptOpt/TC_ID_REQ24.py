
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/model-tuning-wizard/")

# Click on Basic Configuration radio button
basic_configuration_button = driver.find_element(By.XPATH, "//button[contains(text(), 'Basic Configuration')]")
basic_configuration_button.click()

# Verify that Basic Configuration is selected
assert driver.find_element(By.XPATH, "//label[contains(text(), 'Basic Configuration')]").is_selected()

# Enter model name and algorithm drop-down values
model_name_input = driver.find_element(By.XPATH, "//input[contains(text(), 'Model Name')]")
model_name_input.send_keys("My Model")

algorithm_drop_down = driver.find_element(By.XPATH, "//select[contains(text(), 'Algorithm')]")
algorithm_drop_down.select_by_value("CTGAN - High Fidelity Synthetic Data")

# Verify that Basic Configuration values are displayed
assert driver.find_element(By.XPATH, "//h2[contains(text(), 'Basic Configuration')]").text == "My Model - CTGAN - High Fidelity Synthetic Data"

# Click on Advanced Configuration radio button
advanced_configuration_button = driver.find_element(By.XPATH, "//button[contains(text(), 'Advanced Configuration')]")
advanced_configuration_button.click()

# Verify that Advanced Configuration is selected
assert driver.find_element(By.XPATH, "//label[contains(text(), 'Advanced Configuration')]").is_selected()

# Enter batch size, epoch, and privacy budget values
batch_size_input = driver.find_element(By.XPATH, "//input[contains(text(), 'Batch Size')]")
batch_size_input.send_keys("100")

epoch_input = driver.find_element(By.XPATH, "//input[contains(text(), 'Epoch')]")
epoch_input.send_keys("10")

privacy_budget_input = driver.find_element(By.XPATH, "//input[contains(text(), 'Privacy Budget')]")
privacy_budget_input.send_keys("10")

# Verify that Advanced Configuration values are displayed
assert driver.find_element(By.XPATH, "//h2[contains(text(), 'Advanced Configuration')]").text == "My Model - CTGAN - High Fidelity Synthetic Data - Batch Size: 100 - Epoch: 10 - Privacy Budget: 10"

# Close test environment
driver.quit()
