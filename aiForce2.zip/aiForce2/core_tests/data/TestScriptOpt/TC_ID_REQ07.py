
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("http://localhost/xenius/")

# Click on Data source L0 menu
driver.find_element_by(By.XPATH, "//a[contains(text(), 'Data Source L0')]").click()

# Select Local File data source type
driver.find_element_by(By.XPATH, "//select[@name='dataSourceType']").send_keys("Local File")

# Click on Add Data Source button
driver.find_element_by(By.XPATH, "//button[contains(text(), 'Add Data Source')]").click()

# Wait for pop-up to appear
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//div[contains(text(), 'Add Data Source')]")))

# Select Local File option in pop-up
driver.find_element_by(By.XPATH, "//select[@name='dataSourceType']").send_keys("Local File")

# Click on Browse button
driver.find_element_by(By.XPATH, "//button[contains(text(), 'Browse')]").click()

# Wait for file selection dialog to appear
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//div[contains(text(), 'Select File')]")))

# Select multiple files
driver.find_element_by(By.XPATH, "//input[@name='dataSourceFiles']").send_keys("C:\\Path\\To\\File1.xlsx")
driver.find_element_by(By.XPATH, "//input[@name='dataSourceFiles']").send_keys("C:\\Path\\To\\File2.csv")

# Click on Add button
driver.find_element_by(By.XPATH, "//button[contains(text(), 'Add')]").click()

# Wait for pop-up to disappear
WebDriverWait(driver, 10).until(EC.invisibility_of_element_located((By.XPATH, "//div[contains(text(), 'Add Data Source')]")))

# Close test environment
driver.quit()
