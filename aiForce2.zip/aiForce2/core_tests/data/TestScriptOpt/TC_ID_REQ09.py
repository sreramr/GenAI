
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/")

# Navigate to Data Source menu
driver.find_element_by(By.LinkText,"Data Source").click()
driver.find_element_by(By.LinkText,"L0").click()

# Select Database option
driver.find_element_by(By.Dropdown, "data_source_type").select_by_value("Database")

# Wait for database list to appear
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR,"div.database_list")))

# Select MSSQL Database from list
driver.find_element_by(By.ClassName,"database_item").click()

# Enter MSSQL Database password
driver.find_element_by(By.Name,"password").send_keys("my_mssql_password")

# Verify password field anonymization
assert driver.find_element_by(By.Name,"password").get_attribute("value") == "****"

# Close test environment
driver.quit()
