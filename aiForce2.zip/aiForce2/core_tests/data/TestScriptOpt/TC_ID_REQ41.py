
import pytest
from pytest import mark
from app.apis.dataservices import get_dataservices
from app.apis.getmetadata import get_metadata
from app.apis.getdata import get_data

@pytest.fixture(scope='function')
def client():
    client = pytest.FixtureClient()
    return client

@pytest.mark.usefixtures('client')
def test_dataservices(client):
    response = client.get('/dataservices')
    assert response.status_code == 200
    assert response.json['dataservices']

@pytest.mark.usefixtures('client')
def test_getmetadata(client):
    response = client.get('/getmetadata', params={'userid': 'xx-xx', 'dataserviceid': 'xx'})
    assert response.status_code == 200
    assert response.json['metadata']

@pytest.mark.usefixtures('client')
def test_getdata(client):
    response = client.get('/getdata', params={'userid': 'xx-xx', 'dataserviceid': 'xx', 'metadataid': 'xx'})
    assert response.status_code == 200
    assert response.json['dataset']

@pytest.mark.usefixtures('client')
def test_publish_dataset(client):
    response = client.post('/dataservices', json={'dataservice': {'name': 'My Dataset'}})
    assert response.status_code == 201
    assert response.json['dataservice']['id']

@pytest.mark.usefixtures('client')
def test_parse_regex(client):
    response = client.post('/getmetadata', params={'userid': 'xx-xx', 'dataserviceid': 'xx'})
    assert response.status_code == 200
    assert response.json['metadata']
