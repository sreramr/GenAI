
import pytest
from app.ui.wizard import Wizard
from app.ui.react_flow import ReactFlow
from app.ui.metadata import Metadata

@pytest.fixture
def setup_wizard():
    wizard = Wizard()
    wizard.add_step(SchemaStep())
    wizard.add_step(MetadataDetailsStep())
    wizard.add_step(DataPreviewStep())
    return wizard

@pytest.fixture
def setup_react_flow():
    react_flow = ReactFlow()
    react_flow.add_table(Table1())
    react_flow.add_table(Table2())
    react_flow.add_table(Table3())
    return react_flow

def test_metadata_ui_enhancement(setup_wizard, setup_react_flow):
    # Test 1: Remove input metadata file input box in first step
    wizard = setup_wizard
    wizard.run()
    assert wizard.current_step == SchemaStep

    # Test 2: Add new third step for Metadata Details
    wizard = setup_wizard
    wizard.add_step(MetadataDetailsStep())
    wizard.run()
    assert wizard.current_step == MetadataDetailsStep

    # Test 3: Define metadata between tables in Metadata Details step
    react_flow = setup_react_flow
    react_flow.add_table(Table1())
    react_flow.add_table(Table2())
    react_flow.add_table(Table3())
    react_flow.set_metadata(Table1, Table2, "primary_key")
    react_flow.set_metadata(Table2, Table3, "foreign_key")

    # Test 4: Link primary key from one table to foreign key in another table
    react_flow.link_tables(Table1, Table2)
    react_flow.link_tables(Table2, Table3)

    # Test 5: Upload metadata file and verify changes in UI
    react_flow = setup_react_flow
    react_flow.upload_metadata_file("metadata.json")
    assert react_flow.get_metadata_file() == "metadata.json"

    # Test 6: Verify changes in UI after uploading metadata file
    react_flow = setup_react_flow
    react_flow.run()
    assert react_flow.get_metadata_ui() == "metadata_ui.html"

    # Test 7: Verify that user can navigate between steps
    wizard = setup_wizard
    wizard.run()
    assert wizard.current_step == DataPreviewStep

    # Test 8: Verify that user can save and load metadata
    react_flow = setup_react_flow
    react_flow.save_metadata()
    assert react_flow.get_metadata_file() != ""
    react_flow.load_metadata()
    assert react_flow.get_metadata_file() == ""

    # Test 9: Verify that user can delete metadata
    react_flow = setup_react_flow
    react_flow.delete_metadata()
    assert react_flow.get_metadata_file() == ""

    # Test 10: Verify that user can upload new metadata
    react_flow = setup_react_flow
    react_flow.upload_metadata_file("new_metadata.json")
    assert react_flow.get_metadata_file() == "new_metadata.json"
