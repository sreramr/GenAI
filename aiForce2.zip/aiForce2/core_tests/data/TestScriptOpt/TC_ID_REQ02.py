
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/login")

# Click on New User link
new_user_link = driver.find_element_by(By.XPATH, "//a[contains(text(), 'New User')]")
new_user_link.click()

# Verify pop-up form appears
pop_up_form = driver.find_element_by(By.XPATH, "//div[contains(text(), 'New User')]")
assert pop_up_form.is_displayed, "Pop-up form did not appear"

# Fill in form fields and submit
pop_up_form.find_element_by(By.NAME, "name").send_keys("John Doe")
pop_up_form.find_element_by(By.NAME, "email").send_keys("johndoe@example.com")
pop_up_form.find_element_by(By.NAME, "password").send_keys("password123")
pop_up_form.find_element_by(By.XPATH, "//button[contains(text(), 'Create Account')]").click()

# Verify success message appears
success_message = driver.find_element_by(By.XPATH, "//div[contains(text(), 'Account created successfully')]")
assert success_message.is_displayed, "Success message did not appear"

# Refresh page and log in
driver.get("https://www.xenius.com/login")
driver.find_element_by(By.XPATH, "//button[contains(text(), 'Log in')]").click()

# Verify user is logged in
driver.find_element_by(By.XPATH, "//span[contains(text(), 'Logged in as')]").text.should_contain("John Doe")
