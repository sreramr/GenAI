
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Define the test cases for each box
def test_synthetic_data_generation():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Synthetic Data Generation
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'synthetic-data-generation')]")))
    driver.find_element_by_link_text("Synthetic Data Generation").click()
    # Verify the page title
    assert driver.title == "Synthetic Data Generation"

def test_data_labelling():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Data Labelling
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'data-labelling')]")))
    driver.find_element_by_link_text("Data Labelling").click()
    # Verify the page title
    assert driver.title == "Data Labelling"

def test_data_streaming():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Data Streaming
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'data-streaming')]")))
    driver.find_element_by_link_text("Data Streaming").click()
    # Verify the page title
    assert driver.title == "Data Streaming"

def test_anomaly_detection():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Anomaly Detection
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'anomaly-detection')]")))
    driver.find_element_by_link_text("Anomaly Detection").click()
    # Verify the page title
    assert driver.title == "Anomaly Detection"

def test_data_quality():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Data Quality
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'data-quality')]")))
    driver.find_element_by_link_text("Data Quality").click()
    # Verify the page title
    assert driver.title == "Data Quality"

def test_semantic_domain_layer():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Semantic Domain Layer
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'semantic-domain-layer')]")))
    driver.find_element_by_link_text("Semantic Domain Layer").click()
    # Verify the page title
    assert driver.title == "Semantic Domain Layer"

def test_data_transformation():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Data Transformation
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'data-transformation')]")))
    driver.find_element_by_link_text("Data Transformation").click()
    # Verify the page title
    assert driver.title == "Data Transformation"

def test_cataloging_and_publishing():
    # Open the Xenius landing page
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/")
    wait = WebDriverWait(driver, 10)
    # Click on the "Get Started" button for Cataloging and Publishing
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, 'cataloging-and-publishing')]")))
    driver.find_element_by_link_text("Cataloging and Publishing").click()
    # Verify the page title
    assert driver.title == "Cataloging and Publishing"

# Wait for the page to load
wait.until(EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'content')]")))
