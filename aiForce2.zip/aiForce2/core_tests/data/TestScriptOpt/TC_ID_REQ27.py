
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("http://localhost/xenius")

# Test Edit Functionality for Unstructured Data Parsing
def test_edit_functionality():
    # Navigate to Unstructured Data Parsing component
    driver.find_element_by_link_text("Unstructured Data Parsing").click()

    # Generate RegEx
    driver.find_element_by_button_text("Generate RegEx").click()

    # Verify RegEx table
    table = driver.find_element_by_css_selector "#regex-table"
    rows = table.find_elements_by_tag_name("tr")
    assert len(rows) > 0, "No RegEx rows found"

    # Edit RegEx
    row = rows[0]
    edit_button = row.find_element_by_css_selector ".edit-button"
    edit_button.click()

    # Verify Edit Pop-up
    pop_up = driver.find_element_by_css_selector ".regex-edit-pop-up"
    assert pop_up.is_displayed(), "Edit Pop-up not displayed"

    # Add/Delete/Edit Tags
    tag_input = pop_up.find_element_by_name "tags"
    assert tag_input.is_enabled(), "Tag input field not enabled"
    tag = "new_tag"
    tag_input.send_keys(tag)
    pop_up.find_element_by_button_text("Add").click()
    assert pop_up.find_element_by_text(tag).is_displayed(), f"Tag {tag} not added"

    # Verify Summary
    summary = pop_up.find_element_by_css_selector ".regex-summary"
    assert summary.is_displayed(), "Summary not displayed"
    assert summary.text == "New Tag: new_tag", "Incorrect summary text"

    # Save and Close Pop-up
    pop_up.find_element_by_button_text("Save").click()
    pop_up.find_element_by_button_text("Close").click()

    # Verify List of Generated RegEx
    driver.find_element_by_css_selector "#regex-table tr"
    assert len(driver.find_elements_by_tag_name("tr")) > 0, "No RegEx rows found after editing"

# Teardown test environment
driver.quit()
