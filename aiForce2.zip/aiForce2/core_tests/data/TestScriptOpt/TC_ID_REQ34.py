
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("http://localhost/datasource")

# Test Add Datasource button
add_datasource_button = driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/button[1]")
add_datasource_button.click()

# Test Add Datasource pop-up
add_datasource_popup = driver.find_element(By.XPATH, "/html/body/div[2]/div[3]")
assert add_datasource_popup.text == "Add Datasource"

# Test Datasource Name field
datasource_name_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[4]/input")
assert datasource_name_field.get_attribute("name") == "datasource_name"

# Test Datasource Type field
datasource_type_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[5]/select")
assert datasource_type_field.find_element(By.TAG_NAME, "option").text == "Local File"

# Test Local File option
local_file_option = driver.find_element(By.XPATH, "/html/body/div[2]/div[6]/input")
assert local_file_option.get_attribute("accept") == "application/octet-stream"

# Test Database option
database_option = driver.find_element(By.XPATH, "/html/body/div[2]/div[7]/select")
assert database_option.find_element(By.TAG_NAME, "option").text == "MSSQL"

# Test Data Warehouse option
data_warehouse_option = driver.find_element(By.XPATH, "/html/body/div[2]/div[8]/select")
assert data_warehouse_option.find_element(By.TAG_NAME, "option").text == "Azure Synapse DWH"

# Test Data Lake option
data_lake_option = driver.find_element(By.XPATH, "/html/body/div[2]/div[9]/select")
assert data_lake_option.find_element(By.TAG_NAME, "option").text == "Azure ADLS Gen 2"

# Test Submit button
submit_button = driver.find_element(By.XPATH, "/html/body/div[2]/div[10]")
submit_button.click()

# Test Connection button
connection_button = driver.find_element(By.XPATH, "/html/body/div[2]/div[11]")
assert connection_button.get_attribute("disabled") == "true"

# Test Test Connection button
test_connection_button = driver.find_element(By.XPATH, "/html/body/div[2]/div[12]")
assert test_connection_button.get_attribute("disabled") == "true"

# Teardown test environment
driver.quit()
