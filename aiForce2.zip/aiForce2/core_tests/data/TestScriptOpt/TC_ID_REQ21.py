
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def test_model_tuning_page_multi_table_synthetic_data_generation():
    # Launch the webdriver and navigate to the Model Tuning page
    driver = webdriver.Chrome()
    driver.get("http://localhost/model-tuning-page")
    wait = WebDriverWait(driver, 10)

    # Verify the page title and header
    assert driver.title == "Model Tuning Page"
    assert driver.find_element_by(By.XPATH, "//h1[contains(text(), 'Model Tuning Page')]").is_displayed()

    # Enter a model name and check the drop-down menu
    model_name = "Xenius_Multi_01"
    driver.find_element_by(By.XPATH, "//input[contains(text(), 'Model Name')]").send_keys(model_name)
    wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Save')]")))
    assert driver.find_element_by(By.XPATH, "//h2[contains(text(), 'Model Name')]").text == model_name

    # Verify the type of synthetic data drop-down menu
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'Type of Synthetic Data')]").find_element_by_tag_name("option").text == "Generic Synthetic Data"
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'Type of Synthetic Data')]").is_enabled is False

    # Verify the algorithm drop-down menu
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'Algorithm')]").find_element_by_tag_name("option").text == "Multi-table synthetic dataset generation by capturing correlations between different tables"
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'Algorithm')]").is_enabled is False

    # Verify the HMA1 class
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'HMA1 Class')]").find_element_by_tag_name("option").text == "Multi-table synthetic datasets generation by capturing correlations between different tables with high quality"
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'HMA1 Class')]").is_enabled is False

    # Verify the epoch and batch size drop-downs
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'Epoch')]").find_element_by_tag_name("option").text == "Not needed for Multi-table synthetic data generation"
    assert driver.find_element_by(By.XPATH, "//select[contains(text(), 'Batch size')]").find_element_by_tag_name("option").text == "Not needed for Multi-table synthetic data generation"

    # Close the webdriver and assert that the page is now blank
    driver.quit()
    assert driver.title == ""
