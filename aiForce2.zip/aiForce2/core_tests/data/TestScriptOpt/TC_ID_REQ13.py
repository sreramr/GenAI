
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def test_data_source_connection_test():
    # Launch the browser
    driver = webdriver.Chrome()
    driver.get("http://localhost/xenius/")

    # Navigate to the data source menu
    driver.find_element_by(By.XPATH, "//a[contains(text(), 'Data Sources')]").click()
    driver.find_element_by(By.XPATH, "//a[contains(text(), 'L0')]").click()

    # Check for the "Test Connection" button in the Action column
    button = driver.find_element_by(By.XPATH, "//td[contains(text(), 'Action')]/button[contains(text(), 'Test Connection')]")
    assert button is not None, "Failed to find 'Test Connection' button in the Action column"

    # Click on the "Test Connection" button
    button.click()

    # Wait for the test to complete
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.XPATH, "//div[contains(text(), 'Data source connection test passed')]")))

    # Verify the test result
    assert driver.find_element_by(By.XPATH, "//div[contains(text(), 'Data source connection test passed')]").is_displayed(), "Data source connection test failed"

    # Close the browser
    driver.quit()
