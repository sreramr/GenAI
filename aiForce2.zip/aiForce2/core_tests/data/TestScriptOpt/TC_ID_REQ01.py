
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def test_xenius_login_page():
    # Launch the webdriver
    driver = webdriver.Chrome()
    driver.implicitly_wait(10) # Wait for the page to load

    # Navigate to the login page
    driver.get("https://xenius.com/login")

    # Verify the page layout
    assert driver.find_element_by(By.XPATH, "//div[contains(@class, 'login-form')]").is_displayed
    assert driver.find_element_by(By.XPATH, "//button[contains(@class, 'sign-in-button')]").is_displayed

    # Enter email and password
    email = driver.find_element_by(By.XPATH, "//input[contains(@name, 'email')]")
    email.send_keys("test@example.com")

    password = driver.find_element_by(By.XPATH, "//input[contains(@name, 'password')]")
    password.send_keys("password123")

    # Click the sign-in button
    sign_in_button = driver.find_element_by(By.XPATH, "//button[contains(@class, 'sign-in-button')]")
    sign_in_button.click()

    # Verify the login success message
    assert driver.find_element_by(By.XPATH, "//div[contains(@class, 'login-success-message')]").is_displayed

    # Close the webdriver
    driver.quit()
