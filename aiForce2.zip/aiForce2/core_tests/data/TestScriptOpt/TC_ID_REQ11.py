
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/login")

# Enter email ID and password in the input fields
email = driver.find_element_by(By.ID, "email")
email.send_keys("test@example.com")

password = driver.find_element_by(By.ID, "password")
password.send_keys("password123")

# Validate email ID input field
assert email.get_attribute("value") == "test@example.com"

# Validate password input field
assert password.get_attribute("value") == "password123"

# Click on login button
login_button = driver.find_element_by(By.XPATH, "//button[contains(text(), 'Login')]")
login_button.click()

# Wait for page to load
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//div[contains(text(), 'Logged in successfully')]")))

# Close browser
driver.quit()
