```
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/")

# Click on Forgot Password link
driver.find_element_by_link_text("Forgot Password").click()

# Wait for pop-up to appear
pop_up = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, ".forgot-password-popup")))

# Verify steps of wizard
def verify_wizard_steps():
    # Step 1: Input details
    name_input = pop_up.find_element_by_name("name")
    email_input = pop_up.find_element_by_name("email")
    assert name_input.get_attribute("value") == "John Doe"
    assert email_input.get_attribute("value") == "johndoe@example.com"

    # Step 2: Security question
    security_question = pop_up.find_element_by_name("securityQuestion")
    assert security_question.get_attribute("value") == "What is your favorite book?"

    # Step 3: Update password
    password_input = pop_up.find_element_by_name("password")
    assert password_input.get_attribute("value") == "NewPassword123"

# Click on Next button
pop_up.find_element_by_button_text("Next").click()

# Verify success message
assert pop_up.find_element_by_text("Password updated successfully").is_present()

# Close pop-up and log in
pop_up.find_element_by_button_text("Close").click()
driver.get("https://www.xenius.com/login")
assert driver.find_element_by_text("Logged in successfully").is_present()

# Teardown test environment
driver.quit()
