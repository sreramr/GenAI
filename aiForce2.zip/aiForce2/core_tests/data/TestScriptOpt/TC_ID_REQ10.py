
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("http://localhost/xenius")

# Navigate to Data Source menu
driver.find_element_by(By.LinkText,"Data Source").click()
driver.find_element_by(By.ClassName,"data-source-menu").click()

# Select Data Warehouse option
driver.find_element_by(By.ClassName,"data-source-type").click()
driver.find_element_by(By.Value,"Data Warehouse").click()

# Wait for drop-down list to appear
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, ".data-source-list")))

# Verify drop-down list contains expected data warehouses
assert driver.find_element_by(By.CSS_SELECTOR, ".data-source-list").find_elements(By.CSS_SELECTOR, ".data-source-item").count == 3

# Select Azure Synapse DWH
driver.find_element_by(By.CSS_SELECTOR, ".data-source-list .data-source-item:eq(0)").click()

# Verify input fields are updated
assert driver.find_element_by(By.ID, "data-source-name").get_attribute("value") == "Azure Synapse DWH"
assert driver.find_element_by(By.ID, "data-source-connection-string").get_attribute("value") == "Server=https://<server_name>;Database=<database_name>;User Id=<username>;Password=<password>;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;")

# Select Snowflake DWH
driver.find_element_by(By.CSS_SELECTOR, ".data-source-list .data-source-item:eq(1)").click()

# Verify input fields are updated
assert driver.find_element_by(By.ID, "data-source-name").get_attribute("value") == "Snowflake DWH"
assert driver.find_element_by(By.ID, "data-source-connection-string").get_attribute("value") == "Account=<account_name>;User=<username>;Password=<password>;Warehouse=<warehouse_name>;DB=<database_name>;")

# Select Actian Avalanche DWH
driver.find_element_by(By.CSS_SELECTOR, ".data-source-list .data-source-item:eq(2)").click()

# Verify input fields are updated
assert driver.find_element_by(By.ID, "data-source-name").get_attribute("value") == "Actian Avalanche DWH"
assert driver.find_element_by(By.ID, "data-source-connection-string").get_attribute("value") == "Server=<server_name>;Database=<database_name>;User Id=<username>;Password=<password>;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;")

# Close test environment
driver.quit()
