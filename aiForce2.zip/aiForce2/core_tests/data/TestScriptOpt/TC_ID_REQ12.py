
import pytest
from appium.webdriver.common.touch_event import tap
from appium.webdriver.common.wait import wait

def test_data_source_add_adls_gen2(app):
    # Open Xenius Data source L0 menu
    app.find_element_by_xpath('//a[@href="#/data-source/L0"]').click()
    wait(10).until(lambda driver: driver.find_element_by_xpath('//div[@class="data-source-menu"]'))

    # Select Data Lake from Data source Type drop-down
    app.find_element_by_xpath('//select[@name="dataSourceType"]').select_by_value('Data Lake')

    # Verify Data Lake pop-up displayed
    wait(10).until(lambda driver: driver.find_element_by_xpath('//div[@class="data-source-popup"]'))

    # Verify Azure ADLS Gen 2 field in Data Lake pop-up
    Azure_ADLS_Gen_2_field = app.find_element_by_xpath('//div[@class="data-source-popup"]//div[@class="field"][2]')
    assert Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').get_attribute('name') == 'storageAccountName'
    assert Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').get_attribute('value') == ''

    # Fill in Storage Account Name field
    Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').send_keys('my-storage-account')

    # Verify Storage Account Name field
    assert Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').get_attribute('value') == 'my-storage-account'

    # Fill in Storage Account Key field
    Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').send_keys('my-storage-account-key')

    # Verify Storage Account Key field
    assert Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').get_attribute('value') == 'my-storage-account-key'

    # Fill in Container Name field
    Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').send_keys('my-container')

    # Verify Container Name field
    assert Azure_ADLS_Gen_2_field.find_element_by_tag_name('input').get_attribute('value') == 'my-container'

    # Click Submit button
    app.find_element_by_xpath('//button[@type="submit"]').click()

    # Verify Submit button click
    wait(10).until(lambda driver: driver.find_element_by_xpath('//div[@class="data-source-popup"]/button[2]'))

    # Close Data source pop-up
    app.find_element_by_xpath('//div[@class="data-source-popup"]/button[3]').click()

    # Verify Data source pop-up closed
    wait(10).until(lambda driver: not driver.find_element_by_xpath('//div[@class="data-source-popup"]'))
