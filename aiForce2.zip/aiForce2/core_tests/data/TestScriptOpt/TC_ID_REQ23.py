
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up the test environment
driver = webdriver.Chrome()
driver.get("https://xenius-landing-page.com")

# Test the Synthetic Data Generation tab
def test_synthetic_data_generation_tab():
    # Click on the Synthetic Data Generation tab
    driver.find_element_by(By.Link_Text, "Synthetic Data Generation").click()
    # Verify the page title
    assert driver.title == "Synthetic Data Generation"
    # Click on the 'Get Started' button
    driver.find_element_by(By.Link_Text, "Get Started").click()
    # Wait for the page to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//button[@type='submit']")))
    # Verify the button text
    assert driver.find_element_by(By.XPATH, "//button[@type='submit']").text == "Get Started"

# Test the Data Labelling tab
def test_data_labelling_tab():
    # Click on the Data Labelling tab
    driver.find_element_by(By.Link_Text, "Data Labelling").click()
    # Verify the page title
    assert driver.title == "Data Labelling"
    # Click on the 'Get Started' button
    driver.find_element_by(By.Link_Text, "Get Started").click()
    # Wait for the page to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//button[@type='submit']")))
    # Verify the button text
    assert driver.find_element_by(By.XPATH, "//button[@type='submit']").text == "Get Started"

# Test the Data Streaming tab
def test_data_streaming_tab():
    # Click on the Data Streaming tab
    driver.find_element_by(By.Link_Text, "Data Streaming").click()
    # Verify the page title
    assert driver.title == "Data Streaming"
    # Click on the 'Get Started' button
    driver.find_element_by(By.Link_Text, "Get Started").click()
    # Wait for the page to load
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//button[@type='submit']")))
    # Verify the button text
    assert driver.find_element_by(By.XPATH, "//button[@type='submit']").text == "Get Started"

# Close the test environment
driver.quit()
