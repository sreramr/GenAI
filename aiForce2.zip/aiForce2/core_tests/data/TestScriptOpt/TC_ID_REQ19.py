
import pytest
from appium.webdriver.common.common import Common
from appium.webdriver.common.constants import CommonMethod

class TestDropColumn(Common):
    def test_drop_column_in_schema_view(self):
        # Set up test environment
        self.app.launch_app()
        self.app.maximize_window()
        self.app.load_url("https://localhost:8080/")
        self.app.wait_for_element_visible("Drop Column")

        # Click on Drop Column button
        button = self.app.find_element_by_xpath("//button[contains(text(), 'Drop Column')]")
        button.click()

        # Verify that the column is dropped from the schema
        schema_view = self.app.find_element_by_xpath("//div[contains(text(), 'Schema View')]")
        column_to_be_dropped = "Actions"
        expected_schema = [
            {"name": "Name", "type": "string"},
            {"name": "Description", "type": "string"},
            {"name": "Actions", "type": "string"}
        ]
        actual_schema = schema_view.find_elements_by_tag_name("div")
        assert actual_schema == expected_schema, "Expected schema does not match actual schema"

        # Verify that the column is not used for model training
        model_training_view = self.app.find_element_by_xpath("//div[contains(text(), 'Model Training')]")
        expected_model_training_schema = [
            {"name": "Name", "type": "string"},
            {"name": "Description", "type": "string"},
            {"name": "Actions", "type": "string"}
        ]
        actual_model_training_schema = model_training_view.find_elements_by_tag_name("div")
        assert actual_model_training_schema == expected_model_training_schema, "Expected model training schema does not match actual schema"

        # Close the application
        self.app.quit()

    def tear_down(self):
        pass
