
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Define the requirement ID and description
req_id = "REQ18"
req_desc = "Editable Pagination for Data Preview Wizard"

# Set up the test environment
driver = webdriver.Chrome()
driver.get("http://localhost/data-preview-wizard")

# Click on the "Start" button to enter the data preview wizard
driver.find_element_by_button_text("Start").click()

# Navigate to the data preview page
driver.find_element_by_link_text("Data Preview").click()

# Verify that the pagination dropdown is visible
assert driver.find_element_by_css_selector("div.pagination > ul > li:first-child > span").is_displayed()

# Set up the test case for editable pagination
def test_editable_pagination():
    # Enter the drop-down menu and select a value
    dropdown = driver.find_element_by_css_selector("div.pagination > ul > li:first-child > span")
    dropdown.click()
    dropdown.find_element_by_css_selector("span").click()
    dropdown.find_element_by_css_selector("span").send_keys("50")

    # Verify that the correct number of rows are displayed
    rows = driver.find_elements_by_css_selector("div.data-row")
    assert len(rows) == 50

    # Verify that the number of pages has changed
    pages = driver.find_elements_by_css_selector("li.page-item")
    assert len(pages) == 2

# Teardown the test environment
driver.quit()
