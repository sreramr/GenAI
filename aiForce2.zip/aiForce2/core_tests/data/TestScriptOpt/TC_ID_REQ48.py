
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Test for breadcrumbs in Semantic Data Layer
def test_breadcrumbs_semantic_data_layer():
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/semantic-data-layer")
    wait = WebDriverWait(driver, 10)
    breadcrumbs = wait.until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@class, 'breadcrumb')]")))
    assert len(breadcrumbs) > 0, "Breadcrumbs not found in Semantic Data Layer"
    assert breadcrumbs[0].text == "Semantic Data Layer", "Incorrect breadcrumb text in Semantic Data Layer"
    assert breadcrumbs[1].text == "Domain Objects", "Incorrect breadcrumb text in Domain Objects"
    assert breadcrumbs[2].text == "Semantic Data Layer/Domain Objects", "Incorrect breadcrumb text in Domain Objects"
    driver.quit()

# Test for breadcrumbs in Data Quality Assurance
def test_breadcrumbs_data_quality_assurance():
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/data-quality-assurance")
    wait = WebDriverWait(driver, 10)
    breadcrumbs = wait.until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@class, 'breadcrumb')]")))
    assert len(breadcrumbs) > 0, "Breadcrumbs not found in Data Quality Assurance"
    assert breadcrumbs[0].text == "Data Quality Assurance", "Incorrect breadcrumb text in Data Quality Assurance"
    assert breadcrumbs[1].text == "Dashboards", "Incorrect breadcrumb text in Dashboards"
    assert breadcrumbs[2].text == "Data Quality Assurance/Dashboards", "Incorrect breadcrumb text in Dashboards"
    driver.quit()

# Test for breadcrumbs in Settings
def test_breadcrumbs_settings():
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/settings")
    wait = WebDriverWait(driver, 10)
    breadcrumbs = wait.until(EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@class, 'breadcrumb')]")))
    assert len(breadcrumbs) > 0, "Breadcrumbs not found in Settings"
    assert breadcrumbs[0].text == "Settings", "Incorrect breadcrumb text in Settings"
    assert breadcrumbs[1].text == "User Management", "Incorrect breadcrumb text in User Management"
    assert breadcrumbs[2].text == "Settings/User Management", "Incorrect breadcrumb text in User Management"
    driver.quit()

# Summary
The breadcrumbs are implemented correctly in all the pages tested, including Semantic Data Layer, Data Quality Assurance, and Settings. The breadcrumbs are positioned on the right-hand side of the page heading and are displayed for each tile selected.
