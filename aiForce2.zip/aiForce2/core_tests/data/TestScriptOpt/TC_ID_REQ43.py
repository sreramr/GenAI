
import pytest
from app.features.synthetic_data_generation.datasource import datasource_available
from app.features.synthetic_data_generation.datasource import select_data_asset
from app.features.synthetic_data_generation.datasource import add_new_datasource
from app.features.synthetic_data_generation.datasource import differentially_private_synthetic_data_generation

def test_datasource_available():
    # Test that the datasource is available
    assert datasource_available()

def test_select_data_asset():
    # Test that the select data asset button is visible
    assert select_data_asset()

def test_add_new_datasource():
    # Test that the add new datasource button is visible
    assert add_new_datasource()

def test_differentially_private_synthetic_data_generation():
    # Test that the differentially private synthetic data generation is available
    assert differentially_private_synthetic_data_generation()

@pytest.mark.usefixtures("datasource_available")
def test_datasource_selection():
    # Test that the datasource selection dropdown is available
    assert select_data_asset()

@pytest.mark.usefixtures("add_new_datasource")
def test_add_new_datasource_success():
    # Test that adding a new datasource is successful
    assert add_new_datasource()

@pytest.mark.usefixtures("differentially_private_synthetic_data_generation")
def test_differentially_private_synthetic_data_generation_success():
    # Test that the differentially private synthetic data generation is successful
    assert differentially_private_synthetic_data_generation()

@pytest.mark.usefixtures("datasource_available")
def test_select_data_asset_success():
    # Test that the select data asset button is successful
    assert select_data_asset()

@pytest.mark.usefixtures("add_new_datasource")
def test_add_new_datasource_failure():
    # Test that adding a new datasource fails
    assert not add_new_datasource()

@pytest.mark.usefixtures("differentially_private_synthetic_data_generation")
def test_differentially_private_synthetic_data_generation_failure():
    # Test that the differentially private synthetic data generation fails
    assert not differentially_private_synthetic_data_generation()
