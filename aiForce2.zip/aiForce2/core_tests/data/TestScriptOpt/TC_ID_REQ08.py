
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up the test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/")

# Verify the email ID input field is large enough
email_id_field = driver.find_element_by(By.ID, "email_id")
assert email_id_field.size > 20, "Email ID input field is too small"

# Verify the password input field is large enough
password_field = driver.find_element_by(By.ID, "password")
assert password_field.size > 20, "Password input field is too small"

# Verify the instructions are displayed
instructions_element = driver.find_element_by(By.XPATH, ".//div[contains(text(), 'Enter your email ID and password')]")
assert instructions_element.is_displayed(), "Instructions are not displayed"

# Enter email ID and password and verify the login page is displayed
email_id_field.send_keys("test@example.com")
password_field.send_keys("password123")
driver.find_element_by(By.ID, "login").click()
assert driver.current_url == "https://www.xenius.com/login-success", "Login page is not displayed"

# Close the browser
driver.quit()
