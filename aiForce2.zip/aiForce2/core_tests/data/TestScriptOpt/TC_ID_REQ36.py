
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def test_sign_in_page_normal_login(driver):
    # Open Xenius login page
    driver.get("https://www.xenius.com/login")
    # Fill email ID and password fields
    email_id_field = driver.find_element_by(By.ID, "email")
    password_field = driver.find_element_by(By.ID, "password")
    email_id_field.send_keys("test@example.com")
    password_field.send_keys("test1234")
    # Submit login form
    login_button = driver.find_element_by(By.XPATH, "//button[contains(., 'Sign in')]")
    login_button.click()
    # Verify successful login message
    login_message = driver.find_element_by(By.XPATH, "//div[contains(., 'Your account has been created')]")
    assert login_message.is_displayed(), "Failed to display successful login message"

def test_new_user_popup(driver):
    # Click on New User link
    new_user_link = driver.find_element_by(By.XPATH, "//a[contains(., 'New User?')]")
    new_user_link.click()
    # Fill new user details
    name_field = driver.find_element_by(By.ID, "name")
    name_field.send_keys("John Doe")
    email_field = driver.find_element_by(By.ID, "email")
    email_field.send_keys("johndoe@example.com")
    password_field = driver.find_element_by(By.ID, "password")
    password_field.send_keys("test1234")
    # Submit new user form
    submit_button = driver.find_element_by(By.XPATH, "//button[contains(., 'Create Account')]")
    submit_button.click()
    # Verify successful creation of new user
    new_user_message = driver.find_element_by(By.XPATH, "//div[contains(., 'Your account has been created')]")
    assert new_user_message.is_displayed(), "Failed to create new user"

def test_incorrect_email_password(driver):
    # Fill email ID and password fields with incorrect values
    email_id_field = driver.find_element_by(By.ID, "email")
    email_id_field.send_keys("incorrect@example.com")
    password_field = driver.find_element_by(By.ID, "password")
    password_field.send_keys("incorrectpassword")
    # Submit login form
    login_button = driver.find_element_by(By.XPATH, "//button[contains(., 'Sign in')]")
    login_button.click()
    # Verify error message for incorrect email/password
    error_message = driver.find_element_by(By.XPATH, "//div[contains(., 'Incorrect email or password')]")
    assert error_message.is_displayed(), "Failed to display error message for incorrect email/password"
