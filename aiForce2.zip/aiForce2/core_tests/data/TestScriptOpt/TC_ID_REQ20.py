
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Define the test case
def test_elixir_integration_in_xenius():
    # Launch the webdriver
    driver = webdriver.Chrome()
    driver.implicitly_wait(10) # Wait for 10 seconds for the page to load

    # Navigate to the elixir dashboard page
    driver.get("http://localhost/xenius/elixir")

    # Verify the dashboard page
    assert driver.title == "Elixir Dashboard"
    assert driver.find_element_by(By.XPATH, "//h1[contains(., 'Elixir Dashboard')]").is_displayed

    # Verify the 4 tabs for models, regex and tasks
    assert driver.find_element_by(By.XPATH, "//ul[contains(., 'Models')]").is_displayed
    assert driver.find_element_by(By.XPATH, "//ul[contains(., 'Regex')]").is_displayed
    assert driver.find_element_by(By.XPATH, "//ul[contains(., 'Tasks')]").is_displayed

    # Verify the 2 buttons - New Model Training and Unstructured Data Parsing
    assert driver.find_element_by(By.XPATH, "//button[contains(., 'New Model Training')]").is_displayed
    assert driver.find_element_by(By.XPATH, "//button[contains(., 'Unstructured Data Parsing')]").is_displayed

    # Verify the Recently Completed Tasks Table
    assert driver.find_element_by(By.XPATH, "//table[contains(., 'Recently Completed Tasks')]").is_displayed

    # Click on New Model Training button
    driver.find_element_by(By.XPATH, "//button[contains(., 'New Model Training')]").click()

    # Verify the Training flow
    assert driver.title == "Training Model"
    assert driver.find_element_by(By.XPATH, "//h1[contains(., 'Training Model')]").is_displayed

    # Click on Unstructured Data Parsing button
    driver.find_element_by(By.XPATH, "//button[contains(., 'Unstructured Data Parsing')]").click()

    # Verify the Data Task flow
    assert driver.title == "Data Task"
    assert driver.find_element_by(By.XPATH, "//h1[contains(., 'Data Task')]").is_displayed

    # Close the webdriver
    driver.quit()

# Run the test case
pytest.main()
