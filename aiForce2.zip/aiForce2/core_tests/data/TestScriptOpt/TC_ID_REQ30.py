
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# Define the test cases
def test_basic_labelling_tab():
    # Launch the browser and navigate to the data labelling landing page
    driver = webdriver.Chrome()
    driver.get("http://localhost/xenius-data-labelling/")
    # Click on the Basic Labelling tab
    driver.find_element_by_link_text("Basic Labelling").click()
    # Verify that the Basic Labelling wizard is displayed
    assert driver.find_element_by_class_name("wizard-container").text == "Basic Labelling"
    # Complete the Basic Labelling wizard
    driver.find_element_by_button_text("Next").click()
    # Verify that the labelling is done using clustering
    assert driver.find_element_by_class_name("clustering-results").text != ""

def test_advanced_labelling_tab():
    # Launch the browser and navigate to the data labelling landing page
    driver = webdriver.Chrome()
    driver.get("http://localhost/xenius-data-labelling/")
    # Click on the Advanced Labelling tab
    driver.find_element_by_link_text("Advanced Labelling").click()
    # Verify that the Advanced Labelling wizard is displayed
    assert driver.find_element_by_class_name("wizard-container").text == "Advanced Labelling"
    # Complete the Advanced Labelling wizard
    driver.find_element_by_button_text("Next").click()
    # Verify that the labelling is done using Snorkel
    assert driver.find_element_by_class_name("snorkel-results").text != ""

def test_define_custom_labels():
    # Launch the browser and navigate to the data labelling landing page
    driver = webdriver.Chrome()
    driver.get("http://localhost/xenius-data-labelling/")
    # Click on the Define Custom Labels button
    driver.find_element_by_button_text("Define Custom Labels").click()
    # Verify that the custom label pop-up is displayed
    assert driver.find_element_by_class_name("pop-up").text == "Define Custom Labels"
    # Enter a custom label name and click Apply
    driver.find_element_by_button_text("Apply").click()
    # Verify that the custom label is saved
    assert driver.find_element_by_class_name("custom-label").text == "My Custom Label"

# Define the test suite
@pytest.fixture
def test_suite():
    return [
        test_basic_labelling_tab,
        test_advanced_labelling_tab,
        test_define_custom_labels,
    ]

# Run the test suite
pytest.main()
