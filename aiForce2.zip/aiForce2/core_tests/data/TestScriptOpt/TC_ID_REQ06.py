
import pytest
from appium.webdriver.common.common import CommonMethod

def test_add_data_source_popup_opens(app):
    # Click on Add Data source button
    app.find_element_by_xpath('//button[contains(text(), "Add Data source")]').click()
    # Verify pop-up window opens
    assert app.find_element_by_xpath('//div[contains(text(), "Add Data source")]').is_present(), "Pop-up window not found"
    # Verify pop-up window has correct heading
    assert app.find_element_by_xpath('//h1[contains(text(), "Add Data source")]').text == "Add Data source", "Incorrect pop-up window heading"
    # Verify pop-up window has two fields
    assert app.find_element_by_xpath('//div[contains(text(), "Data source Name")]').is_present(), "Data source Name field not found"
    assert app.find_element_by_xpath('//div[contains(text(), "Data source Type")]').is_present(), "Data source Type field not found"
    # Enter some data and verify it
    app.find_element_by_xpath('//input[contains(text(), "Data source Name")]').send_keys("My Data Source")
    app.find_element_by_xpath('//input[contains(text(), "Data source Type")]').send_keys("My Data Type")
    # Click on Add button
    app.find_element_by_xpath('//button[contains(text(), "Add")]').click()
    # Verify data source added successfully
    assert app.find_element_by_xpath('//div[contains(text(), "My Data Source")]').is_present(), "Data source not added successfully"

def assertions():
    assert app.find_element_by_xpath('//div[contains(text(), "Add Data source")]').is_present(), "Pop-up window not found"
    assert app.find_element_by_xpath('//h1[contains(text(), "Add Data source")]').text == "Add Data source", "Incorrect pop-up window heading"
    assert app.find_element_by_xpath('//div[contains(text(), "Data source Name")]').is_present(), "Data source Name field not found"
    assert app.find_element_by_xpath('//div[contains(text(), "Data source Type")]').is_present(), "Data source Type field not found"
    assert app.find_element_by_xpath('//button[contains(text(), "Add")]').is_enabled(), "Add button not enabled"
    assert app.find_element_by_xpath('//div[contains(text(), "My Data Source")]').is_present(), "Data source not added successfully"

@pytest.mark.usefixtures("app")
def test_add_data_source_popup_opens_fixture(app):
    # Set up test environment
    pass

@pytest.mark.teardown
def teardown():
    # Teardown test environment
    pass
