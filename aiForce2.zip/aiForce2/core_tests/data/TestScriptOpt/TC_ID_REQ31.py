
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Define the test case name and description
test_name = "Verify Xenius Login Page Details Verification"
test_description = "Test that the Xenius login page verifies the input details provided by the user and displays an error message in case of incorrect details."

# Set up the test environment
driver = webdriver.Chrome()
driver.get("https://www.xenius.com/")

# Enter user details and verify
username = "test_username"
password = "test_password"
driver.find_element_by_name("username").send_keys(username)
driver.find_element_by_name("password").send_keys(password)
driver.find_element_by_name("login").click()

# Verify login success
assert driver.title == "Xenius"

# Enter incorrect details and verify error message
incorrect_username = "incorrect_username"
incorrect_password = "incorrect_password"
driver.find_element_by_name("username").send_keys(incorrect_username)
driver.find_element_by_name("password").send_keys(incorrect_password)
driver.find_element_by_name("login").click()

# Verify error message
assert driver.find_element_by_css_selector("#error-message").is_displayed()

# Close the browser
driver.quit()
