
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# Set up test environment
driver = webdriver.Chrome()
driver.implicitly_wait(10) # Wait for page to load

# Test Details Dashboard enhancements
def test_details_dashboard_enhancements():
    # Navigate to Details Dashboard
    driver.get("https://xenius.com/details-dashboard")
    # Verify new columns added
    table = driver.find_element_by_css_selector "#data-quality-table")
    assert table.find_element_by_css_selector ".threshold-defined").is_present
    assert table.find_element_by_css_selector ".threshold-achieved").is_present
    assert table.find_element_by_css_selector ".cost-of-quality").is_present
    # Verify pagination
    driver.find_element_by_css_selector "#data-quality-table").click()
    driver.find_element_by_css_selector ".pagination").click()
    driver.find_element_by_css_selector ".pagination li:first-child").click()
    # Verify quality trends dashboard enhancements
    driver.get("https://xenius.com/quality-trends-dashboard")
    # Verify data quality vs time chart heading
    chart = driver.find_element_by_css_selector "#data-quality-vs-time-chart")
    assert chart.find_element_by_css_selector ".chart-header").text == "Data Quality vs Time (last 24 hrs)"
    # Verify cost of quality dashboard enhancements
    driver.get("https://xenius.com/cost-of-quality-dashboard")
    # Verify cost of quality by trend chart heading
    chart = driver.find_element_by_css_selector "#cost-of-quality-by-trend-chart")
    assert chart.find_element_by_css_selector ".chart-header").text == "Cost of Quality Trend per Month"
    # Verify data quality rules mapping
    driver.get("https://xenius.com/data-quality-rules")
    # Verify table level rules
    table = driver.find_element_by_css_selector "#data-quality-table")
    rules = table.find_elements_by_css_selector ".rule")
    for rule in rules:
        assert rule.find_element_by_css_selector ".dimension").text == "Table Level"
    # Verify column level rules
    table = driver.find_element_by_css_selector "#data-quality-table")
    rules = table.find_elements_by_css_selector ".rule")
    for rule in rules:
        assert rule.find_element_by_css_selector ".dimension").text == "Column Level"

# Test re-running validations
def test_re_running_validations():
    # Navigate to Validation Summary Page
    driver.get("https://xenius.com/validation-summary")
    # Verify latest timestamps first
    table = driver.find_element_by_css_selector "#validation-table")
    assert table.find_element_by_css_selector ".sort-by").text == "Latest"
    # Verify re-running validations
    driver.find_element_by_css_selector ".re-run-validation").click()
    table = driver.find_element_by_css_selector "#validation-table")
    assert table.find_element_by_css_selector ".re-run-validation-status").text == "Success"

# Teardown test environment
driver.quit()
