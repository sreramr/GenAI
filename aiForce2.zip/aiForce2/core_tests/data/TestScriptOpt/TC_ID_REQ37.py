
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def test_sign_in_page_normal_log_in(driver):
    # Open Xenius login page
    driver.get("http://www.xenius.com/login")
    # Fill email and password fields
    email_field = driver.find_element_by(By.ID, "email")
    password_field = driver.find_element_by(By.ID, "password")
    email_field.send_keys("test@example.com")
    password_field.send_keys("password")
    # Click sign-in button
    sign_in_button = driver.find_element_by(By.XPATH, "//button[contains(text(), 'Sign In')]")
    sign_in_button.click()
    # Verify successful sign-in
    assert driver.title == "Xenius"

def test_new_user_registration(driver):
    # Open Xenius new user registration page
    driver.get("http://www.xenius.com/register")
    # Fill new user details
    name_field = driver.find_element_by(By.NAME, "name")
    name_field.send_keys("John Doe")
    email_field = driver.find_element_by(By.NAME, "email")
    email_field.send_keys("johndoe@example.com")
    role_select = driver.find_element_by(By.SELECT, "role")
    role_select.select_by_value("Admin")
    # Click submit button
    submit_button = driver.find_element_by(By.XPATH, "//button[contains(text(), 'Submit')]")
    submit_button.click()
    # Verify successful registration
    assert driver.title == "Xenius"

def test_forgot_password(driver):
    # Open Xenius forgot password page
    driver.get("http://www.xenius.com/forgot_password")
    # Fill email field
    email_field = driver.find_element_by(By.ID, "email")
    email_field.send_keys("test@example.com")
    # Click submit button
    submit_button = driver.find_element_by(By.XPATH, "//button[contains(text(), 'Submit')]")
    submit_button.click()
    # Verify successful forgot password
    assert driver.title == "Xenius"

def test_password_update(driver):
    # Open Xenius password update page
    driver.get("http://www.xenius.com/password_update")
    # Fill old password field
    old_password_field = driver.find_element_by(By.ID, "old_password")
    old_password_field.send_keys("old_password")
    # Fill new password field
    new_password_field = driver.find_element_by(By.ID, "new_password")
    new_password_field.send_keys("new_password")
    # Click submit button
    submit_button = driver.find_element_by(By.XPATH, "//button[contains(text(), 'Submit')]")
    submit_button.click()
    # Verify successful password update
    assert driver.title == "Xenius"

def test_password_update_success(driver):
    # Open Xenius password update page
    driver.get("http://www.xenius.com/password_update")
    # Fill old password field
    old_password_field = driver.find_element_by(By.ID, "old_password")
    old_password_field.send_keys("old_password")
    # Fill new password field
    new_password_field = driver.find_element_by(By.ID, "new_password")
    new_password_field.send_keys("new_password")
    # Click submit button
    submit_button = driver.find_element_by(By.XPATH, "//button[contains(text(), 'Submit')]")
    submit_button.click()
    # Verify successful password update
    assert driver.title == "Xenius"

def test_password_update_fail(driver):
    # Open Xenius password update page
    driver.get("http://www.xenius.com/password_update")
    # Fill old password field
    old_password_field = driver.find_element_by(By.ID, "old_password")
    old_password_field.send_keys("old_password")
    # Fill new password field
    new_password_field = driver.find_element_by(By.ID, "new_password")
    new_password_field.send_keys("incorrect_password")
    # Click submit button
    submit_button = driver.find_element_by(By.XPATH, "//button[contains(text(), 'Submit')]")
    submit_button.click()
    # Verify failed password update
    assert driver.title == "Xenius"
