```
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("http://www.xenius.com/")

# Click on Forgot Password link
driver.find_element_by_link_text("Forgot Password").click()

# Wait for pop-up to appear
pop_up = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, ".forgot-password-popup")))

# Verify steps 1 and 2 of wizard
def verify_step1_and_2():
    step1_input_field = pop_up.find_element_by_name("name")
    step2_security_question = pop_up.find_element_by_name("securityQuestion")
    assert step1_input_field.get_attribute("value") == "John Doe"
    assert step2_security_question.get_attribute("value") == "What is your favorite book?"

# Verify step 4 of wizard
def verify_step4():
    password_field = pop_up.find_element_by_name("password")
    assert password_field.get_attribute("value") == "NewPassword123"

# Verify failure message for password less than 6 characters
def verify_failure_message():
    failure_message = pop_up.find_element_by_css_selector(".password-length-error")
    assert failure_message.text == "Password must be at least 6 characters long"

# Test the wizard steps
def test_forgot_password_wizard():
    verify_step1_and_2()
    password_field = pop_up.find_element_by_name("password")
    password_field.send_keys("NewPassword123")
    verify_step4()
    verify_failure_message()

# Close pop-up and quit driver
pop_up.find_element_by_css_selector(".close").click()
driver.quit()
