
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.implicitly_wait(10) # Wait for 10 seconds for page to load

# Navigate to Xenius User Management
driver.get("http://localhost/xenius/user-management")

# Verify User Management Landing Page
assert driver.title == "Xenius User Management"

# Click on User Details tile
user_management_tile = driver.find_element_by_link_text("User Management")
user_management_tile.click()

# Verify User Details Page
assert driver.title == "User Management - Xenius"

# Verify User Profile Details
user_profile = driver.find_element_by_css_selector "#user-profile"
assert user_profile.find_element_by_css_selector "#name").text == "John Doe"
assert user_profile.find_element_by_css_selector "#email").text == "johndoe@example.com"
assert user_profile.find_element_by_css_selector "#role").text == "Admin"

# Verify User Metadata Table
user_metadata_table = driver.find_element_by_css_selector "#user-metadata-table"
assert len(user_metadata_table.find_elements_by_tag_name "tr")) == 0

# Add New User
add_user_button = driver.find_element_by_css_selector "#add-user-button"
add_user_button.click()

# Verify Add User Pop-up
pop_up = driver.find_element_by_css_selector "#add-user-pop-up"
assert pop_up.find_element_by_css_selector "#user-name").text == "New User"
assert pop_up.find_element_by_css_selector "#email").text == "newuser@example.com"

# Save New User Details
save_button = driver.find_element_by_css_selector "#save-button"
save_button.click()

# Verify User Management Landing Page
driver.get("http://localhost/xenius/user-management")
assert driver.title == "Xenius User Management"

# Verify New User Details
new_user_details = driver.find_element_by_css_selector "#user-profile"
assert new_user_details.find_element_by_css_selector "#name").text == "New User"
assert new_user_details.find_element_by_css_selector "#email").text == "newuser@example.com"

# Verify Anomaly Detection Table
anomaly_detection_table = driver.find_element_by_css_selector "#anomaly-detection-table"
assert len(anomaly_detection_table.find_elements_by_tag_name "tr")) == 0

# Verify Data Sources Table
data_sources_table = driver.find_element_by_css_selector "#data-sources-table"
assert len(data_sources_table.find_elements_by_tag_name "tr")) == 0

# Verify User Management Landing Page
driver.get("http://localhost/xenius/user-management")
assert driver.title == "Xenius User Management"

# Close Browser
driver.quit()

# Summary
Passed: All test cases passed
