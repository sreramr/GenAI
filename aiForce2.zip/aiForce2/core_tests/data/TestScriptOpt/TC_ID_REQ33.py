
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up test environment
driver = webdriver.Chrome()
driver.get("http://localhost/datasource")

# Test Add Datasource button
add_datasource_button = driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/button[1]")
add_datasource_button.click()

# Test Add Datasource pop-up
add_datasource_popup = driver.find_element(By.XPATH, "/html/body/div[2]/div[3]")
assert add_datasource_popup.text == "Add Datasource"

# Test Datasource Name field
datasource_name_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[4]/input")
assert datasource_name_field.get_attribute("name") == "datasource_name"

# Test Datasource Type field
datasource_type_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[5]/select")
assert datasource_type_field.find_element(By.XPATH, "option[1]").text == "Local File"

# Test Local File field
local_file_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[6]/input")
assert local_file_field.get_attribute("accept") == "xls,csv,json"

# Test Database field
database_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[7]/select")
assert database_field.find_element(By.XPATH, "option[1]").text == "MSSQL Database"

# Test Data Warehouse field
data_warehouse_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[8]/select")
assert data_warehouse_field.find_element(By.XPATH, "option[1]").text == "Azure Synapse DWH"

# Test Data Lake field
data_lake_field = driver.find_element(By.XPATH, "/html/body/div[2]/div[9]/select")
assert data_lake_field.find_element(By.XPATH, "option[1]").text == "Azure ADLS Gen 2"

# Test Submit button
submit_button = driver.find_element(By.XPATH, "/html/body/div[2]/div[10]")
submit_button.click()

# Test Connection button
connection_button = driver.find_element(By.XPATH, "/html/body/div[2]/div[11]")
connection_button.click()

# Wait for test to complete
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "/html/body/div[2]/div[12]")))

# Summary
Passed
