
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

def test_regex_in_data_labelling():
    # Launch the application
    driver = webdriver.Chrome()
    driver.get("http://localhost/xenius")

    # Navigate to Advanced Labelling page
    driver.find_element_by(By.LinkText,"Advanced Labelling").click()

    # Select a textual column
    column_select = driver.find_element_by(By.XPATH,"//select[@name='column']")
    column_select.select_by_value("Text Column 1")

    # Click on the RegEx option
    reg_ex_option = driver.find_element_by(By.XPATH,"//button[@name='regex']")
    reg_ex_option.click()

    # Wait for the regex pop-up to appear
    regex_pop_up = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH,"//div[contains(@class,'regex-popup')]")))

    # Enter a regex or select from the list
    regex_input = regex_pop_up.find_element_by(By.XPATH,"//input[@name='regex']")
    regex_input.send_keys("^.*$")

    # Click on the Apply button
    apply_button = regex_pop_up.find_element_by(By.XPATH,"//button[@name='apply']")
    apply_button.click()

    # Wait for the data labelling to complete
    driver.find_element_by(By.XPATH,"//div[contains(@class,'data-labelling-complete')]").click()

    # Verify the data labelling results
    driver.find_element_by(By.XPATH,"//div[contains(@class,'data-labelling-results')]").text.should_contain("Labelled data")

    # Close the application
    driver.quit()

def assertions():
    # Assert that the RegEx option is present in the drop-down menu
    assert driver.find_element_by(By.XPATH,"//select[@name='column']").find_element_by(By.XPATH,"//option[@value='Text Column 1']").is_enabled()

    # Assert that the RegEx button is present in the Advanced Labelling page
    assert driver.find_element_by(By.XPATH,"//button[@name='regex']").is_enabled()

    # Assert that the regex pop-up appears when the RegEx button is clicked
    assert driver.find_element_by(By.XPATH,"//div[contains(@class,'regex-popup')]").is_visible()

    # Assert that the regex input field is present in the regex pop-up
    assert driver.find_element_by(By.XPATH,"//input[@name='regex']").is_enabled()

    # Assert that the Apply button is present in the regex pop-up
    assert driver.find_element_by(By.XPATH,"//button[@name='apply']").is_enabled()

    # Assert that the data labelling results are displayed after applying the regex
    assert driver.find_element_by(By.XPATH,"//div[contains(@class,'data-labelling-results')]").text.should_contain("Labelled data")

@pytest.mark.usefixtures("driver")
def test_regex_in_data_labelling():
    test_regex_in_data_labelling()
