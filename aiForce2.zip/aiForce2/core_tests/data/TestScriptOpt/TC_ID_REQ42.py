
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def test_xenius_login_page_verifies_input_details():
    # Set up test environment
    driver = webdriver.Chrome()
    driver.get("https://www.xenius.com/login")

    # Enter incorrect email and password
    email = "incorrect_email@example.com"
    password = "incorrect_password"
    driver.find_element_by_name("email").send_keys(email)
    driver.find_element_by_name("password").send_keys(password)
    driver.find_element_by_name("login").click()

    # Verify error message is displayed
    error_message = driver.find_element_by_class_name("error-message")
    assert error_message.text == "Incorrect email or password."

    # Teardown test environment
    driver.quit()

# Summary of the test
test_xenius_login_page_verifies_input_details - Tests that the Xenius login page verifies the input details provided by the user and displays an error message in case of incorrect details.
