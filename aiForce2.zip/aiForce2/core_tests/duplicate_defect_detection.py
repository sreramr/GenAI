from langchain.chat_models import AzureChatOpenAI
from core.usecases.testing.duplicate_defect_detection.main import DuplicateDefectDetection
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import DocArrayInMemorySearch
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
from core.data_store.utils import load_document_to_vector_store
from langchain.llms import CTransformers
from dotenv import load_dotenv
import os

load_dotenv()

CurrentDir = os.path.abspath(os.getcwd())
AssetsDir = os.path.join(CurrentDir, "Assets")
ModelsDir = os.path.join(AssetsDir, "Models")

#output_dir = "core_tests/results/change_impact_analysis"
# model_name = "llama-2-7b-chat.Q4_K_M.gguf"
model_name = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"
def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=3500,
    #     temperature=0.3,
    #     openai_api_type='azure'
        
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})

    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )

    embeddings = OpenAIEmbeddings(
        deployment='embedding',        
        chunk_size=15,
        model='embedding',
        openai_api_type='azure'
    )
    
    defect_db = DocArrayInMemorySearch.from_params(embedding=embeddings)

    defect_file = r"core_tests\data\DuplicateDefect\DefectInfo_meta_v1.xlsx"
    ids = load_document_to_vector_store(
        vector_store=defect_db,
        llm=llm,
        data_type="defect",
        input_file=defect_file
    )

    # print(">>>>>>>>>>>",ids)
    # input_folder_path = r"C:\python_ws\Modular_Impl\codebase\server\core_tests\data\DuplicateDefect"
    
    
    usecase = DuplicateDefectDetection(
                llm=llm,
                defect_file = defect_file,
                defect_db=defect_db,
                similarity_threshold=0.95,
                total_docs = len(ids)
            )


    usecase.execute_and_save_result(output_dir="Assets", report_format="md") 



if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    print("\n\nDuplicate Detection Started\n\n")
    result = execute_usecase()
    print("\n\nDuplicate Detection Ended\n\n")
