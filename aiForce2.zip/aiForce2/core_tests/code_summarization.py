import os
import shutil

from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.llms import CTransformers
from langchain.schema.document import Document
from langchain.vectorstores import Chroma, OpenSearchVectorSearch

from core.data.connectors.tfs import TFSConnector
from core.usecases.development.code_summarization.main import CodeSummarizer
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel

CurrentDir = os.path.abspath(os.getcwd())
AssetsDir = os.path.join(CurrentDir, "Assets")
ModelsDir = os.path.join(AssetsDir, "Models")

tfs_code_dir = "graviton/Xenius/server/Utility"
code_dir = "core_tests/data/tfs_files"

model_name = "llama-2-7b-chat.Q4_K_M.gguf"
# model_name = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"

def execute_usecase():
    # Get code files from TFS
    tfs_connector = TFSConnector(
        url=os.getenv("AZURE_DEVOPS_URL"),
        pat=os.getenv("AZURE_DEVOPS_PAT"),
        project="DataEngineering",
        repository="DataEngineering",
    )

    if os.path.exists(code_dir):
        shutil.rmtree(code_dir)
    os.makedirs(code_dir, exist_ok=True)

    # tfs_connector.download_code_file_dir(dir=tfs_code_dir, target_dir=code_dir)
    tfs_connector.download_file(path=tfs_code_dir + "/adls_utility.py", target_filepath=code_dir + "/adls_utility.py")

    # Summarize code files

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})


    # llm = CTransformers(
    #     model=os.path.join(ModelsDir,model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )

    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    summarizer = CodeSummarizer(
        llm=llm,
        code_dir=code_dir,
    )

    result = summarizer.get_file_level_summaries()
    for r in result:
        print(r.filename)
        print("-"*50)
        print(r.summary)
        print("="*50)

    # Store summaries in OpenSearch
    embeddings = OpenAIEmbeddings(model="embedding")

    vector_db = Chroma(embedding_function=embeddings)

    # vector_db = OpenSearchVectorSearch(
    #     opensearch_url="http://localhost:9200",
    #     index_name="code_summarization",
    #     embedding_function=embeddings
    # )

    summary_docs = [Document(
        page_content=summary.summary,
        metadata={"filename": summary.filename}
    ) for summary in result]

    ids = vector_db.add_documents(summary_docs)


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()
