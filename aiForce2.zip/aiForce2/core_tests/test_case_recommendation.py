from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from core.usecases.testing.test_case_recommendation.main import TestCaseRecommendation
from core.data_store.utils import load_document_to_vector_store
from langchain.vectorstores import DocArrayInMemorySearch
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
import os
from dotenv import load_dotenv

load_dotenv()

def execute_usecase():
    print("Test Case Recommendation... core_tests")
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})
    

    embeddings = OpenAIEmbeddings(
        deployment='embedding',        
        chunk_size=15,
        model='embedding',
        openai_api_type='azure'
    )

    testcase_db = DocArrayInMemorySearch.from_params(embedding=embeddings)

    input_testcase_csv_path = r"core_tests\data\TestCaseRecommendation\TestCaseInfo.csv"
    ids = load_document_to_vector_store(
        vector_store=testcase_db,
        llm=llm,
        data_type="testcase_recommendation",
        input_file=input_testcase_csv_path
    )

    input_defect_csv_path = r"core_tests\data\TestCaseRecommendation\Defects_Info.csv"
    

    usecase = TestCaseRecommendation(
        llm=llm,
        testcase_db= testcase_db,
        input_defect_csv_path=input_defect_csv_path,
        input_testcase_csv_path=input_testcase_csv_path,
        similarity_threshold=0.8
    )

    try:
        usecase.execute_and_save_result(output_dir="Assets", report_format="md")
    except Exception as e:
        print(f"Results Saving Failed...{str(e)}")
        pass


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()
