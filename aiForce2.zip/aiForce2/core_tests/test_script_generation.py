from langchain.chat_models import AzureChatOpenAI
from core.usecases.testing.test_script_generation import TestScriptGenerator
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
import os
from dotenv import load_dotenv

load_dotenv()

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=3000,
    #     temperature=0.1
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})


    input_folder_path = r"core_tests\data\TestScriptGeneration"
    llm_guard_run = False

    tsg = TestScriptGenerator(
        llm=llm,
        input_folder_path=input_folder_path,
        api_filename="",
        req_filename="",
        coding_guideline_filename="",
        additional_requirements="",
        llm_guard_run=llm_guard_run,
        model_name="",
        MAX_TOKENS=3000
    )

    tsg.execute_and_save_result(language="powershell", framework="None", output_dir="Assets/TSGM", report_format="md")

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()