from langchain.chat_models import AzureChatOpenAI
from core.usecases.testing.test_script_updation.main import TestScriptUpdation
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import DocArrayInMemorySearch
from core.data_store.utils import load_document_to_vector_store
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
import os
from dotenv import load_dotenv

load_dotenv()

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=3500,
    #     temperature=0.3,
    #     openai_api_type='azure'
        
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})

    embeddings = OpenAIEmbeddings(
        deployment='embedding',        
        chunk_size=15,
        model='embedding',
        openai_api_type='azure'
    )
    
    script_db = DocArrayInMemorySearch.from_params(embedding=embeddings)

    script_dir = r"core_tests\data\Test Script Updation\TestScriptsForReq"
    ids = load_document_to_vector_store(
        vector_store=script_db,
        llm=llm,
        data_type="script",
        input_file=script_dir
    )
    
        
    input_folder_path = r"core_tests\data\Test Script Updation"
    
    
    usecase = TestScriptUpdation(
                llm=llm,
                input_dir=input_folder_path,
                mapping="no",
                similarity_score=0.80,
                model_name="OpenAI",
                extra_prompt_info="",
                scripts_db=script_db
            )

    
    usecase.execute_and_save_result(output_dir="Assets", report_format="md")  # saves result
    


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    print("\n\Test Script Updation Started\n\n")
    result = execute_usecase()
    print("\n\nTest Script Updation Ended\n\n")
