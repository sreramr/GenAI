from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings, HuggingFaceEmbeddings
from langchain.llms import CTransformers
from core.usecases.testing.test_case_grouping.main import TestCaseGrouping
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
from dotenv import load_dotenv
import os
load_dotenv()

def execute_usecase():
    print("Test Case Grouping... core_tests")
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})
    

    CurrentDir = os.path.abspath(os.getcwd())
    AssetsDir = os.path.join(CurrentDir, "Assets")
    ModelsDir = os.path.join(AssetsDir, "Models")
    model_name = "llama-2-7b-chat.Q4_K_M.gguf"
    # llm = CTransformers(
    #     model=os.path.join(ModelsDir, model_name),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )

    embeddings = OpenAIEmbeddings(
        deployment='embedding',
        chunk_size=15
    )
    # ModelName = "multi-qa-MiniLM-L6-cos-v1"
    # embeddings = HuggingFaceEmbeddings(model_name=os.path.join(ModelsDir, ModelName))

    input_csv_file = r"core_tests\data\Test Case Grouping\TestCaseInfo__NT_TCG_18-12-2023_11-20-16.csv"

    usecase = TestCaseGrouping(
        llm=llm,
        testcase_db = embeddings,
        input_csv_path = input_csv_file,
        model_name = "Azure Open AI GPT 3.5 Turbo",
        similarity_threshold=0.9
    )

    try:
        usecase.execute_and_save_result(output_dir="Assets", report_format="md")
    except Exception as e:
        print(f"Results Saving Failed...{str(e)}")
        pass


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()
