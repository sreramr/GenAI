import os
import shutil

from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings, HuggingFaceEmbeddings
from langchain.vectorstores import OpenSearchVectorSearch, Chroma, ElasticsearchStore
from langchain.llms import CTransformers

from core.data.connectors.tfs import TFSConnector
from core.usecases.development.code_generation import CodeGenerator
from core.data_store.utils import load_document_to_vector_store
from core.utilts import common_utility as common_utils
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel

CurrentDir = os.path.abspath(os.getcwd())
AssetsDir = os.path.join(CurrentDir, "Assets")
ModelsDir = os.path.join(AssetsDir, "Models")

language = 'Python'
# Root input folder path [Root folder contains api, req, guideline file]
input_folder_path = r"core_tests\data\CodeGeneration"
api_filename = "api_document.txt" # API file name [Optional]
req_filename = "requirements.txt" # Requirement file name [Either requirement file/additional_requirements]
guideline_filename = None # Guidelines file name [Optional]
additional_requirements = "" # (str) Additional requirements [Either requirement file/additional_requirements]
llm_guard_run = False # LLM Guard Check 
# EXEC LIST : Based on values running below additional section
EXEC_LIST = {
                "is_generate_unittest" : True,
                "is_generate_technicaldocs" : True,
                "is_generate_dockersteps" : True
            }
output_dir = "core_tests/results/code_generation"
DEFAULT_EXTENSION = "txt"

# model_name = "llama-2-7b-chat.Q4_K_M.gguf"
model_name = "mistral-7b-instruct-v0.2.Q4_K_M.gguf"

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=3500,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})


    # llm = CTransformers(
    #     model=os.path.join(ModelsDir,model_name"),
    #     config={
    #         "temperature": 0.3,
    #         "max_new_tokens": 2000,
    #         "context_length": 4096,
    #     }
    # )


    embeddings = OpenAIEmbeddings(
        deployment='embedding',
        chunk_size=15
    )

    # ModelName = "multi-qa-MiniLM-L6-cos-v1"
    # embeddings = HuggingFaceEmbeddings(model_name=os.path.join(ModelsDir, ModelName))

    api_db = OpenSearchVectorSearch(
        opensearch_url="http://localhost:9200",
        index_name="cg_python",
        embedding_function=embeddings,
    )

    # api_db = ElasticsearchStore(
    #     es_url="http://localhost:9200",
    #     index_name="cg_python",
    #     embedding_function=embeddings,
    # )
    
    # CHROMA_DB_PERSIST_DIR =  "Assets/chroma_db"
    # api_db = Chroma(persist_directory=CHROMA_DB_PERSIST_DIR,
    #             collection_name="cg_python_api",
    #             embedding_function=embeddings)

    if api_filename != None:
        api_file_path = common_utils.find_file_path(input_folder_path, api_filename)
        ids = load_document_to_vector_store(vector_store=api_db, llm=llm, 
                                                data_type="api", input_file=api_file_path, 
                                                regex_pattern = r'#{5,}')

   
    code_gen = CodeGenerator(
                llm=llm,
                language = language,
                input_folder_path = input_folder_path,
                api_filename = api_filename,
                req_filename = req_filename,
                guideline_filename = guideline_filename,
                additional_requirements = additional_requirements,
                api_db = api_db,
                llm_guard_run = llm_guard_run,
                exec_list = EXEC_LIST
            )
   
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    result = code_gen.execute_and_save_result(output_dir=output_dir)  # saves result

    for detail_section in result.report.detailed_report_list:
        common_utils.save_output_file(output_dir, detail_section.title.strip(), DEFAULT_EXTENSION, detail_section.content)
    return result


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    print("\n\nCode Generation Started\n\n")
    result = execute_usecase()
    data = result.report
    # print(data)
    print("\n\nCode Generation Ended\n\n")
