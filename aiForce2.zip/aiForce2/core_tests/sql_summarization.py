import os

from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings, HuggingFaceEmbeddings
from langchain.vectorstores import OpenSearchVectorSearch, Chroma, ElasticsearchStore
from langchain.schema.document import Document
from langchain.llms import CTransformers
from core.utilts.sagemaker_endpoint import SagemakerEndpointLlamaChatModel
from core.usecases.development.sql_summarization.main import SqlSummarizer

CurrentDir = os.path.abspath(os.getcwd())
AssetsDir = os.path.join(CurrentDir, "Assets")
ModelsDir = os.path.join(AssetsDir, "Models")

database_url = "sqlite:///core_tests/data/SQLSummarization/DQCCLoud.db"
output_dir = "core_tests/results/sql_summarization"

def execute_usecase():
    # llm = AzureChatOpenAI(
    #     deployment_name='chat-model',
    #     max_tokens=2000,
    #     temperature=0.3
    # )

    llm = SagemakerEndpointLlamaChatModel(
            endpoint_name=os.getenv('endpoint_name'),
            client_kwargs= {
            "region_name":os.getenv('region_name'),
            "aws_access_key_id": os.getenv('aws_access_key_id'),
            "aws_secret_access_key": os.getenv('aws_secret_access_key')},
            model_kwargs={"temperature": 0.8, "max_new_tokens": 2000})


    usecase = SqlSummarizer(
        llm=llm,
        database_url=database_url
    )

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    result = usecase.execute_and_save_result(output_dir=output_dir)  # saves result

    # Result saving into vector db code start from here
    embeddings = OpenAIEmbeddings(
        deployment='embedding'
    )

    # ModelName = "multi-qa-MiniLM-L6-cos-v1"
    # embeddings = HuggingFaceEmbeddings(model_name=os.path.join(ModelsDir, ModelName))

    # vector_db = OpenSearchVectorSearch(
    #     opensearch_url="http://localhost:9200",
    #     index_name="sql_summarization",
    #     embedding_function=embeddings,
    # )

    # vector_db = ElasticsearchStore(
    #     es_url="http://localhost:9200",
    #     index_name="sql_summarization",
    #     embedding_function=embeddings,
    # )
    
    CHROMA_DB_PERSIST_DIR =  "Assets/chroma_db"
    vector_db = Chroma(persist_directory=CHROMA_DB_PERSIST_DIR,
                collection_name="sql_summarization",
                embedding_function=embeddings)

    summary_docs = [Document(
        page_content=summary.content,
        metadata={"filename": summary.title}
    ) for summary in result.report.detailed_report_list]

    ids = vector_db.add_documents(summary_docs)


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    result = execute_usecase()
