"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import usecase as views

urlpatterns = [
    path('get_menu_names', views.get_menu_names, name='get_menu_names'),
    path('get_ui_controls', views.get_ui_controls, name='get_ui_controls'),
    path('run_usecase', views.run_usecase, name='run_usecase'),
    path('get_execution_preview_data', views.get_execution_preview_data, name='get_execution_preview_data'),
    path('get_execution_info_data', views.get_execution_info_data, name='get_execution_info_data'),
    path('delete_execution_info', views.delete_execution_info, name='delete_execution_info'),
    path('delete_structured_data', views.delete_structured_data, name='delete_structured_data'),
    path('delete_unstructured_data', views.delete_unstructured_data, name='delete_unstructured_data'),
    path('run_usecase_fromvs', views.run_usecase_fromvs, name='run_usecase_fromvs'),
    path('download_result', views.download_result, name='download_result'),
    path('get_tfs_files_info', views.get_tfs_files_info, name='get_tfs_files_info'),
    path('get_svn_files_info', views.get_svn_files_info, name='get_svn_files_info'),
    path('get_sample_metadata', views.get_sample_metadata, name='get_sample_metadata'),
    path('view_sample_metadata', views.view_sample_metadata, name='view_sample_metadata'),
    path('get_uploaded_data', views.get_uploaded_data, name='get_uploaded_data'),
    path('run_test_usecase_from_vs', views.run_test_usecase_from_vs, name='run_test_usecase_from_vs'),
    path('test_script_optimization', views.test_script_optimization_view),
    path('test_script_updation', views.test_script_updation_view),
    # 
    path('list_source_code', views.list_usecases_source_view),
    path('download_source_code', views.download_usecases_source_view)
]

# localhost:8000/usecase/run_usecase
