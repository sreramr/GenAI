"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views.organization import OrganizationApi as views
from API.views import organization as organization

urlpatterns = [
    path('', views.as_view(), name='organizations'),
    path('<int:org_id>/', views.as_view(), name='organization_specific'),
    path('check_domain_exists', organization.check_domain_exists, name='check_domain_exists'),
]
