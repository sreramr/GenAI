"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import conversation as views

urlpatterns = [
    path('get_query_response', views.get_query_response, name='get_query_response'),
    path('get_defect_support_result', views.get_defect_support_result, name='get_defect_support_result'),
    path('get_query_QnA', views.get_query_QnA, name='get_query_QnA')
]

# localhost:8000/usecase/run_usecase
