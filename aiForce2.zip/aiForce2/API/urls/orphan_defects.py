"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import orphan_defects as views

urlpatterns = [
    path('get_orphan_defects_data', views.get_orphan_defects_data, name='get_orphan_defects_data'),
    path('get_feature_testcases', views.get_feature_testcases, name='get_feature_testcases'),
    path('get_feature_internal_defects', views.get_feature_internal_defects, name='get_feature_internal_defects'),
    path('get_feature_internal_orphans', views.get_feature_internal_orphans, name='get_feature_internal_orphans'),
    path('get_feature_crds', views.get_feature_crds, name='get_feature_crds'),
    path('get_feature_crds_orphan', views.get_feature_crds_orphan, name='get_feature_crds_orphan')
]

# localhost:8000/usecase/run_usecase
