"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import search as views

urlpatterns = [
    path('get_query_response', views.get_query_response, name='get_query_response'),
    path('get_defect_query_response', views.get_defect_query_response, name='get_defect_query_response'),
    path('get_functions_list', views.get_functions_list, name='get_functions_list'),
    path('get_py_file', views.get_py_file, name='get_py_file'),
    path('get_defect_fix_suggestion_for_lead', views.get_defect_fix_suggestion_for_lead,
         name='get_defect_fix_suggestion_for_lead'),
    path('get_testcase_query_response', views.get_testcase_query_response, name='get_testcase_query_response'),
    path('post_comment_to_TFS', views.post_comment_to_TFS, name='post_comment_to_TFS'),
    path('post_related_content_to_TFS', views.post_related_content_to_TFS, name='post_related_content_to_TFS'),
    path('add_related_work_to_testcase', views.add_related_work_to_testcase, name='add_related_work_to_testcase'),
    path('suggest_defect_query_response', views.suggest_defect_query_response, name='suggest_defect_query_response'),
]

# localhost:8000/usecase/run_usecase
