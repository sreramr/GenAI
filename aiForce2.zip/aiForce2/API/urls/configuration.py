"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import configuration as views

urlpatterns = [
    path('check_llmconfiguration_exists', views.check_llmconfiguration_exists, name='check_llmconfiguration_exists'),
    path('save_llmconfiguration', views.save_llmconfiguration, name='save_llmconfiguration'),
    path('get_llmconfiguration', views.get_llmconfiguration, name='get_llmconfiguration'),
    
    path('calculate_breakeven', views.calculate_breakeven, name='calculate_breakeven'),
    path('save_effortweightage', views.save_effortweightage, name='save_effortweightage'),
    path('restore_effortweightage', views.restore_effortweightage, name='restore_effortweightage'),
   
    path('save_security_config', views.save_security_config, name='save_security_config'),
    path('get_security_config', views.get_security_config, name='get_security_config'),
    path('save_tfs_config', views.save_tfs_config, name='save_tfs_config'),
    path('get_tfs_config', views.get_tfs_config, name='get_tfs_config'),
    path('save_keywords', views.save_keywords, name='save_keywords'),
    path('get_keywords', views.get_keywords, name='get_keywords'),
    
    path('check_emb_configuration_exists', views.check_emb_configuration_exists, name='check_emb_configuration_exists'),
    path('save_embedding_configuration', views.save_embedding_configuration, name='save_embedding_configuration'),
    path('get_embedding_configuration', views.get_embedding_configuration, name='get_embedding_configuration'),

    path('list_local_models', views.list_local_models_view),
]

