"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import model_run as views

urlpatterns = [
    path('run_model', views.run_model, name='run_model'),
    path('train_model', views.train_model, name='train_model'),
    path('sync_execution_jobs', views.sync_execution_jobs, name='sync_execution_jobs'),
    path('get_status', views.get_status, name='get_status')
]
