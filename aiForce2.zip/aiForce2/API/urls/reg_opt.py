"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import reg_opt as views

urlpatterns = [
    path('get_project_release_builds', views.get_project_release_builds, name='get_project_release_builds'),
    path('get_project_defects_by_build', views.get_project_defects_by_build, name='get_project_defects_by_build'),
    path('get_project_features', views.get_project_features, name='get_project_features'),
    path('get_project_environments', views.get_project_environments, name='get_project_environments'),
    path('get_recommended_testcases', views.get_recommended_testcases, name='get_recommended_testcases'),
    path('get_testcase_run_environment', views.get_testcase_run_environment, name='get_testcase_run_environment'),
    path('add_environment', views.add_environment, name='add_environment'),
    path('get_environment_for_unique_testcases', views.get_environment_for_unique_testcases,
         name='get_environment_for_unique_testcases'),
    path('get_optimized_testcases', views.get_optimized_testcases, name='get_optimized_testcases'),

    # Modeling API to store records in database from the uploaded data
    path('analyze_golden_testcases', views.analyze_golden_testcases, name='analyze_golden_testcases'),
    path('analyze_environment_testcases', views.analyze_environment_testcases, name='analyze_environment_testcases'),
    path('analyze_rag_testcases', views.analyze_rag_testcases, name='analyze_rag_testcases'),
    path('analyze_orphan_defects_and_mapping', views.analyze_orphan_defects_and_mapping,
         name='analyze_orphan_defects_and_mapping'),
    path('analyze_change_based_testcases', views.analyze_change_based_testcases, name='analyze_change_based_testcases'),
    path('map_feature_defects', views.map_feature_defects, name='map_feature_defects'),
    path('map_feature_testcases', views.map_feature_testcases, name='map_feature_testcases'),
    path('map_defect_with_feature', views.map_defect_with_feature, name='map_defect_with_feature'),
]

# localhost:8000/usecase/run_usecase
