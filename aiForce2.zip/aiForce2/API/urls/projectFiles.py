"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views.projectFiles import ProjectFilesApi as views, upload_data_from_usecase

urlpatterns = [
    path('', views.as_view(), name='projects_files'),
    path('<int:project_file_id>/', views.as_view(), name='project_file_specific'),
    path('load_from_usecase/', upload_data_from_usecase)
]
