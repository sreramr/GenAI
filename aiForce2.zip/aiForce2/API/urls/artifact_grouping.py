"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import artifact_grouping as views

urlpatterns = [
    path("get_defects_data", views.get_defects_data, name="get_defects_data"),
    path("get_testcases_Data", views.get_testcases_data, name="get_testcases_Data"),
]
