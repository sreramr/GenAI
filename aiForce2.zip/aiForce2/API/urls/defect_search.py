"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import defect_search as views
from API.views.defect_search import get_defect_filter_options, get_defect_filter_result

urlpatterns = [
    path('get_defects_details', views.get_defects_details, name='get_defects_details'),
    path('get_defect_localize', views.get_defect_localize, name='get_defect_localize'),
    path('filter_options/', get_defect_filter_options),
    path('filter_result/', get_defect_filter_result),
    path('search_summarization_llm', views.search_summarization_llm, name="search_summarization_llm")
]

