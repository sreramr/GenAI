"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import feature as views

urlpatterns = [
    path('create_feature', views.create_feature, name='create_feature'),
    path('update_feature', views.update_feature, name='update_feature'),
    path('delete_feature/<int:feature_id>', views.delete_feature, name='delete_feature'),
    path('list_feature', views.list_feature, name='list_feature'),
    path('get_feature_mapping_data', views.get_feature_mapping_data, name='get_feature_mapping_data'),
    path('get_feature_tagging_data', views.get_feature_tagging_data, name='get_feature_tagging_data'),
    path('get_feature_testcases_data', views.get_feature_testcases_data, name='get_feature_testcases_data'),
    path('get_feature_defects_data', views.get_feature_defects_data, name='get_feature_defects_data'),
    path('get_feature_sourcecode_data', views.get_feature_sourcecode_data, name='get_feature_sourcecode_data'),
    path('get_parent_feature_list', views.get_parent_feature_list, name='get_parent_feature_list'),
]

# localhost:8000/usecase/run_usecase
