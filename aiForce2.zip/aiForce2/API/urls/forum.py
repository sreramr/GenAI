"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import forum as views
# from API.views.forum import get_query_details

urlpatterns = [
    path('get_query_details', views.get_query_details, name='get_query_details'),
    path('get_summary', views.get_summary, name='get_summary')
]

