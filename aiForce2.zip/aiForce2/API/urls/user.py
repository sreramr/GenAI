"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views.user import UserManagementApi as views
from API.views import user as user

urlpatterns = [
    path("", views.as_view(), name="users"),
    path("<int:user_id>/", views.as_view(), name="user_specific"),
    #path('check_loginName_exists', user.check_loginName_exists, name='check_loginName_exists'),
    path('check_exists', user.check_exists, name='check_exists'),
    path('login_exists', user.login_exists, name='login_exists'),
    path('email_exists', user.email_exists, name='email_exists'),
    #path('check_Email_Login_exists_url', user.check_Email_Login_exists_url, name='check_Email_Login_exists_url'),
]
