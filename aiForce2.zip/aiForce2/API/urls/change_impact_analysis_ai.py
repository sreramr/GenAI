"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import change_impact_analysis_ai as views

urlpatterns = [
    path('get_project_release_builds', views.get_project_release_builds, name='get_project_release_builds'),
    path('fetch_files_builds', views.fetch_files_builds, name='fetch_files_builds'),
    path('fetch_files_defects', views.fetch_files_defects, name='fetch_files_defects'),
    path('search_defects', views.search_defects, name='search_defects'),
    path('search_files', views.search_files, name='search_files'),
    path('getdefects_list', views.getdefects_list, name='getdefects_list'),
    path('getfiles_list', views.getfiles_list, name='getfiles_list'),
    path('getanalyze_changes', views.getanalyze_changes, name='getanalyze_changes'),
]


