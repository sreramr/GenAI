"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import data_management as views

urlpatterns = [
    path('upload_data', views.upload_data, name='upload_data'),
    path('get_unstructured_data_list', views.get_unstructured_data_list, name='get_unstructured_data_list'),
    path('tfs_list_data', views.list_tfs_data),
    path('push_suggested_testcases', views.push_suggested_testcases),
    path('push_testscripts', views.push_testscripts),
    path('fetch_suggested_testcases', views.fetch_suggested_testcases),
    path('store_suggested_testcases_centralized', views.store_suggested_testcases_centralized),
    path('push_suggested_testcases_TFS', views.push_suggested_testcases_TFS),
    path('push_suggested_opti_testcases_TFS', views.push_suggested_opti_testcases_TFS), 
    path('store_suggested_defects_centralized', views.store_suggested_defects_centralized),
    path('push_suggested_defects_TFS', views.push_suggested_defects_TFS),
    path('map_defects_TFS', views.map_defects_TFS),
    path('store_suggested_testcasegroup_centralized', views.store_suggested_testcasegroup_centralized),
    path('push_suggested_testcasesgroup_TFS', views.push_suggested_testcasesgroup_TFS),  
    path('check_job_name', views.check_job_name)
]
