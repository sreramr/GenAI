"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views.project import ProjectView as views
from API.views.project import get_default_project, get_versions

urlpatterns = [
    path('', views.as_view(), name='projects'),
    path('<int:project_id>/', views.as_view(), name='project_specific'),
    path('get_default_project', get_default_project, name='default_project'),
    path('get_versions', get_versions, name='get_versions')
]
