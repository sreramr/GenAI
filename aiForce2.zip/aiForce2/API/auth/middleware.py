from django.http import HttpResponseForbidden


class AuthorizationMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        print("Authorization Middleware")
        return HttpResponseForbidden('Not authorized')
        # if request.path.startswith('/auth/'):
        #     # Allow access to '/auth/' URLs without authorization
        #     return self.get_response(request)
        #
        #     # Implement your authorization logic here
        # authorized = False
        # # Check if the user is authorized
        # if authorized:
        #     return self.get_response(request)
        # else:
        #     return HttpResponseForbidden('Not authorized')
