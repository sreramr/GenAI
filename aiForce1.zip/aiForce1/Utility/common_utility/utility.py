"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os
import json
from pandas import DataFrame
import configparser
import shutil
import ast
import astor
import tokenize
import io
import charset_normalizer
import tiktoken
import csv
import pandas as pd
import requests
import base64
import numpy as np
import chardet
from datetime import datetime
from langchain.text_splitter import (
    RecursiveCharacterTextSplitter,
    Language,
)
from langchain.document_loaders import UnstructuredExcelLoader
from pdfminer.converter import TextConverter
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import textwrap

from django.http import HttpResponse, FileResponse
from django.core.files import File

from Utility.db_utility import db_utility as db_utils
from Utility.common_utility.docx_renderer import DocxRenderer
from markdown_it import MarkdownIt
from markdown_it.token import Token
from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT, WD_LINE_SPACING
from docx.shared import Pt
import re
import svn.remote
from requests.auth import HTTPBasicAuth
import docx
from Utility.common_utility.vector_store.es_db import search_similar_codes
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from Utility.usecase_utility.llm_call import llm_call
from ast import literal_eval

### Configured the ROOt Path
cwdPath = os.path.abspath(os.getcwd())

project_rootpath = os.path.join(cwdPath, "Projects")
usecase_rootpath = os.path.join(cwdPath, "UsecaseResult")
Result_rootpath = os.path.join(cwdPath, "Result")

Assets_rootpath = os.path.join(cwdPath, "Assets")
DefaultSampleDataPath = os.path.join(Assets_rootpath, "DefaultSampleData")
UploadData_rootpath = os.path.join(Assets_rootpath, "UploadedData")
Logs_rootpath = os.path.join(Assets_rootpath, "Logs")
Result_rootpath = os.path.join(Assets_rootpath, "Result")

config_path = os.path.join(cwdPath, "config")


### Create Directory IF NOT EXISTS
def createDirectory(create_path):
    if not os.path.exists(create_path):
        os.makedirs(create_path)
    return True


### Get the Directory Name From Path
def get_folder_path(content):
    last_index = content.rfind('/')
    if last_index != -1:
        dir_name = content[:last_index]
        return dir_name

    ### Handle the Uploaded Directory


def handleUploadDirectory(uploaded_files, usecase_name, job_name, request):
    upload_root_path = os.path.join(UploadData_rootpath, usecase_name, job_name)
    createDirectory(upload_root_path)
    for file in uploaded_files:
        file_path = request.POST.get(f'path_{file.name}_{file.size}')
        upload_form_path = get_folder_path(file_path)
        handle_uploaded_file(upload_root_path, upload_form_path, file=file)
    return upload_form_path.split('/')[0]


### Save the uploaded files into Local Folder
def handle_uploaded_file(upload_root_path, upload_form_path, file):
    try:
        save_path = os.path.join(upload_root_path, upload_form_path)
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        with open(os.path.join(save_path, file.name), 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
            return os.path.join(save_path, file.name)
    except Exception as e:
        print("Upload Exception :>>", str(e))


def generate_jobname(exec_start_time, usecase_name):
    job_postfix_name = exec_start_time.strftime("%Y%m%d%H%M%S")
    if usecase_name == "Security Assessment":
        uc = "VA"
    elif usecase_name == "Code Generation" or usecase_name == "Code Generation V1":
        uc = "CG"
    elif usecase_name == "Code Summarization":
        uc = "CS"
    elif usecase_name == "Code Clone Detection":
        uc = "CC"
    elif usecase_name == "Code Refactoring":
        uc = "CR"
    elif usecase_name == "SQL Generation":
        uc = "SG"
    elif usecase_name == "SQL Summarization":
        uc = "SS"
    elif usecase_name == "Change Impact Analysis":
        uc = "CIA"
    elif usecase_name == "Code Migration":
        uc = "CM"
    elif usecase_name == "Unit Test Case Generation":
        uc = "UTCG"
    # Testing Related usecases Start from here
    elif usecase_name == "Test Script Generation":
        uc = "TSG"
    elif usecase_name == "Test Case Generation":
        uc = "TCG"
    elif usecase_name == "Test Case Grouping":
        uc = "TCGR"
    elif usecase_name == "Duplicate Defect Detection":
        uc = "DD"
    elif usecase_name == "Test Case Optimization":
        uc = "TCO"
    elif usecase_name == "Orphan Defect Detection":
        uc = "ODD"
    elif usecase_name == "Test Suite Failure":
        uc = "TSF"
    elif usecase_name == "Test Case Recommendation":
        uc = "TCR"
    elif usecase_name == "Data Generation":
        uc = "DG"
    elif usecase_name == "Test Script Optimization":
        uc = "TSO"
    elif usecase_name == "Test Case Standardization":
        uc = "TCS"
    elif usecase_name == "Test Script Updation":
        uc = "TSU"
    else:
        uc = "TEST"

    job_name = "UC_" + uc + "_" + str(job_postfix_name)
    return job_name


### Create the LOG FILE IF NOT EXISTS
# DELETE the content IF EXISTS
def createLOGFile(log_name):
    logs_path = os.path.join(Logs_rootpath, log_name)
    with open(logs_path, "w") as file:
        pass

    ### Updating the LOGS


def updatelog(log_name, log_content, date_display):
    logs_path = os.path.join(Logs_rootpath, log_name)
    current_date_time = datetime.now()
    formatted_date_time = current_date_time.strftime("%d-%m-%Y %H:%M:%S")
    if date_display == True:
        formatted_line = f"{formatted_date_time}   {log_content}"
    else:
        formatted_line = f"{log_content}"

    with open(logs_path, "r") as file:
        content = file.read()

    updated_content = content + formatted_line + "\n"
    with open(logs_path, "w") as file:
        file.write(updated_content)

    ### Generating the Dynamic Prompt


def generatePrompt(form_data, prompt_values, additional_info, input_control, input_data):
    FinalPrompt = ""
    SystemRole = ""
    summary_id = additional_info['TYPE'] if "TYPE" in additional_info else 0
    input_ids = list(input_control.keys())
    summary_type = ''.join(form_data[input_id] if input_id == summary_id else "" for input_id in input_ids)
    for (input_id, input_type) in input_control.items():
        system_role_id = additional_info['SYSTEM_ROLE'] if "SYSTEM_ROLE" in additional_info else 0
        scanner_id = additional_info['SCANNER'] if "SCANNER" in additional_info else 0
        summary_id = additional_info['TYPE'] if "TYPE" in additional_info else 0
        if system_role_id == input_id:
            selected_option = form_data[input_id] if input_id in form_data else ""
            selected_input_data = input_data[input_id] if input_id in input_data else ""
            indexvalue = selected_input_data.index(selected_option)
            selected_prompt_value = prompt_values[input_id] if input_id in prompt_values else ""
            SystemRole = selected_prompt_value[indexvalue]
        elif scanner_id == input_id or summary_id == input_id:
            pass
        else:
            if input_type == "text_area":
                print(f'summary_type: {summary_type}')
                if summary_type == "File":
                    FinalPrompt += prompt_values[input_id] if input_id in prompt_values and input_id != '5' else ""
                    FinalPrompt += "\n"
                    FinalPrompt += form_data[input_id] if input_id in form_data and input_id != '5' else ""
                    FinalPrompt += "\n\n"
                elif summary_type == "Function":
                    FinalPrompt += prompt_values[input_id] if input_id in prompt_values and input_id != '2' else ""
                    FinalPrompt += "\n"
                    FinalPrompt += form_data[input_id] if input_id in form_data and input_id != '2' else ""
                    FinalPrompt += "\n\n"
                else:
                    FinalPrompt += prompt_values[input_id] if input_id in prompt_values else ""
                    FinalPrompt += "\n"
                    FinalPrompt += form_data[input_id] if input_id in form_data else ""
                    FinalPrompt += "\n\n"
            else:
                selected_option = form_data[input_id] if input_id in form_data else ""
                selected_input_data = input_data[input_id] if input_id in input_data else ""
                indexvalue = selected_input_data.index(selected_option)
                selected_prompt_value = prompt_values[input_id] if input_id in prompt_values else ""
                FinalPrompt += selected_prompt_value[indexvalue] + " "

    print("---------- GENERATED DYNAMIC PROMPT *START* -----------")
    # print("SystemRole :>>", SystemRole)
    # print("FinalPrompt :>>", FinalPrompt)
    print("---------- GENERATED DYNAMIC PROMPT *END* -----------")
    return SystemRole, FinalPrompt


### Generate Prompt Main Function
def GeneratePromptFromInput(usecase_name, form_data, log_name):
    updatelog(log_name, "Prompt Generating...", True)
    response = db_utils.get_promptValue(usecase_name)
    promptValue = response["data"][0]
    prompt_values = json.loads(promptValue["prompt_value"].replace('\'', '\"'))
    additional_info = json.loads(promptValue["additional_info"].replace('\'', '\"'))
    input_control = json.loads(promptValue["input_control"].replace('\'', '\"'))
    input_data = json.loads(promptValue["input_data"].replace('\'', '\"'))
    SystemRole, FinalPrompt = generatePrompt(form_data, prompt_values, additional_info, input_control, input_data)
    updatelog(log_name, "Prompt Generated Successfully!\n", True)
    return SystemRole, FinalPrompt


### Return the List of Files from given Uploaded Directory
def read_inputdirectory(usecase_name, job_name):
    file_list = []
    input_dirpath = os.path.join(UploadData_rootpath, usecase_name, job_name)
    for root, _, files in os.walk(input_dirpath):
        for file in files:
            file_path = os.path.join(root, file)
            relative_path = os.path.relpath(file_path, input_dirpath)
            file_list.append(relative_path)
    log_content = "Total " + str(len(file_list)) + " Input Files."
    updatelog(job_name, log_content, False)
    return file_list


### Get the user entered additional prompt
def get_userinput_prompt(form_data, usecase_name):
    userinput_prompt = []
    response = db_utils.getinput_visibility_details(usecase_name)
    visibility_details = response["data"][0]
    input_visibility = json.loads(
        visibility_details["input_visibility"].replace('\'', '\"'))
    input_control = json.loads(
        visibility_details["input_control"].replace('\'', '\"'))
    for (input_id, visibility_status) in input_visibility.items():
        if visibility_status == "True":
            input_control_type = input_control[input_id]
            if input_control_type == "text_area":
                userinput_prompt.append(form_data[input_id].replace('\n', '<br/>'))
    final_input_prompt = "<br/><br/>".join(userinput_prompt)
    return final_input_prompt


### Get the selected model name
def get_model_name():
    # cwdPath = os.path.abspath(os.getcwd())
    # with open(os.path.join(cwdPath, "config", "config_setting.json")) as f:
    #     response = json.load(f)
    response = db_utils.get_model_name()
    if response['message'] == "Success":
        if len(response['data']) > 0:
            model_name = response['data'][0]['llm_model']
            config = response["data"][0]['config']

            # local model
            if config.get("model_path", {}).get("model", ""):
                model_name = config.get("model_path", {}).get("model", "")

            return model_name

    # print(response)
    # llm_config_file = os.path.join(config_path, "llm_config.ini")
    # config_parser = configparser.ConfigParser()
    # config_parser.read(llm_config_file)

    # selected_model = config_parser.get("DEFAULT_MODELS", "chat_model")

    # usecase_info_file = os.path.join(config_path, "usecase_info.ini")
    # config_parser.read(usecase_info_file)
    # model_name =  config_parser.get("llm_model", selected_model)
    # return model_name


### Read & Return the File Content using Job Name and File Name
def read_inputfile(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    with open(input_file_path, 'r') as file:
        file_content = file.read()
        file_size = os.path.getsize(input_file_path)
        file_name = os.path.basename(input_file_path)
        updatelog(log_name, "[" + file_name + "] File Read Successfully! \n", True)
        return file_content, file_size, file_name


### Find the Line of Code / Number of Word from Given File
def getcount(inputfile_path, count_type):
    count = 0
    try:
        with open(inputfile_path, 'r') as file:
            for line in file:
                if count_type == "LoC":  # Line of Code
                    count += 1
                elif count_type == "NoW":  # Number of Word
                    words = line.split()
                    count += len(words)
                elif count_type == "NoC":  # Number of Character
                    count += len(line)
    except Exception as ex:
        print(f"File not readable {inputfile_path}")
    return count


### Find the Line of Code/Charactor,Word and Function from Given File
def check_count(usecase_name, job_name, file_relpath, count_type):
    inputfile_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    count = 0
    if count_type == "LoC":  # Line of Code
        count = getcount(inputfile_path, count_type)
    elif count_type == "NoW":  # Number of Word
        count = getcount(inputfile_path, count_type)
    elif count_type == "NoC":  # Number of Character
        count = getcount(inputfile_path, count_type)
    elif count_type == "NoF":
        count = 0

    return count


def saveExecutionSummary(result_summary, exec_id):
    try:
        config_parser = configparser.ConfigParser()
        config_parser.read(os.path.join(config_path, "usecase_info.ini"))

        data_ = []
        for key in result_summary.keys():
            tmp_ = {}
            tmp_['execution_id'] = exec_id
            tmp_['key'] = config_parser.get("summary_title", key)
            tmp_['value'] = str(result_summary[key])
            tmp_['remarks'] = ""
            data_.append(tmp_)

        summ_df = DataFrame(data_)
        db_utils.save_df_to_db(summ_df, 'execution_summary')
        return True
    except Exception as e:
        print(str(e))
        return False


def saveExecutionDetails(log_name, execution_details: list):
    try:
        exec_id = execution_details[0].get("execution_id")
        execution_details.insert(0,
                                 {
                                     'execution_id': exec_id,
                                     'prompt': "", 'title': "",
                                     "result": "**Disclaimer: This output contains AI generated content, user is advised to review it before consumption.** \n\n\*\****Start of AI Generated Content*****"
                                 })
        execution_details.append(
            {
                'execution_id': exec_id,
                'prompt': "",
                'title': "",
                "result": "\*\****End of AI Generated Content*****"
            }
        )
        final_df = DataFrame(execution_details)
        # final_df["result"] = np.where(final_df["result"].values != '',
        #                       "***This is an AI generated content, please review before consumption***\n" +
        #                       final_df["result"],
        #                       final_df["result"])

        db_utils.save_df_to_db(final_df, 'execution_details')
        updatelog(log_name, "Job Execution Results are Saved. ", True)
        return True
    except Exception as e:
        print(str(e))
        return False


### Splitter
def count_tokens(filecontent, encoding_name="r50k_base"):
    encoding = tiktoken.get_encoding(encoding_name)
    num_tokens = len(encoding.encode(filecontent))
    return num_tokens


def code_splitter(filecontent, lang, chunk_size=5000, chunk_overlap=15):
    if lang=="CPP":
        code_splitter = RecursiveCharacterTextSplitter(separators=[ "\nvoid ","\nint ",  "\nfloat ", "\ndouble "], chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    else:
        code_splitter = RecursiveCharacterTextSplitter.from_language(language=eval(f"Language.{lang}"),
                                                                    chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    code_docs = code_splitter.create_documents([filecontent])
    return code_docs


def text_splitter(filecontent, chunk_size=15000, chunk_overlap=20):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                                   length_function=len, add_start_index=True)
    text_docs = text_splitter.create_documents([filecontent])
    return text_docs


### TESTING RELATED USECASE UTILITY FUNCTION START FROM HERE

### Read & Return the File Content using Job Name and File Name
def read_csv_row_wise(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    data_array = []
    with open(input_file_path, 'r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            row_data = []
            for cell in row:
                row_data.append(cell)
            data_array.append(row_data)
    file_size = os.path.getsize(input_file_path)
    file_name = os.path.basename(input_file_path)
    updatelog(log_name, "File Read Successfully! [" + file_name + "]\n", True)
    return data_array, file_size, file_name


### Read & Return the File Content using Job Name and File Name
def read_csv_inputfile(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    file_content = ""
    with open(input_file_path, 'r') as file:
        csv_reader = csv.reader(file)
        file_size = os.path.getsize(input_file_path)
        file_name = os.path.basename(input_file_path)
        for row in csv_reader:
            file_content = file_content + " " + row
    updatelog(log_name, "File Read Successfully! [" + file_name + "]\n", True)
    return file_content, file_size, file_name


def read_csv_file(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    file_content = pd.read_excel(input_file_path)
    file_size = os.path.getsize(input_file_path)
    file_name = os.path.basename(input_file_path)
    updatelog(log_name, "File Read Successfully! [" + file_name + "]\n", True)
    return file_content, file_size, file_name


def read_csv_file_new(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    if ".xlsx" in file_relpath:
        file_content = pd.read_excel(input_file_path)
    elif ".csv" in file_relpath:
        detected_encoding = detect_encoding(input_file_path)
        print(detect_encoding)
        file_content = pd.read_csv(input_file_path, encoding=detected_encoding)
    file_size = os.path.getsize(input_file_path)
    file_name = os.path.basename(input_file_path)
    updatelog(log_name, "File Read Successfully! [" + file_name + "]\n", True)
    return file_content, file_size, file_name


##For Orphan Defect Detection
def get_file_details(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)

    file_size = os.path.getsize(input_file_path)
    file_name = os.path.basename(input_file_path)

    updatelog(log_name, "File Read Successfully! [" + file_name + "]\n", True)
    return file_size, file_name


### Generate Prompt based on VS Code Input
def GeneratePromptFromVSInput(usecase_name, form_data, log_name):
    updatelog(log_name, "Prompt Generating...", True)
    response = db_utils.get_promptValue(usecase_name)
    promptValue = response["data"][0]
    prompt_values = json.loads(promptValue["prompt_value"].replace('\'', '\"'))
    additional_info = json.loads(promptValue["additional_info"].replace('\'', '\"'))
    input_control = json.loads(promptValue["input_control"].replace('\'', '\"'))
    input_data = json.loads(promptValue["input_data"].replace('\'', '\"'))
    visibility = json.loads(promptValue["input_visibility"].replace('\'', '\"'))
    default_value = json.loads(promptValue["default_value"].replace('\'', '\"'))

    FinalPrompt = ""
    SystemRole = ""
    for (input_id, input_type) in input_control.items():
        system_role_id = additional_info['SYSTEM_ROLE'] if "SYSTEM_ROLE" in additional_info else 0
        summary_id = additional_info['TYPE'] if "TYPE" in additional_info else 0
        scanner_id = additional_info['SCANNER'] if "SCANNER" in additional_info else 0
        if system_role_id == input_id:
            selected_option = default_value[input_id] if input_id in default_value else ""
            selected_input_data = input_data[input_id] if input_id in input_data else ""
            indexvalue = selected_input_data.index(selected_option)
            selected_prompt_value = prompt_values[input_id] if input_id in prompt_values else ""
            SystemRole = selected_prompt_value[indexvalue]
        elif scanner_id == input_id or summary_id == input_id:
            pass
        else:
            if input_type == "text_area":
                if visibility[input_id] == False:
                    FinalPrompt += prompt_values[input_id] if input_id in prompt_values else ""
                    FinalPrompt += "\n"
                    FinalPrompt += default_value[input_id] if input_id in default_value else ""
                    FinalPrompt += "\n\n"
                else:
                    FinalPrompt += form_data
                    FinalPrompt += "\n\n"
            else:
                selected_option = default_value[input_id] if input_id in default_value else ""
                selected_input_data = input_data[input_id] if input_id in input_data else ""
                indexvalue = selected_input_data.index(selected_option)
                selected_prompt_value = prompt_values[input_id] if input_id in prompt_values else ""
                FinalPrompt += selected_prompt_value[indexvalue] + " " if len(
                    selected_prompt_value) == indexvalue else ""

    updatelog(log_name, "VS Code Prompt Generated Successfully!\n", True)
    print("---------- GENERATED DYNAMIC PROMPT *START* -----------")
    # print("SystemRole :>>", SystemRole)
    # print("FinalPrompt :>>", FinalPrompt)
    print("---------- GENERATED DYNAMIC PROMPT *END* -----------")
    return SystemRole, FinalPrompt


def save_userinput_intofile(user_input, language, usecase_name, job_name):
    lang_dict = {"c": ".c", "cpp": ".cpp", "csharp": ".cs", "css": ".css", "go": ".go", 
                 "html": ".html", "java": ".java", "javascript": ".js", "javascriptreact": ".jsx", 
                 "json": ".json", "markdown": ".md", "php": ".php", "python": ".py", "ruby": ".rb", 
                 "typescript": ".ts", "xml": ".xml", "yaml": ".yaml"}
    ext = lang_dict.get(language.lower())
    file_name = job_name + ext
    upload_root_path = os.path.join(UploadData_rootpath, usecase_name, job_name)
    createDirectory(upload_root_path)
    try:
        with open(os.path.join(upload_root_path, file_name), 'wb+') as destination:
            destination.write(user_input)
            return os.path.join(upload_root_path, file_name)
    except Exception as e:
        print("Upload Exception :>>", str(e))


### Saving the content into PDF
def save_content_as_pdf(output_save_path, file_content, file_name):
    c = canvas.Canvas(output_save_path, pagesize=letter)
    c.setTitle(file_name)
    c.setFont("Helvetica", 12)

    # Set the starting coordinates, line height, and text width  
    x = 50
    y = 750
    line_height = 14
    text_width = 95
    bottom_margin = 50

    # Split the content into lines  
    lines = file_content.split("\n")

    # Write each line to the PDF with automatic line wrapping  
    for line in lines:
        # Wrap the line if it exceeds the text_width  
        wrapped_lines = textwrap.wrap(line, width=text_width)

        for wrapped_line in wrapped_lines:
            if y < bottom_margin:
                c.showPage()
                y = 750

            c.drawString(x, y, wrapped_line)
            y -= line_height

            # Add a blank line to separate paragraphs
        y -= line_height
    c.showPage()
    c.save()


def createResultFolder(usecase_name, job_name):
    output_root_path = os.path.join(Result_rootpath, usecase_name, job_name)
    createDirectory(output_root_path)


### Get the Directory Name From Path
def get_dir_path(file_relpath):
    last_index = file_relpath.rfind('\\')
    if last_index != -1:
        dir_name = file_relpath[:last_index]
        return dir_name

    ### Help to get the File Name from Path


def get_file_name(content):
    last_index = content.rfind('\\')
    if last_index != -1:
        file_name = content[last_index + 1:];
        return file_name

    # Helper function to add bold text


def add_bold_text(paragraph, text):
    run = paragraph.add_run(text)
    run.bold = True
    return run


def save_output_file(usecase_name, job_name, file_relpath, file_name, extension, file_content):
    extension = extension.replace(".","")
    final_file_name = file_name.split(".")[0] + "." + extension
    output_root_path = os.path.join(Result_rootpath, usecase_name, job_name)
    if file_relpath == "":
        final_result_rootpath = output_root_path
    else:
        dir_path = get_dir_path(file_relpath)
        final_result_rootpath = os.path.join(output_root_path, dir_path)
        createDirectory(final_result_rootpath)
    output_save_path = os.path.join(final_result_rootpath, final_file_name)

    lang_dict = {"java": "//", "py": "#", "cs": "//", "js": "//", "jsx": "//", "cpp":"//", "c":"//", "net" :"//"}
    comment_symbol = lang_dict.get(extension, "#")

    dis_head = comment_symbol+"Disclaimer: This output contains AI generated content, user is advised to review it before consumption."
    dis_top = comment_symbol+"*Start of AI Generated Content*"
    dis_end = comment_symbol+"*End of AI Generated Content*"
    disclaimer = dis_head + "\n\n" + dis_top
    if extension == "docx" or extension == "doc":
        # Option 1
        # document = Document()  
        # document.add_paragraph(file_content)  
        # document.save(output_save_path)
        # Option 2
        # renderer = DocxRenderer()  
        # md = MarkdownIt()
        # tokens = md.parse(file_content)  
        # renderer.render(tokens)  
        # renderer.doc.save(output_save_path)
        # Option 3
        doc = Document()
        disclaimer_paragraph = doc.add_paragraph()
        disclaimer_run = disclaimer_paragraph.add_run(disclaimer)
        disclaimer_run.bold = True
        # Split the response into paragraphs  
        paragraphs = file_content.split("\n")
        for paragraph_text in paragraphs:
            paragraph = doc.add_paragraph()
            paragraph.style.font.size = Pt(12)
            paragraph.space_before = Pt(0)
            paragraph.space_after = Pt(0)
            paragraph.line_spacing_rule = WD_LINE_SPACING.SINGLE
            paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT

            # Apply bold formatting to text enclosed in double asterisks (**)  
            bold_parts = re.findall(r"\*\*.*?\*\*", paragraph_text)
            if bold_parts:
                for bold_part in bold_parts:
                    # Remove the double asterisks  
                    bold_text = bold_part.strip("*")
                    paragraph_text = paragraph_text.replace(bold_part, "")

                    # Add the bold text to the paragraph  
                    add_bold_text(paragraph, bold_text)

                    # Add the remaining text to the paragraph
            paragraph.add_run(paragraph_text)

        doc_paragraph = doc.add_paragraph()
        doc_run = doc_paragraph.add_run(dis_end)
        doc_run.bold = True
        # Save the Document as a .docx file
        doc.save(output_save_path)
    elif extension == "pdf":
        save_content_as_pdf(output_save_path, file_content, file_name)
    else:
        file_content = dis_head + "\n" + dis_top + "\n\n" + file_content + "\n\n" + dis_end
        with open(output_save_path, 'w') as file:
            file.write(file_content)

        ### Delete the Directory/Sub Directory and Files

 
def delete_directory(directory_path):
    if os.path.exists(directory_path):
        try:
            shutil.rmtree(directory_path)
            return ("Directory and its contents have been deleted successfully.")
        except Exception as e:
            return (f"An error occurred while deleting the directory: {e}")
    else:
        return ("The specified directory does not exist.")


def make_archive(source, destination):
    base = os.path.basename(destination)
    name = base.split('.')[0]
    format = base.split('.')[1]
    archive_from = os.path.dirname(source)
    archive_to = os.path.basename(source.strip(os.sep))
    shutil.make_archive(name, format, archive_from, archive_to)
    shutil.move('%s.%s' % (name, format), destination)
    return "OK"


def makeresult_as_zip(usecase_name, job_name, delete_dir=True):
    zip_filepath = os.path.join(Result_rootpath, usecase_name, job_name + ".zip")
    dir_path = os.path.join(Result_rootpath, usecase_name, job_name)
    make_archive(dir_path, zip_filepath)

    if delete_dir:
        delete_directory(dir_path)


def download_resultaszip(usecase_name, job_name):
    if usecase_name == "Orphan Defect Detection" or usecase_name == "Test Case Generation" or usecase_name == "Duplicate Defect Detection" or usecase_name == "Test Case Grouping" or usecase_name == "Test Case Optimization" or usecase_name == "Data Generation":
        zip_filepath = os.path.join(Result_rootpath, usecase_name, job_name + "_Result" + ".zip")
        if not os.path.exists(zip_filepath):
            makeresult_as_zip(usecase_name, job_name + "_Result")
    else:
        zip_filepath = os.path.join(Result_rootpath, usecase_name, job_name + ".zip")
    if not os.path.exists(zip_filepath):
        response = HttpResponse()
    else:
        downloadfile_content = open(zip_filepath, 'rb')
        downloadfile = File(downloadfile_content)
        response = HttpResponse(downloadfile.read())
        response['Content-Disposition'] = 'attachment'
    return response


def excel_with_disclaimer(usecase_name, job_name, file_name, extension):
    final_file_name = file_name.split(".")[0] + "." + extension
    output_root_path = os.path.join(Result_rootpath, usecase_name)
    new_folder = os.path.join(output_root_path, job_name + "_Result")
    createDirectory(new_folder)
    output_path = os.path.join(new_folder, final_file_name)
    return output_path


def save_excel_file(usecase_name, job_name, file_relpath, file_name, extension):
    final_file_name = file_name.split(".")[0] + "." + extension
    output_root_path = os.path.join(Result_rootpath, usecase_name, job_name)
    if file_relpath == "":
        final_result_rootpath = output_root_path
    else:
        dir_path = get_dir_path(file_relpath)
        final_result_rootpath = os.path.join(output_root_path, dir_path)
        createDirectory(final_result_rootpath)
    output_save_path = os.path.join(final_result_rootpath, final_file_name)
    return output_save_path


def get_code_data_from_response(response, start_char, end_char, usecase_name, job_name, language, row):
    start_index = response.find(start_char)
    end_index = 0
    if start_index != -1:
        end_index = response.find(end_char, start_index + 3)

        if end_index != -1:
            code_str = response[start_index:end_index]
            if "```" + language in code_str:
                code_str = code_str.replace("```" + language, "")
        else:
            # If end triple backtick is not found, assume code extends to the end
            code_str = response[start_index:]
            if "```" + language in code_str:
                code_str = code_str.replace("```" + language, "")
    else:
        # In case, triple backticks are not present
        code_str = "Code not found in the expected format." + response
    file_ext = ""
    if language == "python" or language == "pyats (python based testing framework for network devices)" or language == "selenium":
        code_str = response[start_index:end_index].replace("```" + "python", "")
        file_ext = ".py"
    if language == "powershell" or language == "hcl edat (powershell based device testing)" or language == "powershell (hcl e-dat - device testing automation)":
        code_str = response[start_index:end_index].replace("```" + "powershell", "")
        file_ext = ".ps1"
    if language == "java":
        code_str = response[start_index:end_index].split('\n', 1)[1]
        # code_str = response[start_index:end_index].replace("```java", "")
        file_ext = ".java"
    if language == "jest (javascript based testing framework for web applications)":
        code_str = response[start_index:end_index].replace("```" + "javascript", "")
        file_ext = ".test.js"
    if language == "groovy" or language == "geb - spock (brower automation/web testing framework)":
        code_str = response[start_index:end_index].replace("```" + "groovy", "")
        file_ext = ".groovy"

    with open(get_resultdirectory_path(usecase_name, job_name) + "/" + "TC_ID_" + str(
            row) + file_ext, "w") as f:
        f.write(code_str)
    dis_head = "Disclaimer: This output contains AI generated content, user is advised to review it before consumption."
    dis_top = "*Start of AI Generated Content*"
    dis_end = "*End of AI Generated Content*"
    disclaimer = dis_head + "\n" + dis_top
    with open(get_resultdirectory_path(usecase_name, job_name) + "/" + "TC_ID_" + str(row) + file_ext, "w") as f:
        f.write(disclaimer)
        f.write(code_str)
        f.write(dis_end)

    return code_str, file_ext


def get_resultdirectory_path(usecase_name, job_name):
    result_dirpath = os.path.join(Result_rootpath, usecase_name, job_name)
    return result_dirpath


def merge_xlsx_files(usecase_name, job_name, excelname, defect_excel_file):
    output_file_path = os.path.join(Result_rootpath, usecase_name, job_name) + "/" + excelname
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, defect_excel_file)
    f1 = pd.read_excel(output_file_path)
    f2 = pd.read_excel(input_file_path)
    f3 = f1[["Defect ID"]].merge(f2[["Defect ID",
                                     "Defect Title", "Defect Description",
                                     "Date"]],
                                 on="Defect ID",
                                 how="left")
    #   Defect Title	Defect Description	Date
    file_name = "Orphan_Defect.xlsx"
    output_file_path = os.path.join(Result_rootpath, usecase_name, job_name) + "/" + file_name
    # creating a new file
    f3.to_excel(output_file_path, index=False)
    return output_file_path, file_name


def convert_xlsx_to_csv(xlsxfilepath, usecase_name, job_name, file_name):
    df = pd.read_excel(xlsxfilepath)
    csv_data = df.to_csv(index=False)
    csv_file_path = os.path.join(Result_rootpath, usecase_name, job_name) + "/" + file_name
    with open(csv_file_path, 'w') as csv_file:
        csv_file.write(csv_data)
    return csv_file_path


def get_csv_data_from_response(response, start_char, end_char, usecase_name, job_name):
    response = str(response)
    start_index = response.index(start_char) + 1
    end_index = response.rfind(end_char)
    csv_str = start_char + response[start_index:end_index] + end_char
    return csv_str


def tableFromText(text, excelname, usecase_name, job_name, orphan_defect):
    rows = text.strip().split('\n')
    headers = [header.strip() for header in rows[0].split('|') if header.strip()]
    data = [[cell.strip() for cell in row.split('|') if cell.strip()] for row in rows[2:]]
    data = [[cell.strip() for cell in row] for row in data]
    df = pd.DataFrame(data, columns=headers)
    # Remove rows where Column1 has the value True
    if orphan_defect == True:
        df = df[df['Orphan Defect'] != "false"]
        df = df[df['Orphan Defect'] != "False"]
    output_file_path = os.path.join(Result_rootpath, usecase_name, job_name) + "/" + excelname
    df.to_excel(output_file_path, index=False)


def read_xlsx_file(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(Result_rootpath, usecase_name, job_name, file_relpath)
    file_content = pd.read_excel(input_file_path)
    file_size = os.path.getsize(input_file_path)
    file_name = os.path.basename(input_file_path)
    updatelog(log_name, "File Read Successfully! [" + file_name + "]\n", True)
    return file_content


def get_input_file_path(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    return input_file_path


def excelLoader(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** " + str(id) + " Out of " + str(file_count) + " Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    loader = UnstructuredExcelLoader(input_file_path, mode="elements")
    docs = loader.load()
    file_content = docs[0].page_content
    file_size = os.path.getsize(input_file_path)
    file_name = os.path.basename(input_file_path)
    updatelog(log_name, "File Read Successfully! [" + file_name + "]\n", True)
    return file_content, file_size, file_name


def read_xlsx_clean_data(usecase_name, job_name, file_relpath):
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    df = pd.read_excel(input_file_path)
    tab_separated_data = df.to_csv(sep="\t", index=False)
    tab_separated_data = tab_separated_data.replace(',', "\n")
    return tab_separated_data


def get_tfs_files_info(org_id, tfs_filepath):
    # org_id = os.environ.get('ORG_ID')
    get_config = db_utils.get_tfs_config(org_id)
    if len(get_config['data']) > 0:
        config = get_config['data'][0]['repo_config']
        repository_url = config['repo_url']
        organization = config['org_name']
        project_name = config['proj_name']
        repository_name = config['repo_name']
        pat = config['pat']
        folder = tfs_filepath

        # Encode the PAT in base64
        encoded_pat = base64.b64encode((':' + pat).encode()).decode()
        # Send the request to the Azure DevOps API
        headers = {"Authorization": f"Basic {encoded_pat}"}

        checkrepo_resp = requests.get(
            f"{repository_url}/{organization}/{project_name}/_apis/git/repositories/{repository_name}", headers=headers)
        if checkrepo_resp.status_code == 200:
            # For Git repositories
            api_url = f"{repository_url}/{organization}/{project_name}/_apis/git/repositories/{repository_name}/items?scopePath=/{folder}&recursionLevel=Full&api-version=5.1"
            response = requests.get(api_url, headers=headers)
            if response.status_code == 200:
                # Parse the JSON response and format it as a folder structure
                data = json.loads(response.text)
                files_info = []
                fileext_list = []
                fileext_list.append("All")
                id = 0
                for item in data["value"]:
                    if "isFolder" in item and item["isFolder"]:
                        continue
                    else:
                        id = id + 1
                        file_name = item['path'].split('/')[-1]
                        split_filename_ext = file_name.rsplit(".", 1)
                        ext_value = split_filename_ext[1] if 1 < len(split_filename_ext) else ""
                        file_info = {}
                        file_info['id'] = id
                        file_info['path'] = item['path'].rsplit('/', 1)[0][1:]
                        file_info['name'] = file_name
                        file_info['fullpath'] = item['path']
                        files_info.append(file_info)
                        if ext_value not in fileext_list:
                            fileext_list.append(ext_value)

                ret = {}
                fileext_list.sort()
                ret['message'] = "Success"
                ret['data'] = sorted(files_info, key=lambda item: item["path"])
                ret['extension'] = fileext_list
            else:
                ret = {}
                ret['message'] = "PATH_NOT_VALID"
                ret['data'] = []
                ret['extension'] = []
        else:
            ret = {}
            ret['message'] = "CONFIG_NOT_VALID"
            ret['data'] = []
            ret['extension'] = []
    else:
        ret = {}
        ret['message'] = "CONFIG_NOT_FOUND"
        ret['data'] = []
        ret['extension'] = []
    return ret


def handleTFSFilesUpload(uploaded_files, usecase_name, job_name, request):
    upload_root_path = os.path.join(UploadData_rootpath, usecase_name, job_name)
    createDirectory(upload_root_path)

    org_id = os.environ.get('ORG_ID')
    get_config = db_utils.get_tfs_config(org_id)
    config = get_config['data'][0]['repo_config']

    repository_url = config['repo_url']
    organization = config['org_name']
    project_name = config['proj_name']
    repository_name = config['repo_name']
    pat = config['pat']

    # Encode the PAT in base64
    encoded_pat = base64.b64encode((':' + pat).encode()).decode()
    # Send the request to the Azure DevOps API
    headers = {"Authorization": f"Basic {encoded_pat}"}

    for uploaded_file in uploaded_files:
        file_path = uploaded_file["fullpath"]
        save_path = os.path.join(upload_root_path, uploaded_file["path"])
        createDirectory(save_path)
        api_url = f"{repository_url}/{organization}/{project_name}/_apis/git/repositories/{repository_name}/items?path=/{file_path}&api-version=5.1"
        response = requests.get(api_url, headers=headers)
        if response.status_code == 200:
            # Write the file to disk  
            with open(os.path.join(save_path, uploaded_file["name"]), "wb") as file:
                file.write(response.content)
            print("File downloaded successfully. [", file_path, "]")
        else:
            print(f"Failed to download file: {response.status_code} - {response.text}")
    return uploaded_files[0]['fullpath'].split('/')[0]


def get_sample_metadata(data_format, file_type):
    check_rel_path = os.path.join(DefaultSampleDataPath,
                                  "Structured/") if data_format == "structured" else os.path.join(DefaultSampleDataPath,
                                                                                                  "Unstructured/")
    folder_path = os.path.join(check_rel_path, f"{file_type}/")
    file_list = []
    id = 0
    fileext_list = []
    fileext_list.append("All")
    for root, _, files in os.walk(folder_path):
        for file in files:
            id = id + 1
            file_path = os.path.join(root, file)
            relative_path = os.path.relpath(file_path, check_rel_path).replace("\\", "/")
            file_size = os.path.getsize(file_path)
            path = relative_path.rsplit("/", 1)[0]
            split_filename_ext = file.rsplit(".", 1)
            ext_value = split_filename_ext[1] if 1 < len(split_filename_ext) else ""
            if ext_value not in fileext_list:
                fileext_list.append(ext_value)

            file_list.append({
                'id': id,
                'name': file,
                'path': path,
                'fullpath': relative_path,
                'size': file_size
            })

    ret = {}
    fileext_list.sort()
    ret['message'] = "Success"
    ret['data'] = sorted(file_list, key=lambda item: item["path"])
    ret['extension'] = fileext_list

    return ret


def get_uploaded_data(project_id, usecase_name):
    if usecase_name == "Data Generation#Invalidate":
        folder_path = os.path.join(UploadData_rootpath, f"{project_id}/structured/")
    else:
        folder_path = os.path.join(UploadData_rootpath, f"{project_id}/unstructured/")
    file_list = []
    id = 0
    fileext_list = []
    fileext_list.append("All")
    with open(os.path.join(config_path, "usecase_data.json")) as f:
        usecase = json.load(f)

    ### ## # FOR UNSTRUCTURED DATA # ## ###
    for root, _, files in os.walk(folder_path):
        for file in files:
            id = id + 1
            file_path = os.path.join(root, file)
            relative_path = os.path.relpath(file_path, folder_path).replace("\\", "/")
            file_size = os.path.getsize(file_path)
            modified_date = os.path.getmtime(file_path)
            path = relative_path.rsplit("/", 1)[0]
            data_format = "structured" if usecase_name == "Data Generation#Invalidate" else "unstructured"
            split_filename_ext = file.rsplit(".", 1)
            ext_value = split_filename_ext[1] if 1 < len(split_filename_ext) else ""
            if ext_value not in fileext_list:
                fileext_list.append(ext_value)
            if usecase_name in usecase["UsecaseName"]:
                for i in usecase["UsecaseName"][usecase_name]:
                    if i in path:
                        file_list.append(
                            {'id': id, 'name': file, 'path': path, 'fullpath': relative_path, 'size': file_size,
                             'data_format': data_format, 'modified_date': modified_date, 'category': relative_path.split('/')[0],'checked':False})
            else:
                file_list.append({'id': id, 'name': file, 'path': path, 'fullpath': relative_path, 'size': file_size,
                                  'data_format': data_format, 'modified_date': modified_date})

    ### ## # FOR STRUCTURED DATA # ## ###
    if usecase_name in usecase["StructuredData"]:
        folder_path = os.path.join(UploadData_rootpath, f"{project_id}/structured/")
        print(folder_path)
        for root, _, files in os.walk(folder_path):
            for file in files:
                id = id + 1
                file_path = os.path.join(root, file)
                modified_date = os.path.getmtime(file_path)
                relative_path = os.path.relpath(file_path, folder_path).replace("\\", "/")
                file_size = os.path.getsize(file_path)
                path = relative_path.rsplit("/", 1)[0]
                data_format = "structured"
                split_filename_ext = file.rsplit(".", 1)
                ext_value = split_filename_ext[1] if 1 < len(split_filename_ext) else ""
                if ext_value not in fileext_list:
                    fileext_list.append(ext_value)
                for i in usecase["StructuredData"][usecase_name]:
                    if i in path:
                        file_list.append(
                            {'id': id, 'name': file, 'path': path, 'fullpath': relative_path, 'size': file_size,
                             'data_format': data_format, 'modified_date': modified_date, 'category': relative_path.split('/')[0]})

    ret = {}
    fileext_list.sort()
    ret['message'] = "Success"
    ret['data'] = sorted(file_list, key=lambda x: x['modified_date'], reverse=True)
    ret['extension'] = fileext_list

    return ret


def handleSampleFilesUpload(uploaded_files, usecase_name, job_name):
    upload_root_path = os.path.join(UploadData_rootpath, usecase_name, job_name)
    createDirectory(upload_root_path)
    for uploaded_file in uploaded_files:
        file_path = uploaded_file["fullpath"]
        save_path = os.path.join(upload_root_path, uploaded_file["path"])
        default_location_path = os.path.join(DefaultSampleDataPath, file_path)
        createDirectory(save_path)
        shutil.copy(default_location_path, save_path)
    return uploaded_files[0]['fullpath'].split('/')[0]


def get_svn_files_info(svn_filepath):
    # repository_file = os.path.join(config_path, "repository.ini")
    # config_parser = configparser.ConfigParser()
    # config_parser.read(repository_file)
    #
    # username = config_parser.get("SVN", "svn_username")
    # password = config_parser.get("SVN", "svn_password")
    # instance_url = config_parser.get("SVN", "svn_instance_url")
    username = ""
    password = ""
    instance_url = ""

    files_info = []
    fileext_list = []
    final_svn_file_path = os.path.join(instance_url, str(svn_filepath))
    SVN = svn.remote.RemoteClient(final_svn_file_path, username, password)

    for rel_path, e in SVN.list_recursive():
        id = 0
        if e['is_directory'] == True:
            continue
        else:
            file_info = {}
            file_name = e['name']
            split_filename_ext = file_name.rsplit(".", 1)
            ext_value = split_filename_ext[1] if 1 < len(split_filename_ext) else ""
            file_info['id'] = id + 1
            file_info['path'] = rel_path
            file_info['name'] = e['name']
            file_info['fullpath'] = svn_filepath
            files_info.append(file_info)
            if ext_value not in fileext_list:
                fileext_list.append(ext_value)

    ret = {}
    fileext_list.sort()
    ret['message'] = "Success"
    ret['data'] = sorted(files_info, key=lambda item: item["path"])
    ret['extension'] = fileext_list

    global svn_file_path
    svn_file_path = final_svn_file_path
    global x
    x = ret['data']
    return ret


def handleSVNFilesUpload(uploaded_files, usecase_name, job_name):
    upload_root_path = os.path.join(UploadData_rootpath, usecase_name, job_name)
    createDirectory(upload_root_path)
    # repository_file = os.path.join(config_path, "repository.ini")
    # config_parser = configparser.ConfigParser()
    # config_parser.read(repository_file)
    #
    # username = config_parser.get("SVN", "svn_username")
    # password = config_parser.get("SVN", "svn_password")
    username = ""
    password = ""

    for uploaded_file in uploaded_files:
        if uploaded_file["path"] != None:
            file_path = svn_file_path + '/' + uploaded_file["path"] + '/' + uploaded_file["name"]
        else:
            file_path = svn_file_path + '/' + uploaded_file["name"]
        save_path = os.path.join(upload_root_path, uploaded_file["path"])

        createDirectory(save_path)

        auth = HTTPBasicAuth(username, password)
        response = requests.get(file_path, auth=auth)
        if response.status_code == 200:
            with open(os.path.join(save_path, uploaded_file["name"]), "wb") as file:
                file.write(response.content)
            print("File downloaded successfully. [", file_path, "]")
        else:
            print(f"Failed to download file: {response.status_code} - {response.text}")
    return svn_file_path.split('/')[0]


def find_file_path(root_path, target_file):
    for dir_path, dir_names, file_names in os.walk(root_path):
        for file_name in file_names:
            if file_name == target_file:
                return os.path.join(dir_path, file_name)
    return None


def GeneratePromptFromFile(usecase_name, job_name, form_data, index_name):
    log_name = job_name
    updatelog(log_name, "Prompt Generating...", True)
    uploaded_file_path = os.path.join(
        "Assets", "UploadedData", usecase_name, job_name)

    if usecase_name == "Code Generation":
        chk_list = ['requirement', 'guideline']

    FinalPrompt = ""

    for file in chk_list:
        updatelog(log_name, "Reading " + file + "...", True)
        exact_filename = FindFileNamebyTitle(uploaded_file_path, file)
        if exact_filename != None:
            doc_path = find_file_path(uploaded_file_path, exact_filename)
            ext = doc_path.split(".")[1] if doc_path != None else ""
            if ext == "txt":
                file_content = read_txt(doc_path)
                FinalPrompt += file_content + "\n\n"
            elif ext == "docx":
                file_content = read_txt(doc_path)
                FinalPrompt += file_content + "\n\n"
            else:
                file_content = ""
                FinalPrompt += ""

            if file == 'requirement':
                function_names = extract_functions_nl(file_content)
                print("Function names File :> ", function_names)
                for function_name in function_names:
                    print("function_name :>>", function_name)
                    api_details = search_similar_codes(index_name, function_name)
                    # for r in result:
                    if len(api_details) > 5:
                        FinalPrompt += "Generate utility function based on below API details" + api_details + "\n"

    # FinalPrompt += form_data["2"] if "2" in form_data else ""
    FinalPrompt += "Return only generated code. The title should be Generated Code. Must return the generated code in inside of single code block. Do not return any code explanation. The final response title and subtitle should be bold."
    return FinalPrompt


def GenerateSQLPromptFromFile(usecase_name, job_name):
    log_name = job_name
    updatelog(log_name, "Prompt Generating...", True)
    uploaded_file_path = os.path.join(
        "Assets", "UploadedData", usecase_name, job_name)
    if usecase_name == "SQL Generation":
        chk_list = ['requirement', 'guideline']
    FinalPrompt = ""
    for file in chk_list:
        updatelog(log_name, "Reading " + file + "...", True)
        exact_filename = FindFileNamebyTitle(uploaded_file_path, file)
        if exact_filename != None:
            doc_path = find_file_path(uploaded_file_path, exact_filename)
            ext = doc_path.split(".")[1] if doc_path != None else ""
            if ext == "txt":
                file_content = read_txt(doc_path)
                FinalPrompt += file_content + "\n\n"
            elif ext == "docx":
                file_content = read_docx(doc_path)
                FinalPrompt += file_content + "\n\n"
            else:
                file_content = ""
                FinalPrompt += ""
    return FinalPrompt


def read_docx(file_path):
    doc = docx.Document(file_path)
    text = []
    for paragraph in doc.paragraphs:
        text.append(paragraph.text)
    return "\n".join(text)


def read_txt(file_path):
    with open(file_path, "r", encoding='utf-8', errors='ignore') as file:
        content = file.read()
    return content


def get_functions_list(content):
    pattern = r'\b(?:def|public\s+static(?:\s+[a-zA-Z_][a-zA-Z0-9_<>]*)?|private\s+static(?:\s+[a-zA-Z_][a-zA-Z0-9_<>]*)?|protected\s+static(?:\s+[a-zA-Z_][a-zA-Z0-9_<>]*)?)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\('

    # Find all matches in the file content
    function_names = re.findall(pattern, content)
    return function_names


def extract_functions_nl(content):
    try:
        log_name = "func_utility"
        createLOGFile(log_name)
        SystemRole = "You are senior software developer."
        Prompt = """Below is requirement document. Can you suggest for code generation scenarios like what lines you would consider to create/generate functions. {} \n\n {} """
        FormatPrompt = """Return the suggested function names in array format (example : ['','']). Must return the all function names in array format."""
        FinalPrompt = Prompt.format(content, FormatPrompt)
        response = llm_call(FinalPrompt, SystemRole, log_name, max_tokens=3000)
        # print(response['response'])
        # print(type(response['response']))
        matched = re.search("\[(.*?)\]", response['response'])
        # print(matched)
        if matched:
            try:
                # print(matched.group())
                functions = literal_eval(matched.group())
                return functions
            except Exception as e:
                return []
        else:
            return []

        # FinalPrompt = """Below content parse and return the only array values only. """+response['response']
        # response = llm_call(FinalPrompt, SystemRole, log_name, max_tokens=3000)
        # print(response['response'])

        # # Split the content by line break to get each line as a separate string  
        # lines = content.split('\n')

        # # Initialize an empty list to store the functions  
        # functions = []
        # # Iterate over each line  
        # for line in lines:
        #     # If the line starts with a digit, it means it's one of the functions  
        #     if line and line[0].isdigit():
        #         # Remove the digit and the dot at the start, and strip the remaining leading and trailing whitespace  
        #         function = line.split('. ', 1)[1].strip()
        #         # If the function ends with a comma or a dot, remove it  
        #         if function[-1] in ',.':
        #             function = function[:-1]
        #             # Add the function to the list
        #         functions.append(function)

        # print("Functions List :>>", functions)

    except Exception as e:
        return []


def get_all_orphan_defect(csv_table_data):
    # Split the data into lines and remove empty lines
    lines = [line.strip() for line in csv_table_data.strip().split('\n')]

    # Extract the header and data rows
    header = [item.strip() for item in lines[0].split('|')]
    data = [line.split('|') for line in lines[2:]]

    # Create a list of dictionaries
    data_dicts = []
    for row in data:
        data_dict = {header[i]: row[i].strip() for i in range(len(header))}
        data_dicts.append(data_dict)

    response = []
    # get the list of dictionaries
    for item in data_dicts:
        if str(item['Orphan Defect']).lower() == "true":
            response.append(item['Defect ID'])

    return response


def read_pdf(path):
    resource_manager = PDFResourceManager()
    output_string = io.StringIO()
    codec = 'utf-8'
    laparams = None
    device = TextConverter(resource_manager, output_string, codec=codec, laparams=laparams)
    with open(path, 'rb') as file:
        interpreter = PDFPageInterpreter(resource_manager, device)
        for page in PDFPage.get_pages(file):
            interpreter.process_page(page)
        text = output_string.getvalue()
    device.close()
    output_string.close()
    return text


def text_splitter_doc(filecontent, chunk_size=15000, chunk_overlap=20):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                                   length_function=len, add_start_index=True)
    text_docs = text_splitter.split_text(filecontent)
    return text_docs


def get_most_relatable_language(text, terms):
    # Create a TF-IDF vectorizer
    vectorizer = TfidfVectorizer()

    # Calculate TF-IDF vectors for terms and the text
    tfidf_matrix = vectorizer.fit_transform([text] + terms)

    # Calculate cosine similarity between the text and each term
    similarities = cosine_similarity(tfidf_matrix)

    # The term with the highest similarity is the most relevant
    most_relatable_term = terms[similarities[0][1:].argmax()]

    return most_relatable_term


def isLLMGuardRun(usecase_name, form_data):
    isLLMGuardRun = False
    response = db_utils.get_promptValue(usecase_name)
    promptValue = response["data"][0]
    additional_info = json.loads(promptValue["additional_info"].replace('\'', '\"'))
    scanner_id = additional_info['SCANNER'] if "SCANNER" in additional_info else 0
    if scanner_id != 0:
        selected_option = form_data[scanner_id] if scanner_id in form_data else ""
        if selected_option == "Yes":
            isLLMGuardRun = True
    return isLLMGuardRun


def summaryType(usecase_name, form_data):
    summaryType = 'file'
    response = db_utils.get_promptValue(usecase_name)
    promptValue = response["data"][0]
    additional_info = json.loads(promptValue["additional_info"].replace('\'', '\"'))
    summary_type = additional_info['TYPE'] if "TYPE" in additional_info else 0
    if summary_type != 0:
        selected_option = form_data[summary_type] if summary_type in form_data else ""
        if selected_option == "Function":
            summaryType = 'function'
    return summaryType


def ExtractFuncAPIDetails(file_content, index_name):
    APIPrompt = ""
    function_names = extract_functions_nl(file_content)
    print("Function names Prompt :> ", function_names)
    for function_name in function_names:
        api_details = search_similar_codes(index_name, function_name)
        if len(api_details) > 5:
            APIPrompt += "Generate utility function based on below API details" + api_details + "\n"
    return APIPrompt


def FindFileNamebyTitle(upload_path, title):
    for root, _, files in os.walk(upload_path):
        for filename in files:
            if title in filename:
                return filename
    return None


def convert_xlsx_to_csv_remove_duplicate_testcase(xlsxfilepath, usecase_name, job_name, file_name):
    if xlsxfilepath.lower().endswith('.xlsx'):
        df = pd.read_excel(xlsxfilepath)
    elif xlsxfilepath.lower().endswith('.csv'):
        df = pd.read_csv(xlsxfilepath, encoding = detect_encoding(xlsxfilepath))
    else:
        raise ValueError("Unsupported file format: {}".format(xlsxfilepath))
    # df = pd.read_excel(xlsxfilepath)
    disclaimer_header1 = pd.DataFrame(
        [['Disclaimer: This output contains AI generated content, user is advised to review it before consumption.']],
        columns=['testcaseId'])
    disclaimer_header = pd.DataFrame([['*Start of AI generated content*']], columns=['testcaseId'])
    disclaimer_footer = pd.DataFrame([['*End of AI generated content*']], columns=['testcaseId'])
    # Concatenate disclaimer DataFrame with the main DataFrame
    df = pd.concat([disclaimer_header1, disclaimer_header, df, disclaimer_footer], ignore_index=True)
    df_to_sync = df.drop_duplicates(subset=['testcaseId'])
    df_to_sync = df_to_sync[['testcaseId', 'Title', 'Description']]
    df_to_sync = df_to_sync.dropna(how='all')
    df_to_sync = df_to_sync.reset_index(drop=True)
    csv_data = df_to_sync.to_csv(index=False)
    # print(csv_data)
    csv_file_path = os.path.join(Result_rootpath, usecase_name, job_name) + "/" + file_name
    with open(csv_file_path, 'w') as csv_file:
        csv_file.write(csv_data)
    return csv_file_path, csv_data


def convert_xlsx_to_csv_remove_defect_column(xlsxfilepath, usecase_name, job_name, file_name):
    df = pd.read_excel(xlsxfilepath)
    df_to_sync = df[['defectId', 'Title', 'Description']]
    df_to_sync = df_to_sync.dropna()
    df_to_sync = df_to_sync.reset_index(drop=True)
    csv_data = df_to_sync.to_csv(index=False)
    # print(csv_data)
    csv_file_path = os.path.join(Result_rootpath, usecase_name, job_name) + "/" + file_name
    with open(csv_file_path, 'w') as csv_file:
        csv_file.write(csv_data)
    return csv_file_path, csv_data


def tableFromOpenAiResponse(textList, excelname, usecase_name, job_name, orphan_defect):
    flag = True
    for text in textList:

        rows = text.strip().split('\n')
        if flag:
            headers = [header.strip() for header in rows[0].split('|') if header.strip()]
            flag = False
        data = [[cell.strip() for cell in row.split('|') if cell.strip()] for row in rows[2:]]
        data = [[cell.strip() for cell in row] for row in data]
        df = pd.DataFrame(data, columns=headers)

    output_file_path = os.path.join(Result_rootpath, usecase_name, job_name) + "/" + excelname
    df.to_excel(output_file_path, index=False)


def update_xlsx_Recommendation(defect_file_path, defect_testcaseid_list, usecase_name, job_name, project_id):
    # print(defect_file_path)
    if defect_file_path.endswith('.xlsx'):
        csv_data = pd.read_excel(defect_file_path)
    elif defect_file_path.endswith('.csv'):
        csv_data = pd.read_csv(defect_file_path,encoding = detect_encoding(defect_file_path))
    else:
        raise ValueError("Unsupported file format. Please provide a file with either .xlsx or .csv extension.")
    # csv_data = pd.read_excel(defect_file_path)

    for li in defect_testcaseid_list:
        update_data = {1: str(li).split('|')[0], 2: str(li).split('|')[1]}
        for index, row in csv_data.iterrows():
            if str(row['defectId']) == str(str(li).split('|')[0]):
                csv_data.loc[index, 'test_case_id'] = str(str(li).split('|')[1])

    os.makedirs(os.path.join(UploadData_rootpath, project_id, "unstructured", "testing_artifact", job_name))
    csv_file_path = os.path.join(UploadData_rootpath, project_id, "unstructured", "testing_artifact",
                                 job_name) + "/" + "Defects_Info.xlsx"

    csv_data.to_excel(csv_file_path, index=False)


def latestFolder(folderPath, prefix_to_check):
    folder_path = folderPath
    prefix_to_check = prefix_to_check
    folders = [f for f in os.listdir(folder_path) if
               os.path.isdir(os.path.join(folder_path, f)) and f.startswith(prefix_to_check)]

    latest_timestamp = datetime.min
    latest_folder = ""

    for folder in folders:
        timestamp_str = folder.split('_')[-1]
        timestamp = datetime.strptime(timestamp_str, '%m-%d-%Y-%H-%M-%S')

        if timestamp > latest_timestamp:
            latest_timestamp = timestamp
            latest_folder = folder

    latest_folder_path = os.path.join(folder_path, latest_folder)

    return latest_folder_path


def detect_encoding(file_path):
    with open(file_path, 'rb') as file:
        result = chardet.detect(file.read())
        return result['encoding']


def read_input_file_content(file_path):
    with open(file_path, 'r') as file:
        file_content = file.read()
        file_size = os.path.getsize(file_path)
        file_name = os.path.basename(file_path)
        return file_content, file_size, file_name


# def detect_language(content):
#     try:
#         log_name = "func_utility"
#         createLOGFile(log_name)
#         SystemRole = "You are a programming export"
#         Prompt = """Below content analysis and return that content relavant to which program language like java, python, c, c++, js, csharp etc . {} {} """
#         FormatPrompt = """Return only the programming language only (example :Java). """
#         FinalPrompt = Prompt.format(FormatPrompt, content)
#         response = llm_call(FinalPrompt, SystemRole, log_name, max_tokens=3000)
#         return response['response']
#     except Exception as e:
#         return ""