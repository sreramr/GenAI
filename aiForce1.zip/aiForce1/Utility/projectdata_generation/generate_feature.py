"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import concurrent.futures
from tqdm import tqdm
import pandas as pd
import numpy as np

from sklearn.cluster import DBSCAN
from Utility.llms.llm_client import chat_completion_client, text_embedding_client
from Utility.vdb_client_utility.vdb_lc_client import create_vectorstore_client
from langchain.callbacks import get_openai_callback

FEATURE_DEFINATION = """In software development, a feature refers to a specific functionality or capability of a software application.
A feature should be short and concise, strictly not more than two or three words.
"""

TEST_CASE_TO_FEATURE_PROMPT = FEATURE_DEFINATION + """
Extract distinct features from the following list of Test Cases Info:

{testcase_list}

Return the List of extracted features in following format:
- feature1
- feature2
...

"""

DEFECT_TO_FEATURE_PROMPT = FEATURE_DEFINATION + """
Extract distinct features from the following list of Software Defects Info:

{defect_list}

Return the List of extracted features in following format:
- feature1
- feature2
...

"""

FEATURE_CLASSIFIER_PROMPT = FEATURE_DEFINATION + """
Based on the above feature defination, classify below text as feauture of not.
`{feature}`

Return Yes/No.
Answer:"""

PARENT_FEATURE_PROMPT = """Feature List:
{feature_list}

Given the above list of Similar features, Decide a 'Parent Feature' to which majority of these features are related.
If only one feature is given, just return the same feature as Parent feature.

Parent Feature:"""


def _batch_maker(items: list, batch_size=1):
    batch_items = []
    for i in range(0, len(items), batch_size):
        batch = items[i:i+batch_size]
        batch_items.append(batch)
    return batch_items


class FeatureGenerator:
    def __init__(
        self,
        feature_df: pd.DataFrame = None,
        testcase_df: pd.DataFrame = None,
        defect_df: pd.DataFrame = None
    ) -> None:
        if not isinstance(testcase_df, pd.DataFrame) and not isinstance(defect_df, pd.DataFrame):
            raise ValueError(
                "Atleast provide either testcase or defect info dataframe")

        self.feature_df = feature_df
        self.testcase_df = testcase_df
        self.defect_df = defect_df

        self.chat_llm = chat_completion_client(
            max_retries=30, request_timeout=120)
        self.embedding_llm = text_embedding_client()

        self.temp_feature_db = None
        self.final_feature_df = feature_df

        self.prompt_tokens = 0
        self.total_tokens = 0
        self.total_cost = 0

    def _llm(self, input):
        res = ""
        try:
            with get_openai_callback() as cb:
                res = self.chat_llm.call_as_llm(input)
                self.prompt_tokens += cb.prompt_tokens
                self.total_tokens += cb.total_tokens
                self.total_cost += cb.total_cost
        except:
            ...
        return res

    def _feature_filter(self, feature_list):
        # filter duplicates and null
        filtered_features = [f for f in list(set(feature_list)) if f.strip()]
        # filter too long features
        filtered_features = [f for f in filtered_features if len(f.split(" ")) <= 3]
        # LLM classifier
        _feature_classfier_promp_list = [FEATURE_CLASSIFIER_PROMPT.format(feature=f) for f in filtered_features]
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executer:
            _result_class = list(executer.map(self._llm, _feature_classfier_promp_list))
            filtered_features = [f for i, f in enumerate(filtered_features) if _result_class[i].strip() == "Yes"]

        return filtered_features

    def _generate_feature_from_testcase(self):
        feature_list = []
        if isinstance(self.testcase_df, pd.DataFrame):
            testcase_title_list = self.testcase_df.Title.drop_duplicates().tolist()
            batch_size = 10
            batch_prompt_list = []

            for batch in _batch_maker(testcase_title_list, batch_size=batch_size):
                prompt = TEST_CASE_TO_FEATURE_PROMPT.format(
                    testcase_list="- " + "\n- ".join(batch))
                batch_prompt_list.append(prompt)

            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executer:
                print("Generating feature from Test Cases")
                batch_feature_list_str = list(tqdm(executer.map(
                    self._llm, batch_prompt_list), total=len(batch_prompt_list)))

            batch_feature_list = [batch_features.splitlines()
                                  for batch_features in batch_feature_list_str]
            feature_list = [f.strip("- ") for f in sum(batch_feature_list, [])]

        return feature_list

    def _generate_feature_from_defect(self):
        feature_list = []
        if isinstance(self.defect_df, pd.DataFrame):
            defect_title_list = self.defect_df.Title.drop_duplicates().tolist()
            batch_size = 10
            batch_prompt_list = []

            for batch in _batch_maker(defect_title_list, batch_size=batch_size):
                prompt = DEFECT_TO_FEATURE_PROMPT.format(
                    defect_list="- " + "\n- ".join(batch))
                batch_prompt_list.append(prompt)

            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executer:
                print("Generating feature from Defects")
                batch_feature_list_str = list(tqdm(executer.map(
                    self._llm, batch_prompt_list), total=len(batch_prompt_list)))

            batch_feature_list = [batch_features.splitlines()
                                  for batch_features in batch_feature_list_str]
            feature_list = [f.strip("- ") for f in sum(batch_feature_list, [])]

        return feature_list

    def generate_features(self):
        all_features = []
        all_features += self._generate_feature_from_testcase()
        all_features += self._generate_feature_from_defect()

        all_features = self._feature_filter(all_features)

        feature_df = pd.DataFrame(all_features, columns=["feature"])
        feature_vectors = self.embedding_llm.embed_documents(all_features)
        feature_df["embedding"] = feature_vectors
        X = np.array(feature_vectors)

        # Group featues and Remove duplicates
        dbscan = DBSCAN(eps=0.5, min_samples=1).fit(X)
        feature_df["cluster label"] = dbscan.labels_

        feature_df_group = feature_df.groupby("cluster label")

        final_features_json = []

        # Get parent feature for a group
        parent_feature_prompt_list = []
        for name, group in feature_df_group:
            _feature_list = group["feature"].tolist()
            _prompt = PARENT_FEATURE_PROMPT.format(
                feature_list="\n".join(["- " + f for f in _feature_list]))
            parent_feature_prompt_list.append(_prompt)

        print("Grouping features")
        parent_feature_name_list = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executer:
            parent_feature_name_list = list(tqdm(executer.map(
                self._llm, parent_feature_prompt_list), total=len(parent_feature_prompt_list)))

        for i, (name, group) in enumerate(feature_df_group):
            parent_feature_name = parent_feature_name_list[i]

            final_features_json.append({
                "feature": parent_feature_name,
                "parent feature": None,
            })

            for sub_feature in group["feature"].tolist():
                if sub_feature == parent_feature_name:
                    continue  # Skip

                final_features_json.append({
                    "feature": sub_feature,
                    "parent feature": parent_feature_name,
                })

        self.final_feature_df = pd.DataFrame(final_features_json, columns=[
                                             "feature", "parent feature"])
        self.final_feature_df["CreatedDate"] = pd.Timestamp.now().strftime(
            '%m/%d/%Y')
        self.final_feature_df["keywords"] = None

        print(">>>>>>>Feature Generation Completed...")
        return self.final_feature_df

    def _create_feature_db(self):
        if not self.temp_feature_db:
            if not isinstance(self.final_feature_df, pd.DataFrame):
                self.final_feature_df = self.generate_features()

            self.temp_feature_db = create_vectorstore_client()
            self.temp_feature_db.add_texts(texts=self.final_feature_df["feature"].fillna("").tolist())

        return self.temp_feature_db

    def _get_similar_feature(self, query="", query_vector=None, threshold=0.5):
        self._create_feature_db()
        docs = []
        if query_vector:
            docs = self.temp_feature_db.similarity_search_by_vector(
                query_vector, k=1)
        else:
            docs = self.temp_feature_db.similarity_search(query, k=1)

        if len(docs) > 0:
            return docs[0].page_content
        else:
            return None

    def map_feature_to_testcase(self):
        testcase_vectors = self.embedding_llm.embed_documents(
            self.testcase_df.Title.tolist())

        testcase_to_feature = [self._get_similar_feature(
            query_vector=qv) for qv in testcase_vectors]

        self.testcase_df["FeatureName"] = testcase_to_feature
        return self.testcase_df

    def map_feature_to_defect(self):
        defect_vectors = self.embedding_llm.embed_documents(
            self.defect_df.Title.tolist())

        defect_to_feature = [self._get_similar_feature(
            query_vector=qv) for qv in defect_vectors]

        self.defect_df["Feature"] = defect_to_feature
        return self.defect_df
