"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""

#************************************************************#
from langchain.document_loaders import CSVLoader, DataFrameLoader
from langchain.vectorstores import DocArrayInMemorySearch
from Utility.common_utility import utility

from Utility.llms.llm_client import (
    chat_completion_client,
    get_embedding_config,
)
import logging
from langchain.callbacks import get_openai_callback
import os
import csv
import time
import math
import tiktoken
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from typing import Tuple
import os
import pandas as pd
import ast
import re
import json

#from prompts_TCGP import TREE
from Utility.usecase_utility.llm_call import llm_call
from Utility.llms.llm_client import get_config

def create_input_folder_if_not_exists(directory_name):
    input_path = os.path.join(directory_name, "input")
    if not os.path.exists(input_path):
        os.makedirs(input_path)

def excel_to_csv(input_excel_path, file_name, encoding):
    try:
        name, ext = os.path.splitext(file_name)
        if ext == ".csv":
            return input_excel_path  
        else:
            df = pd.read_excel(input_excel_path, engine='openpyxl')

        try:
            create_input_folder_if_not_exists(os.path.dirname(input_excel_path))
        except Exception as e:
            logging.error("Error Occured %s", e, exc_info=True)
            raise Exception(f"Unable to create input folder: {str(e)}")

        base_name,_ = os.path.splitext(file_name)
        input_csv_path = os.path.join(os.path.dirname(input_excel_path),"input", base_name+".csv")
        df.to_csv(input_csv_path, index=False, encoding=encoding)
        print("Filtered CSV file saved:", input_csv_path)

        if df is None:
            raise Exception("None type Dataframe")
        return input_csv_path
    
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"An error occurred while reading CSV: {str(e)}")


def CSVLoading(csv_data_location, encoding):
    try:
        # Check if csv_data_location is a valid CSV file
        if not csv_data_location.endswith('.csv'):
            raise ValueError("Invalid CSV file format")

        file = csv_data_location
        try:
            loader = CSVLoader(file_path=file)
            docs = loader.load()
        except Exception as e:
            loader = CSVLoader(file_path=file, encoding=encoding)
            docs = loader.load()

        # Check if the loaded document list is not empty
        if docs is None:
            raise ValueError("Unable to load document...")
        
        print(">>>> CSV Loaded")
        return docs
    except ValueError as ve:
        logging.error("Error Occured %s", ve, exc_info=True)
        raise ValueError(f"ValueError while uploading CSV data: {str(ve)}")
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception("An error occurred while loading CSV:", str(e))
    

def create_Vector_docarray(docs, embedding):
    try:
        db = DocArrayInMemorySearch.from_documents(docs, embedding)
        return db
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"An error occurred while creating DocArray: {str(e)}")

    
def extract_test_case_ids(input_df):
    if 'testcaseId' in input_df.columns:
        test_case_ids = [str(id) if not isinstance(id, str) else id for id in input_df['testcaseId'].tolist()]
        return test_case_ids
    else:
        print("Warning! testcaseId not found...")
        return []


def response_temp(list1, max_tries):    
    try:
        llm = chat_completion_client()
        list1 = list1

        template = """You are a Test Case clustering agent. I will provide a list of Test Cases.\
        Group these test cases in a cluster of test cases if there are more than or \
        equal to 3 common test steps in description column. The cluster with maximum commom test steps put it \
        in a list form and give only one cluster list as specified below.
        ['testcaseId', ...]
        Here are the Test Cases : {list1}. 

        **Return me just a single list as:** \
        Eg Strictly output as single list:\
        ['test_case_id', 'test_case_id', ...]
        
        *Note: If two different lists or cluster give only one list in specified format as above"""

        prompt_template = PromptTemplate(input_variables=["list1"], template=template)
        duplicate_chain = LLMChain(llm=llm, prompt=prompt_template)

        input_tokens = token_calc(template, list1)
        #print("Num:", input_tokens)
        if isinstance(input_tokens, int) and input_tokens != 0:
            if input_tokens < 4000:
                response, prompt_dict = getting_response(duplicate_chain, list1, max_tries)
                time.sleep(3)
            else:
                print("WARNING: Grouping Failure...Trying again")
                raise Exception("Grouping Failure")

        tries = 0
        bool_val = False
        while tries < max_tries:
            try:
                output_list = ast.literal_eval(response)
                if isinstance(output_list, list):
                    bool_val = list_eval(output_list)
                    if bool_val:
                        break
                    else:
                        tries += 1        
            except (SyntaxError, ValueError) as e:
                logging.error("Error Occured %s", e, exc_info=True)
                tries += 1
                if tries < max_tries:
                    response, prompt_dict = getting_response(duplicate_chain, list1, max_tries)
                    try:
                        output_list = ast.literal_eval(response)
                    except Exception as e:
                        pass
                    if isinstance(output_list, list):
                        bool_val = list_eval(output_list)
                        if bool_val:
                            break
                    
        result_dict = prompt_dict
            
        if output_list and bool_val:
            print(f"Successfully generated list: {output_list}")
            return output_list, result_dict
        else:
            raise ValueError("Max retries reached, unable to evaluate the response string.")
             
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        output_list = []
        for doc in list1:
            parser = DocumentParser(doc)
            testcase_id = parser.extract_testcase_id()
            output_list.append(testcase_id)
        result_dict = { 'prompt_tokens': 0,
                        'total_tokens': 0,
                        'total_cost': 0,}
        return output_list, result_dict

def list_eval(lst):
    for item in lst:
        if not isinstance(item, str):
            return False
    return True

def getting_response(duplicate_chain, list_details, max_tries):
    list1 = list_details
    num_tries = max_tries  
    successful_try = False

    attempts = 0
    for _ in range(num_tries):
        try:
            with get_openai_callback() as cb:
                response = duplicate_chain.run(list1)
                result_dict = {
                    'prompt_tokens': cb.prompt_tokens,
                    'total_tokens': cb.total_tokens,
                    'total_cost': cb.total_cost,
                }
            successful_try = True 
            break  # Exit the loop if successful
        except Exception as e:
            logging.error("Error Occured %s", e, exc_info=True)
            attempts += 1
            print(f"Attempt {attempts}/{max_tries} failed: {str(e)}")

    if not successful_try:
        raise Exception(f"Maximum number of attempts reached. Unable to get response for {list1}")
    else:
        return response, result_dict


def update_cluster_list_for_duplicates(cluster_list, input_list):
    # Create a list to store items to be removed
    try:
        items_to_remove = []

        # Iterate through the input list
        for item in input_list:
            found = False
            for cluster in cluster_list:
                cluster_values = [value for sublist in cluster.values() for value in sublist]
                #print(cluster_values)
                if item in cluster_values:
                    # Add the item to the removal list
                    items_to_remove.append(item)
                    found = True
                    break

        # Remove the items from the input list
        updated_output_list = [item for item in input_list if item not in items_to_remove]
        print(f"**Test Case Removed : {items_to_remove}")

        return updated_output_list
    
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Invalid cluster List: {str(e)}")

def clean_document_list(document_list, doc_threshold):       
    try:
        unique_documents = {}
        for document, score in document_list:
            if score > doc_threshold:
                unique_documents[score] = document

        cleaned_document_list = list(unique_documents.values())

        return cleaned_document_list
    
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Empty Document list: {document_list} with error {str(e)}")
        cleaned_document_list = []
        return cleaned_document_list
    

def get_test_case_steps(test_case_id, input_df):
    try:
        # Convert test_case_id to a string
        test_case_id = str(test_case_id)
        
        if 'testcaseId' in input_df.columns and 'Description' in input_df.columns:
            # Convert 'testcaseId' column to a string for comparison
            input_df['testcaseId'] = input_df['testcaseId'].astype(str)
            mask = input_df['testcaseId'] == test_case_id
            matching_rows = input_df[mask]

            if not matching_rows.empty:
                return matching_rows.iloc[0]['Description']
                
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"Test Steps not found for {test_case_id}")


def cluster_and_merge(list_of_dicts_cluster, input_csv_path):
    try:
        # Create an empty DataFrame with the desired columns
        clustered_df = pd.DataFrame(columns=['Group', 'testcaseId'])

        # Iterate through the dictionary and populate the clustered DataFrame
        for cluster_dict in list_of_dicts_cluster:
            for cluster_name, test_case_ids in cluster_dict.items():
                for test_case_id in test_case_ids:
                    # Convert test_case_id to string
                    test_case_id = str(test_case_id)
                    clustered_df = pd.concat([clustered_df, 
                                              pd.DataFrame({'Group': [cluster_name],
                                                            'testcaseId': [test_case_id]})],
                                                            ignore_index=True)

        # Read the original DataFrame from the CSV file
        
        actual_df = pd.read_csv(input_csv_path,encoding=utility.detect_encoding(input_csv_path))


        # Convert 'testcaseId' column to string for the original DataFrame
        actual_df['testcaseId'] = actual_df['testcaseId'].astype(str)

        # Merge the original DataFrame with the clustered DataFrame based on 'testcaseId'
        result_df = actual_df.merge(clustered_df, on='testcaseId', how='left')
        result_df['Group'] = result_df['Group'].astype(int)
        result_df = result_df.sort_values(by="Group")
        # print(f"Final Result Dataframe: {result_df.head(3)}")

        return result_df
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"An error occurred in cluster: {str(e)}")


def num_tokens_from_string(string: str, encoding_name: str) -> int:
    try:
        """Returns the number of tokens in a text string."""
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        e = print(f"Error while counting tokens: {str(e)}")
    

def extract_text_from_csv(csv_file):
    try:
        text = ""
        with open(csv_file, 'r', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                for key, value in row.items():
                    if key != "Title":
                        text += value + " "
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        text = ""
        print(f"**Warning: Text not present...")

    return text
       
def process_output(output_list, list_of_dicts_cluster, filtered_list2, i):
    try:
        cluster_key = f"{i}"
        cluster_dict = {cluster_key: output_list}
        list_of_dicts_cluster.append(cluster_dict)
        filtered_list2 = [item for item in filtered_list2 if item not in output_list]
        print(f"Filtered list here: {filtered_list2} \n")
        
        return list_of_dicts_cluster, filtered_list2
        
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"Error while processing Dictionary: {str(e)}")
        
def save_selected_columns_to_csv(dataframe, file_name):
    #selected_columns = ["Link", "testcaseId", "Title", "Description", "Environment", "FeatureName",
    #                    	"Created Date", "Priority", "Automated", "testtype", "Group"]
    selected_columns = ['testcaseId', 'Title', 'Group'] 
    
    try:
        #print(dataframe)
        selected_dataframe = dataframe[selected_columns]
        selected_dataframe.to_csv(file_name, index=False)
        print(f"Selected columns saved as {file_name}")
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Error in saving CSV file: {e}")


def dataframe_to_markdown(df):
    """
    Convert a Pandas DataFrame to a Markdown table.

    Args:
    df (pd.DataFrame): The DataFrame to convert.

    Returns:
    str: The Markdown representation of the DataFrame as a table.
    """
    try:
        selected_columns = ['testcaseId', 'Title', 'Group'] 
        df = df[selected_columns]
        markdown_table = df.to_markdown(index=False)
        updated_markdown_content = markdown_table.replace("testcaseId", "Test Case ID")
        return updated_markdown_content
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Error while creating markdown: {e}")
        markdown_table = "Clustering done unable to get dataframe..."
        return markdown_table
    # Convert the DataFrame to a Markdown table 

def summ_md(result_df, file_name):
    try:
        df = result_df
        summary_data = df.groupby('Group')['testcaseId'].apply(lambda x: ', '.join(x)).reset_index()

        markdown_table = f"\n - File name: {file_name} \n - Number of Test Cases: {len(df)} \n - Groups: {df['Group'].iloc[-1]} \n\n"
        #markdown_table += "\n"
        #markdown_table += "| Group | Test Case Id's |\n| ------- | -------------- |\n"
        #for index, row in summary_data.iterrows():
        #    markdown_table += f"| {row['Group']}       | {row['testcaseId']} |\n"

        # print(markdown_table)
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Unable to create Markdown table: {str(e)}")

    return markdown_table

def merge_md(df_markdown, final_err_report, responseTree):
    fin_md ="\n\n" + "\n" + df_markdown
    if final_err_report == "":
        final_err_report = "<font color='blue'>No Security Threat Detected!!</font>\n\n" 
        fin_md += "\n\n" + " " + "\n" + "# Security Scanner Summary: " + "\n" + final_err_report
    elif final_err_report == "False":
        fin_md += "\n\n" + " " + "\n"
    else:
        fin_md += "\n\n" + " " + "\n" + "# Security Scanner Summary: " + "\n" + final_err_report

    return fin_md


# #Changing to default llm_call for max_retries and max_new_tokens
# def response_generation():
#     try:
#         template = TREE.format(TCs=TCs)
#         print("Template here")
#         print(f"\n {template}\n")
#         final_response = llm_call(final_prompt=template, role_msg=role_msg, log_name=log_name)
#         print(f"Response Here: {final_response}")
#         return final_response
#     except Exception as e:
#         print("WARNING: Unable to generate response...")
#         return None


#change max tries implementation to default
def response_tree(list1, max_tries, model_name):
    """_summary_

    Returns:
        string: Tree Structure
    """ 
    try:
        llm = chat_completion_client()
        list1 = list1

        template = """Form a tree structure for the test cases based on the group id, and join in a \
        pipe structure along with there testcaseId. Here the nodes of the tree will be the test case IDs.\
        The List is here as follows: {list1}.
        """

        try:
            input_tokens = token_calc(template, list1)
            print("Num:", input_tokens)
        except Exception as e:
            input_tokens = 12000

        prompt_template = PromptTemplate(input_variables=["list1"], template=template)
        duplicate_chain = LLMChain(llm=llm, prompt=prompt_template)

        llm_model, config, temperature, max_tokens = get_config()

        #Change this take from UI -- Done
        #Right now openai = 8192
        #How to get max limits of a given model
        #

        MAX_TOKENS = 1800 if model_name == "Meta Llama2" else 4000
        if model_name == "Meta Llama2":
            if input_tokens < MAX_TOKENS:
                response, prompt_dict = getting_response(duplicate_chain, list1, max_tries)
            else:
                num_sublists = math.ceil(input_tokens/MAX_TOKENS)
                indices = split_list_indices(list1, num_sublists)
                res = ""
                for index in indices:
                    l1 = list1[index[0]:index[1]]
                    r1, prompt_dict = getting_response(duplicate_chain, l1, max_tries)
                    res += r1
                response = res
        else:
            if input_tokens < MAX_TOKENS:
                response, prompt_dict = getting_response(duplicate_chain, list1, max_tries)
            else:
                num_sublists = math.ceil(input_tokens/MAX_TOKENS)
                indices = split_list_indices(list1, num_sublists)
                res = ""
                for index in indices:
                    l1 = list1[index[0]:index[1]]
                    r1, prompt_dict = getting_response(duplicate_chain, l1, max_tries)
                    res += r1
                response = res

        return response, prompt_dict
        
    except Exception as e:
        logging.error("Failed in 'response_tree' %s", e, exc_info=True)
        print("Unable to generate cluster tree")
        documents = list1
        tree_root = build_tree(documents)
        tree_string = "\n```"
        tree_string += tree_to_string(tree_root)
        tree_string += "```"
        return tree_string, {'prompt_tokens': 0, 'total_tokens': 0, 'total_cost': 0,}

class TreeNode:
    def __init__(self, value):
        self.value = value
        self.children = []

def build_tree(documents):
    groups = {}

    for doc in documents:
        group_num = doc.metadata.get('Group')
        if group_num not in groups:
            groups[group_num] = []
        groups[group_num].append(doc)
    
    root = TreeNode("Root")
    for group_num, docs in groups.items():
        group_node = TreeNode("Group {}".format(group_num))
        for doc in docs:
            doc_node = TreeNode("- {}".format(doc.page_content))
            group_node.children.append(doc_node)
        root.children.append(group_node)
    
    return root

def tree_to_string(node, level=0):
    result = ""
    if node.value != "Root":
        result += "|" + "-" * level * 1 + node.value + "\n"
    else:
        result += node.value + "\n"
    for child in node.children:
        result += tree_to_string(child, level + 1)
    return result

def split_list_indices(lst, num_sublists):
    try:
        sublist_size = len(lst) // num_sublists
        remainder = len(lst) % num_sublists
        indices = []
        start = 0
        for i in range(num_sublists):
            end = start + sublist_size + (1 if i < remainder else 0) - 1
            indices.append((start, end))
            start = end + 1
        return indices
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"Failed while chunking...")

def getting_response(duplicate_chain, list_details, max_tries):
    list1 = list_details
    num_tries = max_tries  
    successful_try = False

    attempts = 0
    for _ in range(num_tries):
        try:
            with get_openai_callback() as cb:
                response = duplicate_chain.run(list1)
                result_dict = {
                    'prompt_tokens': cb.prompt_tokens,
                    'total_tokens': cb.total_tokens,
                    'total_cost': cb.total_cost,
                }
            successful_try = True 
            break  # Exit the loop if successful
        except Exception as e:
            attempts += 1
            print(f"Attempt {attempts}/{max_tries} failed: {str(e)}")

    if not successful_try:
        raise Exception(f"Maximum number of attempts reached. Unable to get response for {list1}")
    else:
        return response, result_dict


def dataforclustertree(df):

    try:
        selected_columns = ['testcaseId', 'Title', 'Group'] 
        df = df[selected_columns]
        loader = DataFrameLoader(df, page_content_column= 'testcaseId')
        result_data = loader.load()

        return result_data

    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print("Warning! Unable to get data for cluster tree...")

        return None

def res_grpid_des(clusterlist, dataframe, max_tries):
    try:
        columns = ['Group ID', 'Group Name', 'Test Case ID', 'Description']
        df = dataframe
        df_result = pd.DataFrame(columns=columns)
        response = None
        for item in clusterlist:
            for key, values in item.items():
                temp_df = df[df['testcaseId'].isin(values)]
                list_of_dicts = temp_df.to_dict(orient='records')
                for _ in range(max_tries):
                    try:
                        response, _ = common_response_temp(list1=list_of_dicts, max_tries=max_tries)
                        time.sleep(3)
                        break
                    except Exception as e:
                        print(f"Rate limit exceeded. Waiting for 29 seconds. Error: {str(e)}")
                        time.sleep(29)
                print(f"\n********{key}******\n") 

                try:
                    response = str(response.replace("\n", " ").replace("  ", ""))
                    split_strings = [part.strip() for part in response.split('|')]
                    before_pipe = split_strings[0]
                    after_pipe = split_strings[1]
                    ids = ', '.join(map(str, values))
                    df_result = pd.concat([df_result, pd.DataFrame({'Group ID': [key], 'Group Name': [before_pipe], 'Test Case ID': [ids], 'Description': [after_pipe]})], ignore_index=True)
                except Exception as e:
                    df_result = pd.concat([df_result, pd.DataFrame({'Group ID': [key], 'Group Name': ['NA'], 'Test Case ID': [', '.join(map(str, values))], 'Description': ['NA']})], ignore_index=True)
                # print('\nres_grpid_des\n\n')
                # print(f"\n UI result: \n {df_result.head(2)}")
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Warning Unable to get Group Description: {str(e)}")
        df_result = pd.DataFrame(columns=columns)
    return df_result  

def common_response_temp(list1, max_tries):    
    try:
        llm = chat_completion_client()
        list1 = list1

        # template = """You are a Tester. I will provide Test Cases.\
        # Provide a brief description in 10-15 words of the given test cases in strictly single sentence without testcaseid.\ 
        # In this format:
        # Group Name strictly in 1-2 words based on titles | Description for all test cases

        # Here are the test case/test cases {list1}
        # """
        template = create_template(list1)

        prompt_template = PromptTemplate(input_variables=["list1"], template=template)
        duplicate_chain = LLMChain(llm=llm, prompt=prompt_template, verbose=False)

        response, prompt_dict = getting_response(duplicate_chain, list1, max_tries)
        # print(f"Response Here: {response}")
        
        return response, prompt_dict
    
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"Unable to generate response try again...")
    
def create_template(list1):
    template = """You are a Tester. I will provide Test Cases.\
    Provide a brief description in 10-15 words of the given test cases in strictly single sentence without testcaseid.\ 
    In this format:
    Group Name strictly in 1-2 words based on titles | Description for all test cases

    Here are the test case/test cases {list1}
    """
    return template

def dftomd(dataframe):
    md = dataframe.to_markdown(index=False)
    return md

def template_for_grp_des(list1):

    template = f"""You are a Tester. I will provide a Merged Test Case.\
        Provide a brief description of that merged test case in the given format as: \
        The Merged Test Cases are ....
        
        Here is the test case {list1}"""
    
    return template

def save_dataframe(dataframe, file_name):
    file_extension = os.path.splitext(file_name)[-1].lower()
    
    try:
        if file_extension == '.csv':
            dataframe.to_csv(file_name, index=False)
        elif file_extension == '.xlsx':
            dataframe.to_excel(file_name, index=False)
        else:
            print("File not found...")
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print("Unable to save CSV file...")
    return None

def group_name_func(csv_path, dataframe):
    try:
        DF1 = pd.read_csv(csv_path)
        DF2 = dataframe

        DF1['Group'] = DF1['Group'].astype(str)
        DF2['Group ID'] = DF2['Group ID'].astype(str)

        merged_df = pd.merge(DF1, DF2, left_on='Group', right_on='Group ID')
        DF1['Group Name'] = merged_df['Group Name']

        print("\n****************\n")
        # print(DF1.head(2))

    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"\nUnable to merge group names {str(e)} \n")
        
    return DF1

class DocumentParser:
    def __init__(self, document):
        self.page_content = document.page_content
        self.metadata = document.metadata

    def extract_testcase_id(self):
        lines = self.page_content.split('\n')
        for line in lines:
            key, _, value = map(str.strip, line.partition(':'))
            if key == 'testcaseId':
                return value

        return None
    
def token_calc(template, list1):
    try:
        Prompt = f"{template} {list1}"
        num = num_tokens_from_string(string = str(Prompt), encoding_name = "cl100k_base")
        return num
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Error calculating max tokens in prompt: {str(e)}")
        return 0
    
def response_temp_Llama(list1, max_tries):    
    try:
        llm = chat_completion_client()
        list1 = list1

        template = create_template_llama(list1)

        prompt_template = PromptTemplate(input_variables=["list1"], template=template)
        duplicate_chain = LLMChain(llm=llm, prompt=prompt_template, verbose=False)

        response, prompt_dict = getting_response(duplicate_chain, list1, max_tries)
        # print(f"Response Here: {response}")
        
        return response, prompt_dict
    
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"Unable to generate response try again...")
    
def create_template_llama(list1):
    template = """You are a Tester. I will provide Test Cases.\
    Provide a short description of the given test cases in strictly single sentence without testcaseid.\ 
    In this format given as:
    Example:
        Group Name: 
        Description: 

    Here are the test case/test cases {list1}.
    """
    return template


def res_grpid_des_llama2(clusterlist, dataframe, max_tries):
    try:
        columns = ['Group ID', 'Group Name', 'Test Case ID', 'Description']
        df = dataframe
        df_result = pd.DataFrame(columns=columns)
        response = None
        # print(clusterlist)
        for item in clusterlist:
            # print(item)
            for key, values in item.items():
                # print(key, response)
                temp_df = df[df['testcaseId'].isin(values)]
                # print(temp_df)
                list_of_dicts = temp_df.to_dict(orient='records')
                # print(list_of_dicts)
                for _ in range(max_tries):
                    try:
                        response, _ = response_temp_Llama(list1 = list_of_dicts, max_tries=max_tries)
                        break
                    except Exception as e:
                        logging.error("Error Occured %s", e, exc_info=True)
                        print(f"Rate limit exceeded. Waiting for 29 seconds. Error: {str(e)}")
                print(f"\n********{key}******\n") 
                # print(response)
       
                try:
                    pattern = r'Group Name: (.*?)\nDescription: (.*?)\n'
                    matches = re.findall(pattern, str(response))
                    group_name = "NA"
                    description = "NA"
                    for match in matches:
                        group_name, description = match
                        print(f"Group Name: {group_name}\nDescription: {description}\n")
                    ids = ', '.join(map(str, values))
                    df_result = pd.concat([df_result, pd.DataFrame({'Group ID': [key], 'Group Name': [group_name], 'Test Case ID': [ids], 'Description': [description]})], ignore_index=True)
                except Exception as e:
                    logging.error("Error Occured %s", e, exc_info=True)
                    df_result = pd.concat([df_result, pd.DataFrame({'Group ID': [key], 'Group Name': ['NA'], 'Test Case ID': [', '.join(map(str, values))], 'Description': ['NA']})], ignore_index=True)
                # print('\nres_grpid_des\n\n')
                # print(f"\n UI result: \n {df_result.head(2)}")
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Warning Unable to get Group Description: {str(e)}")
        df_result = pd.DataFrame(columns=columns)
    return df_result 

def get_threshold_value():
    try:
        llm_model, embedding_config = get_embedding_config()
        value = int(embedding_config["similarity_score"])/100
        print(f">> Embedding Similarity Threshold: {value}")
        return value
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print("Warning: Unable to get threshold value, setting default value to 92%")
        return float(0.92)


def res_grpid_des_llama2_based_json(clusterlist, dataframe, max_tries):
    try:
        columns = ['Group ID', 'Group Name', 'Test Case ID', 'Description']
        df = dataframe
        df_result = pd.DataFrame(columns=columns)
        response = None
        for item in clusterlist:
            for key, values in item.items():
                temp_df = df[df['testcaseId'].isin(values)]
                list_of_dicts = temp_df.to_dict(orient='records')
                for _ in range(max_tries):
                    try:
                        response, _ = response_temp_Llama_json(list1 = list_of_dicts, max_tries=max_tries)
                        break
                    except Exception as e:
                        print(f"Rate limit exceeded. Waiting for 29 seconds. Error: {str(e)}")

                try:
                    group_name, description = grp_name_and_description_parsing(response)
                    if group_name == "NA" and description == "NA":
                        json_objects = cleaning_and_extracting_json(response)
                        if json_objects != [] or json_objects is not None:
                            json_object = json_objects[0]
                            group_name, description = json_processing(json_object)
                    ids = ', '.join(map(str, values))
                    df_result = pd.concat([df_result, pd.DataFrame({'Group ID': [key], 'Group Name': [group_name], 'Test Case ID': [ids], 'Description': [description]})], ignore_index=True)
                    
                except Exception as e:
                    logging.error("Error Occured %s", e, exc_info=True)
                    df_result = pd.concat([df_result, pd.DataFrame({'Group ID': [key], 'Group Name': ['NA'], 'Test Case ID': [', '.join(map(str, values))], 'Description': ['NA']})], ignore_index=True)
                    
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Warning Unable to get Group Description: {str(e)}")
        df_result = pd.DataFrame(columns=columns)
    return df_result

def json_processing(dictionary: dict):
    group_name = "NA"
    description = "NA"
    try:
        for key, value in dictionary.items():
            if isinstance(value, str):
                if key == 'Group Name' or key == 'Group':
                    group_name = f"{extract_string(value)}"
                elif key == 'Description':
                    description = f"{extract_string(value)}"
            elif value is None:
                if key == 'Group Name' or key == 'Group':
                    group_name = f"{extract_string(value)}"
                elif key == 'Description':
                    description = f"{extract_string(value)}"
        return group_name, description
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Failed Extraction: {str(e)}")
        return "NA", "NA"
    
def extract_string(value):
    return str(value)

def extract_null(value):
    return " " 

def grp_name_and_description_parsing(response: str):
    try:
        pattern = r'Group Name: (.*?)\nDescription: (.*?)\n'
        matches = re.findall(pattern, str(response))
        if matches == []:
            pattern = r'Group : (.*?)\nDescription: (.*?)\n'
            matches = re.findall(pattern, str(response))
            if matches == []:
                pattern = r'Group Name: (.*?)\n\nDescription: (.*?)\n'
                matches = re.findall(pattern, str(response))
                if matches == []:
                    pattern = r'Group : (.*?)\n\nDescription: (.*?)\n'
                    matches = re.findall(pattern, str(response))
            
        group_name = "NA"
        description = "NA"
        for match in matches:
            group_name, description = match

        return group_name, description
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print("WARNING: Unable to parse group name and description")
        return "NA", "NA"

def response_temp_Llama_json(list1, max_tries):    
    try:
        llm = chat_completion_client()
        list1 = list1
        template = create_template_llama_json(list1)
        prompt_template = PromptTemplate(input_variables=["list1"], template=template)
        duplicate_chain = LLMChain(llm=llm, prompt=prompt_template, verbose=False)
        response, prompt_dict = getting_response(duplicate_chain, list1, max_tries)     
        return response, prompt_dict
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        raise Exception(f"Unable to generate response try again...")
    
def create_template_llama_json(list1):
    template = """You are a Tester. I will provide Test Cases.\
    Provide a group name and short description of the given group test cases in strictly single sentence without testcaseid.\ 
    In this format given as:
    Example:
    {{
        "Group Name": " ",
        "Description": " "
    }}
    Here are the test case/test cases {list1}.
    """
    return template

def cleaning_and_extracting_json(response: str):

    pattern = r'\{(?:[^{}]|(?:\{(?:[^{}]|[^{}]*)*\}))*\}'
    try:
        json_strings = re.findall(pattern, response)
        json_objects = [json.loads(json_string) for json_string in json_strings]

        return json_objects
    except Exception as e:
        logging.error("Error Occured %s", e, exc_info=True)
        print(f"Unable to process response: {str(e)}")