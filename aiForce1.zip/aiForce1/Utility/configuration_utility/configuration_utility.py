"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import json
import os
import configparser
# Don't remove the below import its required for cost calculator
import math 
from Utility.db_utility import db_utility as db_utils
import ast

cwdPath = os.path.abspath(os.getcwd())
config_path = os.path.join(cwdPath, "config")
config_parser = configparser.ConfigParser()
config_parser.read(os.path.join(config_path, "formulas.ini"))
phases = ["Development", "Testing", "Support", "Program Management"]


######### LLM Configuration Settings ########
def check_llmconfiguration_exists(request):
    org_id = request.GET['org_id']
    result = db_utils.check_llmconfiguration_exists(org_id)
    return result


def get_llmconfiguration(request):
    org_id = request.GET['org_id']
    llm_model = request.GET['llm_model']
    result = db_utils.get_llmconfiguration(org_id, llm_model)
    return result


def save_llmconfiguration(request):
    llm_models = ["Azure Open AI GPT 3.5 Turbo", "Meta Llama2"]
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    org_id = json_req['org_id']
    llm_model = json_req['llm_model']
    temperature = json_req['temperature']
    max_token = json_req['max_token']

    if llm_model == llm_models[0]:
        openai_endpoint = json_req['openai_endpoint']
        openai_key = json_req['openai_key']
        openai_api_version = json_req['openai_api_version']
        openai_api_type = json_req['openai_api_type']
        openai_deployment = json_req['openai_deployment']
        openai_service_type = json_req['openai_service_type']
        openai_model_type = json_req['openai_model_type']

        config = {"llm_model": llm_model, "temperature": temperature, "max_token": max_token,
                  "openai_endpoint": openai_endpoint, "openai_key": openai_key,
                  "openai_api_version": openai_api_version, "openai_api_type": openai_api_type,
                  "openai_deployment": openai_deployment, "openai_model_type": openai_model_type,
                  "openai_service_type": openai_service_type}
    elif llm_model == llm_models[1]:
        llama_endpoint = json_req['llama_endpoint']
        llama_region = json_req['llama_region']
        llama_accesskey = json_req['llama_accesskey']
        llama_secretkey = json_req['llama_secretkey']
        llama_service_type = json_req['llama_service_type']
        llama_model_type = json_req['llama_model_type']

        config = {"llm_model": llm_model, "temperature": temperature, "max_token": max_token,
                  "llama_endpoint": llama_endpoint, "llama_region": llama_region, "llama_accesskey": llama_accesskey,
                  "llama_secretkey": llama_secretkey, "llama_model_type": llama_model_type,
                  "llama_service_type": llama_service_type}
    else:
        config = json_req

    llm_conf_exists = False
    res = db_utils.check_llm_conf_exists(org_id, llm_model)
    if res['message'] == "Success":
        if len(res['data']) != 0:
            llm_conf_exists = True

    if llm_conf_exists:
        response = db_utils.update_llm_configuration(org_id, llm_model, config)
    else:
        response = db_utils.save_llm_configuration(org_id, llm_model, config)
    return response


def get_active_llm_configuration():
    response = db_utils.get_active_llm_configuration()
    if response['message'] == "Success":
        if len(response['data']) > 0:
            active_config = response['data'][0]
            llm_model = active_config['llm_model'].lower()
            config = active_config['config']
            return llm_model, config
        else:
            return None, None
    else:
        return None, None


def get_active_llm_embedding_configuration():
    response = db_utils.get_active_llm_embedding_configuration()
    if response['message'] == "Success":
        if len(response['data']) > 0:
            active_config = response['data'][0]
            llm_model = active_config['llm_model'].lower()
            config = active_config['config']
            return llm_model, config
        else:
            return None, None
    else:
        return None, None


### Security (LLM Guard) Configuration
def save_security_config(request):
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    org_id = json_req['org_id']
    scanner_status = json_req['scanner_status']
    input_scanner = str(list(json_req['input_scanner']))
    output_scanner = str(list(json_req['output_scanner']))
    additional_info = json_req['additional_info']

    configuration_exists = False
    res = db_utils.check_security_config_exists(org_id)
    if res['message'] == "Success":
        if int(res['data'][0]['count']) != 0:
            configuration_exists = True

    if configuration_exists:
        response = db_utils.update_security_config(org_id, scanner_status, input_scanner, output_scanner,
                                                   additional_info)
    else:
        response = db_utils.save_security_config(org_id, scanner_status, input_scanner, output_scanner, additional_info)
    return response


def get_security_config(request):
    org_id = request.GET['org_id']
    result = db_utils.get_security_config(org_id)
    return result


def save_keywords(request):
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    org_id = json_req['org_id']
    module = json_req['module']
    radio_scanner = json_req['radio_scanner']
    keywords = json_req['keywords']

    keywords_exists = False
    res = db_utils.check_keywords_exists(org_id)
    if res['message'] == "Success":
        if int(res['data'][0]['count']) != 0:
            keywords_exists = True
    if keywords_exists:
        response = db_utils.update_keywords(org_id, module, radio_scanner, keywords)
    else:
        response = db_utils.insert_keywords(org_id, module, radio_scanner, keywords)
    return response


def get_keywords(request):
    org_id = request.GET['org_id']
    radio_scanner = request.GET['radio_scanner']
    result = db_utils.get_keywords(org_id, radio_scanner)
    return result


########### TFS Configuration ############

def save_tfs_config(request):
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body).get('params')
    org_id = json_req.get('org_id')
    repo_url = json_req.get('repo_url')
    pat = json_req.get('pat')
    org_name = json_req.get('org_name')
    proj_name = json_req.get('proj_name')
    repo_name = json_req.get('repo_name')
    datasource_type = json_req.get('type')
    db_utils.create_repoconfig()

    print("#" * 40, "pre")

    org_id_exists = False
    res = db_utils.check_tfsconfig_exist(org_id, datasource_type)
    if res['message'] == "Success":
        if len(res['data']) != 0:
            org_id_exists = True

    print("#" * 40, org_id_exists)

    # Leaving previous flow as it is
    configDict = json_req if datasource_type else None

    if org_id_exists:
        response = db_utils.update_tfs_config(repo_url, pat, org_name, proj_name, repo_name, org_id,
                                              configDict=configDict)
    else:
        response = db_utils.save_tfs_config(repo_url, pat, org_name, proj_name, repo_name, org_id,
                                            configDict=configDict)
    return response


def get_tfs_config(request):
    org_id = request.GET['org_id']
    result = db_utils.get_tfs_config(org_id)
    return result


### For Embedding Configuration
def check_emb_configuration_exists(request):
    org_id = request.GET['org_id']
    result = db_utils.check_emb_configuration_exists(org_id)
    return result


def check_llmconfiguration_exists(request):
    org_id = request.GET['org_id']
    result = db_utils.check_llmconfiguration_exists(org_id)
    return result


def get_embedding_configuration(request):
    org_id = request.GET['org_id']
    llm_model = request.GET['llm_model']
    result = db_utils.get_embedding_configuration(org_id, llm_model)
    return result


def get_embedding_model_base_path():
    cwd_path = os.path.abspath(os.getcwd())
    assets_root_path = os.path.join(cwd_path, "Assets")
    model_base_path = os.path.join(assets_root_path, "Models")
    return model_base_path

def model_folder_exists(llm_model):
    embedding_model_path = get_embedding_model_base_path()
    print(os.path.join(embedding_model_path, llm_model))
    return os.path.exists(os.path.join(embedding_model_path, llm_model))


def save_embedding_configuration(request):
    llm_models = ["Azure Open AI GPT 3.5 Turbo", "Non Open AI Model"]
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    org_id = json_req['org_id']
    llm_model = json_req['llm_model']
    similarity_score = json_req['similarity_score']

    if llm_model == llm_models[0]:
        openai_deployment = json_req['openai_deployment']
        openai_api_type = json_req['openai_api_type']
        openai_endpoint = json_req['openai_endpoint']
        openai_key = json_req['openai_key']
        openai_api_version = json_req['openai_api_version']
        openai_service_type = json_req['openai_service_type']
        openai_model_type = json_req['openai_model_type']
        config = {"llm_model": llm_model, "similarity_score": similarity_score, "openai_endpoint": openai_endpoint,
                  "openai_key": openai_key, "openai_api_version": openai_api_version,
                  "openai_api_type": openai_api_type, "openai_deployment": openai_deployment,
                  "openai_model_type": openai_model_type, "openai_service_type": openai_service_type}
    else:
        if model_folder_exists(llm_model):
            config = {"llm_model": llm_model, "similarity_score": similarity_score}
        else:
            return {
                "status": "Failed",
                "message": "Selected local embedding model is not configured. Refer section 5.5 in the installation guide to "
                           "configure local embedding models"
            }

    embedding_conf_exists = False
    res = db_utils.check_embedding_conf_exists(org_id, llm_model)
    if res['message'] == "Success":
        if len(res['data']) != 0:
            embedding_conf_exists = True

    config = json.dumps(config)

    response = db_utils.save_update_embedding_configuration(org_id, llm_model, config, embedding_conf_exists)
    return {"status": response, "message": "Configuration Saved Successfully."}


##### #### ### ## # COST CALCULATOR START # ## ### #### #####
def save_effortweightage(request):
    try:
        req_body = request.body.decode('utf-8')
        json_req = json.loads(req_body)['params']
        phase_values = json_req['phase_values']

        for phase_value in phase_values:
            id = phase_value['id']
            effort_weightage = phase_value['effort_weightage']
            benefit_potential = phase_value['benefit_potential']
            impl_time_ops_cost = phase_value['impl_time_ops_cost']
            finetune_cycle = phase_value['finetune_cycle']
            billrate_type = phase_value['billrate_type']
            custom_billrate = phase_value['custom_billrate']
            monthly_usage = phase_value['monthly_usage']
            data_obj = [effort_weightage, benefit_potential, impl_time_ops_cost, finetune_cycle, billrate_type,
                        custom_billrate, monthly_usage, id]
            res = db_utils.updateeffortweightage(data_obj)
        return "Success"
    except Exception as e:
        print("Error in save effort weightage", str(e))
        return "Failed"


def restore_effortweightage(request):
    try:
        req_body = request.body.decode('utf-8')
        json_req = json.loads(req_body)['params']
        phase = json_req['phase']
        res = db_utils.restore_effortweightage(phase)
        return "Success"
    except Exception as e:
        print(e)
        return "Failed"


def checkNA(val):
    if val == "Not Applicable" or val == "N/A":
        return True
    else:
        return False


def checkZero(val):
    if val == 0:
        return True
    else:
        return False


def checkZeros(val1, val2):
    if val1 == 0 or val2 == 0:
        return True
    else:
        return False


def checkOfflineModel(val):
    if val.startswith("Offline"):
        return True
    else:
        return False


def checkOnlineModel(val):
    if val.startswith("Online"):
        return True
    else:
        return False


def checkAWSTitanModel(val):
    if val == "Online AWS Bedrock Titan":
        return True
    else:
        return False


def checkBlended(val):
    if val == "Blended":
        return True
    else:
        return False


def getExpectedBenefit():
    ExpectedBenefit = {}
    res = db_utils.getExpectedBenefit()
    for row in res:
        ExpectedBenefit[row['potential']] = row['expected_benefit']
    # print (ExpectedBenefit)
    return ExpectedBenefit


def getImplTime_OpsCost():
    ImplTime, OpsCost = {}, {}
    res = db_utils.getImplTime_OpsCost()
    for row in res:
        ImplTime[row['parameter']] = row['months']
        OpsCost[row['parameter']] = row['ops_cost_multifier']
    # print (ImplTime)
    # print (OpsCost)
    return ImplTime, OpsCost


def getFineTuningCycle(phases):
    FineTuningCycle = {}
    res = db_utils.getFineTuningCycle()
    for phase in phases:
        Phase_FTCycle = {}
        for row in res:
            phase_name = phase.replace(" ", "_").lower()
            Phase_FTCycle[row['finetune_cycle']] = row[phase_name]
        FineTuningCycle[phase] = Phase_FTCycle
    # print (FineTuningCycle)
    return FineTuningCycle


def getMonthlyUsageFrequency():
    MonthlyUsageFrequency = {}
    res = db_utils.getMonthlyUsageFrequency()
    for row in res:
        MonthlyUsageFrequency[row['parameter']] = row['monthly_usage']
    # print (MonthlyUsageFrequency)
    return MonthlyUsageFrequency


def getOtherConstants():
    OtherConstants = {}
    res = db_utils.getOtherConstants()
    for row in res:
        OtherConstants[row['constant_name']] = row['constant_value']
    # print (OtherConstants)
    return OtherConstants


def getSplitFinetunePerc(artifact_type):
    SplitFinetunePerc = {}
    res = db_utils.getSplitFinetunePerc(artifact_type)
    for row in res:
        for phase in phases:
            phase_name = phase.replace(" ", "_").lower()
            SplitFinetunePerc[phase] = row[phase_name]
    # print (SplitFinetunePerc)
    return SplitFinetunePerc


def handleCodeFinetunePerc(CodeFinetunePercDefault, request):
    req_body = request.body.decode('utf-8')
    json_req_main = json.loads(req_body)['params']
    json_req = json_req_main['ui_input']

    dev = json_req["dev"]
    test = json_req["test"]

    dev_team = json_req["dev_team"]
    test_team = json_req["test_team"]

    if (checkZeros(dev, dev_team)) and (checkZeros(test, test_team)):
        CodeFinetunePercDefault[phases[1]] = 0
        CodeFinetunePercDefault[phases[0]] = 0
    else:
        if checkZeros(dev, dev_team):
            CodeFinetunePercDefault[phases[0]] = 0
            CodeFinetunePercDefault[phases[1]] = 100
        elif checkZeros(test, test_team):
            CodeFinetunePercDefault[phases[0]] = 100
            CodeFinetunePercDefault[phases[1]] = 0

    return CodeFinetunePercDefault


def handleDocumentFinetunePerc(DocumentFinetunePercDefault, request):
    req_body = request.body.decode('utf-8')
    json_req_main = json.loads(req_body)['params']
    json_req = json_req_main['ui_input']

    dev = json_req["dev"]
    test = json_req["test"]
    support = json_req["support"]
    pm = json_req["pm"]

    dev_team = json_req["dev_team"]
    test_team = json_req["test_team"]
    support_team = json_req["support_team"]
    pm_team = json_req["pm_team"]
    # IF ALL PRESENT
    if not checkZeros(dev, dev_team) and not checkZeros(test, test_team) and not checkZeros(support,
                                                                                            support_team) and not checkZeros(
            pm, pm_team):
        DocumentFinetunePercDefault = DocumentFinetunePercDefault
    else:
        # IF DEV ONLY NOT PRESENT
        if checkZeros(dev, dev_team) and not checkZeros(test, test_team) and not checkZeros(support,
                                                                                            support_team) and not checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 0
            DocumentFinetunePercDefault[phases[1]] = 30
            DocumentFinetunePercDefault[phases[2]] = 60
            DocumentFinetunePercDefault[phases[3]] = 10
        # IF TEST ONLY NOT PRESENT
        elif not checkZeros(dev, dev_team) and checkZeros(test, test_team) and not checkZeros(support,
                                                                                              support_team) and not checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 5
            DocumentFinetunePercDefault[phases[1]] = 0
            DocumentFinetunePercDefault[phases[2]] = 90
            DocumentFinetunePercDefault[phases[3]] = 5
        # IF SUPPORT ONLY NOT PRESENT
        elif not checkZeros(dev, dev_team) and not checkZeros(test, test_team) and checkZeros(support,
                                                                                              support_team) and not checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 5
            DocumentFinetunePercDefault[phases[1]] = 90
            DocumentFinetunePercDefault[phases[2]] = 0
            DocumentFinetunePercDefault[phases[3]] = 5
        # IF PM ONLY NOT PRESENT
        elif not checkZeros(dev, dev_team) and not checkZeros(test, test_team) and not checkZeros(support,
                                                                                                  support_team) and checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 10
            DocumentFinetunePercDefault[phases[1]] = 30
            DocumentFinetunePercDefault[phases[2]] = 60
            DocumentFinetunePercDefault[phases[3]] = 0
        # IF DEV & TEST NOT PRESENT
        elif checkZeros(dev, dev_team) and checkZeros(test, test_team) and not checkZeros(support,
                                                                                          support_team) and not checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 0
            DocumentFinetunePercDefault[phases[1]] = 0
            DocumentFinetunePercDefault[phases[2]] = 90
            DocumentFinetunePercDefault[phases[3]] = 10
        # IF DEV & SUPPORT NOT PRESENT
        elif checkZeros(dev, dev_team) and not checkZeros(test, test_team) and checkZeros(support,
                                                                                          support_team) and not checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 0
            DocumentFinetunePercDefault[phases[1]] = 90
            DocumentFinetunePercDefault[phases[2]] = 0
            DocumentFinetunePercDefault[phases[3]] = 10
        # IF DEV & PM NOT PRESENT
        elif checkZeros(dev, dev_team) and not checkZeros(test, test_team) and not checkZeros(support,
                                                                                              support_team) and checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 0
            DocumentFinetunePercDefault[phases[1]] = 35
            DocumentFinetunePercDefault[phases[2]] = 65
            DocumentFinetunePercDefault[phases[3]] = 0
        # IF DEV & PM NOT PRESENT
        elif checkZeros(dev, dev_team) and not checkZeros(test, test_team) and not checkZeros(support,
                                                                                              support_team) and checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 0
            DocumentFinetunePercDefault[phases[1]] = 35
            DocumentFinetunePercDefault[phases[2]] = 65
            DocumentFinetunePercDefault[phases[3]] = 0
        # IF TEST & SUPPORT NOT PRESENT
        elif not checkZeros(dev, dev_team) and checkZeros(test, test_team) and checkZeros(support,
                                                                                          support_team) and not checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 50
            DocumentFinetunePercDefault[phases[1]] = 0
            DocumentFinetunePercDefault[phases[2]] = 0
            DocumentFinetunePercDefault[phases[3]] = 50
        # IF TEST & PM NOT PRESENT
        elif not checkZeros(dev, dev_team) and checkZeros(test, test_team) and not checkZeros(support,
                                                                                              support_team) and checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 10
            DocumentFinetunePercDefault[phases[1]] = 0
            DocumentFinetunePercDefault[phases[2]] = 90
            DocumentFinetunePercDefault[phases[3]] = 0
        # IF SUPPORT & PM NOT PRESENT
        elif not checkZeros(dev, dev_team) and not checkZeros(test, test_team) and checkZeros(support,
                                                                                              support_team) and checkZeros(
                pm, pm_team):
            DocumentFinetunePercDefault[phases[0]] = 10
            DocumentFinetunePercDefault[phases[1]] = 90
            DocumentFinetunePercDefault[phases[2]] = 0
            DocumentFinetunePercDefault[phases[3]] = 0
        else:
            if not checkZeros(dev, dev_team):
                DocumentFinetunePercDefault[phases[0]] = 100
                DocumentFinetunePercDefault[phases[1]] = 0
                DocumentFinetunePercDefault[phases[2]] = 0
                DocumentFinetunePercDefault[phases[3]] = 0
            elif not checkZeros(test, test_team):
                DocumentFinetunePercDefault[phases[0]] = 0
                DocumentFinetunePercDefault[phases[1]] = 100
                DocumentFinetunePercDefault[phases[2]] = 0
                DocumentFinetunePercDefault[phases[3]] = 0
            elif checkZeros(support, support_team):
                DocumentFinetunePercDefault[phases[0]] = 0
                DocumentFinetunePercDefault[phases[1]] = 0
                DocumentFinetunePercDefault[phases[2]] = 100
                DocumentFinetunePercDefault[phases[3]] = 0
            elif checkZeros(pm, pm_team):
                DocumentFinetunePercDefault[phases[0]] = 0
                DocumentFinetunePercDefault[phases[1]] = 0
                DocumentFinetunePercDefault[phases[2]] = 0
                DocumentFinetunePercDefault[phases[3]] = 100
            else:
                DocumentFinetunePercDefault[phases[0]] = 0
                DocumentFinetunePercDefault[phases[1]] = 0
                DocumentFinetunePercDefault[phases[2]] = 0
                DocumentFinetunePercDefault[phases[3]] = 0

    return DocumentFinetunePercDefault


def calculate_breakeven(request):
    req_body = request.body.decode('utf-8')
    json_req_main = json.loads(req_body)['params']
    json_req = json_req_main['ui_input']

    phases = ast.literal_eval(str(json_req_main['phase']))
    level = json_req_main['level']

    workingdays_month = json_req["workingdays_month"]
    hoursperday = json_req["hoursperday"]
    type_of_proposition = json_req["type_of_proposition"]
    remaining_duration_project = json_req["remaining_duration_project"]
    amc = json_req["amc"]

    dev = json_req["dev"]
    test = json_req["test"]
    support = json_req["support"]
    pm = json_req["pm"]

    dev_team = json_req["dev_team"]
    test_team = json_req["test_team"]
    support_team = json_req["support_team"]
    pm_team = json_req["pm_team"]

    size_project_code = json_req["size_project_code"]
    size_project_doc = json_req["size_project_doc"]

    avg_hourly_res_cost = json_req["avg_hourly_res_cost"]
    size_resource_pod = json_req["size_resource_pod"]
    num_of_pods = json_req["num_of_pods"]

    type_of_model = json_req["type_of_model"]
    cost_per_tokens = json_req["cost_per_tokens"]
    token_limit = json_req["token_limit"]
    finetuned_model_cost = json_req["finetuned_model_cost"]
    llm_hosting_cost = json_req["llm_hosting_cost"]

    ExpectedBenefit = getExpectedBenefit()
    ImplTime, OpsCost = getImplTime_OpsCost()
    FinetuningCycle = getFineTuningCycle(phases)
    MonthlyUsageFrequency = getMonthlyUsageFrequency()

    OtherConstants = getOtherConstants()
    CodeFinetunePercDefault = getSplitFinetunePerc("Code")
    DocumentFinetunePercDefault = getSplitFinetunePerc("Documentation")
    CodeFinetunePerc = handleCodeFinetunePerc(CodeFinetunePercDefault, request)
    DocumentFinetunePerc = handleDocumentFinetunePerc(DocumentFinetunePercDefault, request)

    # phases= ["Development", "Testing", "Support", "Program Management"]
    total_onboard_time, impl_time_ops_cost_count, impl_time_ops_cost_nacount = 0, 0, 0

    for phase in phases:
        res = db_utils.getPhaseDetails(phase)
        if res['message'] == "Success":
            phase_values = res['data']

            total_resource = eval(config_parser.get("breakeven", "total_resource"))
            complexity_factor = eval(config_parser.get("breakeven", "complexity_factor"))

            total_aggregate_cost, total_existing_cost, total_monthly_online_llm_cost, total_monthly_offline_llm_cost, total_monthly_savings_cost = 0, 0, 0, 0, 0
            # impl_time_ops_cost_count, impl_time_ops_cost_nacount = 0, 0

            for phase_value in phase_values:
                effort_weightage = float(phase_value['effort_weightage']) / 100
                benefit_potential = phase_value['benefit_potential']
                impl_time_ops_cost = phase_value['impl_time_ops_cost']
                finetune_cycle = phase_value['finetune_cycle']
                monthly_usage = phase_value['monthly_usage']
                bill_type = phase_value['billrate_type']
                custom_billrate = float(phase_value['custom_billrate'])

                benefit_potential_value = int(ExpectedBenefit[benefit_potential]) / 100
                phase_value['benefit_potential_value'] = benefit_potential_value
                implement_time = float(ImplTime[impl_time_ops_cost])
                ops_cost_perc = int(OpsCost[impl_time_ops_cost])
                finetune_cycle_value = float(FinetuningCycle[phase][finetune_cycle])
                monthly_usage_value = int(MonthlyUsageFrequency[monthly_usage]) / 100
                oc_data_ingress_egress_cost = float(OtherConstants["Data ingress-egress cost"])
                oc_code_finetune_hours_1mb = float(OtherConstants["Hours to fine tune on 1 MB code"])
                oc_docs_finetune_hours_1gb = float(OtherConstants["Hours to fine tune on 1 GB docs"])
                oc_numof_1ktokens_1mb_code = float(OtherConstants["No. of 1k tokens per 1 MB code"])
                oc_numof_1ktokens_1gb_docs = float(OtherConstants["No. of 1k tokens per 1 GB doc"])
                oc_online_llm_monthly_cost = float(OtherConstants["Monthly Cost Multiplier (Online LLMs)"])

                code_split_perc = int(CodeFinetunePerc[phase]) / 100
                docs_split_perc = int(DocumentFinetunePerc[phase]) / 100

                # total_resource = dev_team + test_team + support_team + pm_team
                # usecase_dev_cost_calc = round(size_resource_pod * implement_time *  avg_hourly_res_cost * workingdays_month * hoursperday * (1+(((math.ceil(total_resource/50))-1)/10)),2)
                if phase == "Development":
                    usecase_dev_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(dev,
                                                                                                         dev_team)) else eval(
                        config_parser.get("breakeven", "usecase_dev_cost"))
                    ops_cost = 0 if usecase_dev_cost == 0 else eval(config_parser.get("breakeven", "ops_cost"))
                    online_llm_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(dev,
                                                                                                         dev_team) or checkOfflineModel(
                            type_of_model)) else eval(
                        config_parser.get("breakeven", "online_llm_cost")) if not checkAWSTitanModel(
                        type_of_model) else eval(config_parser.get("breakeven", "online_llm_cost_aws"))
                    offline_llm_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(dev,
                                                                                                         dev_team) or checkOnlineModel(
                            type_of_model)) else eval(config_parser.get("breakeven", "offline_llm_cost"))
                    aggregate_cost = eval(config_parser.get("breakeven", "aggregate_cost"))
                    monthly_resource_cost = eval(
                        config_parser.get("breakeven", "monthly_res_cost_blended_dev")) if checkBlended(
                        bill_type) else eval(config_parser.get("breakeven", "monthly_res_cost_custom_dev"))
                    monthly_online_llm_cost = 0 if (
                                checkZeros(dev, dev_team) or checkNA(benefit_potential) or checkZero(
                            effort_weightage) or checkOfflineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_online_llm_cost_dev"))
                    monthly_offline_llm_cost = 0 if (
                                checkZeros(dev, dev_team) or checkNA(benefit_potential) or checkZero(
                            effort_weightage) or checkOnlineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_offline_llm_cost"))

                    monthly_savings_cost = benefit_potential_value * effort_weightage
                    total_onboard_time += 0 if checkZeros(dev, dev_team) else implement_time
                    impl_time_ops_cost_count += 0 if checkZeros(dev, dev_team) else 1
                    impl_time_ops_cost_nacount += 0 if checkZeros(dev, dev_team) else 0 if checkNA(
                        impl_time_ops_cost) else 1

                if phase == "Testing":
                    usecase_dev_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(test,
                                                                                                         test_team)) else eval(
                        config_parser.get("breakeven", "usecase_dev_cost"))
                    ops_cost = 0 if usecase_dev_cost == 0 else eval(config_parser.get("breakeven", "ops_cost"))
                    online_llm_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(test,
                                                                                                         test_team) or checkOfflineModel(
                            type_of_model)) else eval(
                        config_parser.get("breakeven", "online_llm_cost")) if not checkAWSTitanModel(
                        type_of_model) else eval(config_parser.get("breakeven", "online_llm_cost_aws"))
                    offline_llm_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(test,
                                                                                                         test_team) or checkOnlineModel(
                            type_of_model)) else eval(config_parser.get("breakeven", "offline_llm_cost"))
                    aggregate_cost = eval(config_parser.get("breakeven", "aggregate_cost"))
                    monthly_resource_cost = eval(
                        config_parser.get("breakeven", "monthly_res_cost_blended_test")) if checkBlended(
                        bill_type) else eval(config_parser.get("breakeven", "monthly_res_cost_custom_test"))
                    monthly_online_llm_cost = 0 if (
                                checkZeros(test, test_team) or checkNA(benefit_potential) or checkZero(
                            effort_weightage) or checkOfflineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_online_llm_cost_test"))
                    monthly_offline_llm_cost = 0 if (
                                checkZeros(test, test_team) or checkNA(benefit_potential) or checkZero(
                            effort_weightage) or checkOnlineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_offline_llm_cost"))

                    monthly_savings_cost = benefit_potential_value * effort_weightage
                    total_onboard_time += 0 if checkZeros(test, test_team) else implement_time
                    impl_time_ops_cost_count += 0 if checkZeros(test, test_team) else 1
                    impl_time_ops_cost_nacount += 0 if checkZeros(test, test_team) else 0 if checkNA(
                        impl_time_ops_cost) else 1

                if phase == "Support":
                    usecase_dev_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(support,
                                                                                                         support_team)) else eval(
                        config_parser.get("breakeven", "usecase_dev_cost"))
                    ops_cost = 0 if usecase_dev_cost == 0 else eval(config_parser.get("breakeven", "ops_cost"))
                    online_llm_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(support,
                                                                                                         support_team) or checkOfflineModel(
                            type_of_model)) else eval(
                        config_parser.get("breakeven", "online_llm_cost")) if not checkAWSTitanModel(
                        type_of_model) else eval(config_parser.get("breakeven", "online_llm_cost_aws"))
                    offline_llm_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(support,
                                                                                                         support_team) or checkOnlineModel(
                            type_of_model)) else eval(config_parser.get("breakeven", "offline_llm_cost"))
                    aggregate_cost = eval(config_parser.get("breakeven", "aggregate_cost"))
                    monthly_resource_cost = eval(
                        config_parser.get("breakeven", "monthly_res_cost_blended_support")) if checkBlended(
                        bill_type) else eval(config_parser.get("breakeven", "monthly_res_cost_custom_support"))
                    monthly_online_llm_cost = 0 if (
                                checkZeros(support, support_team) or checkNA(benefit_potential) or checkZero(
                            effort_weightage) or checkOfflineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_online_llm_cost_support"))
                    monthly_offline_llm_cost = 0 if (
                                checkZeros(support, support_team) or checkNA(benefit_potential) or checkZero(
                            effort_weightage) or checkOnlineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_offline_llm_cost"))

                    monthly_savings_cost = benefit_potential_value * effort_weightage
                    total_onboard_time += 0 if checkZeros(support, support_team) else implement_time
                    impl_time_ops_cost_count += 0 if checkZeros(support, support_team) else 1
                    impl_time_ops_cost_nacount += 0 if checkZeros(support, support_team) else 0 if checkNA(
                        impl_time_ops_cost) else 1

                if phase == "Program Management":
                    usecase_dev_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(pm,
                                                                                                         pm_team)) else eval(
                        config_parser.get("breakeven", "usecase_dev_cost"))
                    ops_cost = 0 if usecase_dev_cost == 0 else eval(config_parser.get("breakeven", "ops_cost"))
                    online_llm_cost = 0 if (checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(pm,
                                                                                                                     pm_team) or checkOfflineModel(
                        type_of_model)) else eval(
                        config_parser.get("breakeven", "online_llm_cost")) if not checkAWSTitanModel(
                        type_of_model) else eval(config_parser.get("breakeven", "online_llm_cost_aws"))
                    offline_llm_cost = 0 if (
                                checkZero(effort_weightage) or checkNA(impl_time_ops_cost) or checkZeros(pm,
                                                                                                         pm_team) or checkOnlineModel(
                            type_of_model)) else eval(config_parser.get("breakeven", "offline_llm_cost"))
                    aggregate_cost = eval(config_parser.get("breakeven", "aggregate_cost"))
                    monthly_resource_cost = eval(
                        config_parser.get("breakeven", "monthly_res_cost_blended_pm")) if checkBlended(
                        bill_type) else eval(config_parser.get("breakeven", "monthly_res_cost_custom+pm"))
                    monthly_online_llm_cost = 0 if (checkZeros(pm, pm_team) or checkNA(benefit_potential) or checkZero(
                        effort_weightage) or checkOfflineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_online_llm_cost_pm"))
                    monthly_offline_llm_cost = 0 if (checkZeros(pm, pm_team) or checkNA(benefit_potential) or checkZero(
                        effort_weightage) or checkOnlineModel(type_of_model)) else eval(
                        config_parser.get("breakeven", "monthly_offline_llm_cost"))

                    monthly_savings_cost = benefit_potential_value * effort_weightage
                    total_onboard_time += 0 if checkZeros(pm, pm_team) else implement_time
                    impl_time_ops_cost_count += 0 if checkZeros(pm, pm_team) else 1
                    impl_time_ops_cost_nacount += 0 if checkZeros(pm, pm_team) else 0 if checkNA(
                        impl_time_ops_cost) else 1

                phase_value['usecase_dev_cost'] = usecase_dev_cost
                phase_value['ops_cost'] = ops_cost
                phase_value['online_llm_cost'] = online_llm_cost
                phase_value['offline_llm_cost'] = offline_llm_cost
                phase_value['aggregate_cost'] = aggregate_cost
                phase_value['monthly_resource_cost'] = monthly_resource_cost
                phase_value['monthly_online_llm_cost'] = monthly_online_llm_cost
                phase_value['monthly_offline_llm_cost'] = monthly_offline_llm_cost

                print(str(usecase_dev_cost) + "    " + str(ops_cost) + "  " + str(online_llm_cost) + "    " + str(
                    offline_llm_cost) + "   " + str(aggregate_cost) + "    " + str(monthly_resource_cost) + "  " + str(
                    monthly_online_llm_cost) + "   " + str(monthly_offline_llm_cost))
                # print(phase_values)
                if level == "all":
                    total_aggregate_cost += aggregate_cost
                    total_existing_cost += monthly_resource_cost
                    total_monthly_online_llm_cost += monthly_online_llm_cost
                    total_monthly_offline_llm_cost += monthly_offline_llm_cost
                    total_monthly_savings_cost += monthly_savings_cost
                    # total_onboard_time += onboard_time

            if level == "all":
                # overall_total_aggregate_cost, overall_total_existing_cost, overall_total_monthly_llm_cost, overall_monthly_savings_cost = 0, 0, 0, 0

                if phase == "Development":
                    total_aggregate_cost = 0 if checkZeros(dev, dev_team) else total_aggregate_cost
                    total_monthly_llm_cost = total_monthly_offline_llm_cost if checkOfflineModel(
                        type_of_model) else total_monthly_online_llm_cost
                    total_monthly_savings_cost = 0 if checkZeros(dev, dev_team) else eval(
                        config_parser.get("breakeven", "monthly_savings_cost"))
                    breakeven_months = 0 if checkZeros(dev, dev_team) else eval(
                        config_parser.get("breakeven", "breakeven_months"))

                    dev_result = {}
                    dev_result['total_aggregate_cost'] = total_aggregate_cost
                    dev_result['total_existing_cost'] = total_existing_cost
                    dev_result['total_monthly_llm_cost'] = total_monthly_llm_cost
                    dev_result['total_monthly_savings_cost'] = total_monthly_savings_cost
                    dev_result['breakeven_months'] = breakeven_months

                if phase == "Testing":
                    total_aggregate_cost = 0 if checkZeros(test, test_team) else total_aggregate_cost
                    total_monthly_llm_cost = total_monthly_offline_llm_cost if checkOfflineModel(
                        type_of_model) else total_monthly_online_llm_cost
                    total_monthly_savings_cost = 0 if checkZeros(test, test_team) else eval(
                        config_parser.get("breakeven", "monthly_savings_cost"))
                    breakeven_months = 0 if checkZeros(dev, dev_team) else eval(
                        config_parser.get("breakeven", "breakeven_months"))

                    test_result = {}
                    test_result['total_aggregate_cost'] = total_aggregate_cost
                    test_result['total_existing_cost'] = total_existing_cost
                    test_result['total_monthly_llm_cost'] = total_monthly_llm_cost
                    test_result['total_monthly_savings_cost'] = total_monthly_savings_cost
                    test_result['breakeven_months'] = breakeven_months

                if phase == "Support":
                    total_aggregate_cost = 0 if checkZeros(support, support_team) else total_aggregate_cost
                    total_monthly_llm_cost = total_monthly_offline_llm_cost if checkOfflineModel(
                        type_of_model) else total_monthly_online_llm_cost
                    total_monthly_savings_cost = 0 if checkZeros(support, support_team) else eval(
                        config_parser.get("breakeven", "monthly_savings_cost"))
                    breakeven_months = 0 if checkZeros(dev, dev_team) else eval(
                        config_parser.get("breakeven", "breakeven_months"))

                    support_result = {}
                    support_result['total_aggregate_cost'] = total_aggregate_cost
                    support_result['total_existing_cost'] = total_existing_cost
                    support_result['total_monthly_llm_cost'] = total_monthly_llm_cost
                    support_result['total_monthly_savings_cost'] = total_monthly_savings_cost
                    support_result['breakeven_months'] = breakeven_months

                if phase == "Program Management":
                    total_aggregate_cost = 0 if checkZeros(pm, pm_team) else total_aggregate_cost
                    total_monthly_llm_cost = total_monthly_offline_llm_cost if checkOfflineModel(
                        type_of_model) else total_monthly_online_llm_cost
                    total_monthly_savings_cost = 0 if checkZeros(pm, pm_team) else eval(
                        config_parser.get("breakeven", "monthly_savings_cost"))
                    breakeven_months = 0 if checkZeros(dev, dev_team) else eval(
                        config_parser.get("breakeven", "breakeven_months"))

                    pm_result = {}
                    pm_result['total_aggregate_cost'] = total_aggregate_cost
                    pm_result['total_existing_cost'] = total_existing_cost
                    pm_result['total_monthly_llm_cost'] = total_monthly_llm_cost
                    pm_result['total_monthly_savings_cost'] = total_monthly_savings_cost
                    pm_result['breakeven_months'] = breakeven_months

    if level == "all":
        overall_total_aggregate_cost = dev_result['total_aggregate_cost'] + test_result['total_aggregate_cost'] + \
                                       support_result['total_aggregate_cost'] + pm_result['total_aggregate_cost']
        overall_total_existing_cost = dev_result['total_existing_cost'] + test_result['total_existing_cost'] + \
                                      support_result['total_existing_cost'] + pm_result['total_existing_cost']
        overall_total_monthly_llm_cost = dev_result['total_monthly_llm_cost'] + test_result['total_monthly_llm_cost'] + \
                                         support_result['total_monthly_llm_cost'] + pm_result['total_monthly_llm_cost']
        overall_monthly_savings_cost = dev_result['total_monthly_savings_cost'] + test_result[
            'total_monthly_savings_cost'] + support_result['total_monthly_savings_cost'] + pm_result[
                                           'total_monthly_savings_cost']
        overall_savings_percentage = eval(config_parser.get("breakeven", "savings_percentage"))
        overall_onboard_time = eval(config_parser.get("breakeven", "overall_onboard_time"))
        overall_breakeven_months = 0 if checkZero(overall_total_aggregate_cost) else eval(
            config_parser.get("breakeven", "overall_breakeven_months"))
        overall_indicative_roi = eval(config_parser.get("breakeven", "overall_indicative_roi"))
        overall_result = {}
        overall_result['overall_total_aggregate_cost'] = round(overall_total_aggregate_cost, 2)
        overall_result['overall_total_existing_cost'] = round(overall_total_existing_cost, 2)
        overall_result['overall_total_monthly_llm_cost'] = round(overall_total_monthly_llm_cost, 2)
        overall_result['overall_monthly_savings_cost'] = overall_monthly_savings_cost
        overall_result['overall_savings_percentage'] = round(overall_savings_percentage, 2)
        overall_result['overall_onboard_time'] = overall_onboard_time
        overall_result['overall_breakeven_months'] = overall_breakeven_months
        overall_result['overall_indicative_roi'] = overall_indicative_roi

        final_result = {}
        final_result['overall'] = overall_result
        final_result['dev'] = dev_result
        final_result['test'] = test_result
        final_result['support'] = support_result
        final_result['pm'] = pm_result
    else:
        final_result = {}
        final_result['phase'] = phase_values

    return final_result

##### #### ### ## # COST CALCULATOR END # ## ### #### #####
