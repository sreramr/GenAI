"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os 
import re

from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT, WD_LINE_SPACING
from docx.shared import Pt
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


def find_file_path(root_path, target_file):
    try:
        for dir_path, dir_names, file_names in os.walk(root_path):
            for file_name in file_names:
                if file_name == target_file:
                    return os.path.join(dir_path, file_name)
        raise ValueError(f"File not exists. : {file_name}")
    except Exception as e:
        raise ValueError(f"Failed to find out the file path: {target_file}")


def save_output_file(output_dir, file_name, extension, file_content):
    if extension.startswith("."):
        final_file_name = file_name.split(".")[0] + extension
    else:
        final_file_name = file_name.split(".")[0] + "." + extension
    
    # output_root_path = os.path.join(output_dir, final_file_name)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    output_save_path = os.path.join(output_dir, final_file_name)
   
    dis_head="Disclaimer: This output contains AI generated content, user is advised to review it before consumption."
    dis_top="*Start of AI Generated Content*"
    dis_end="*End of AI Generated Content*"
    disclaimer = dis_head +"\n\n" + dis_top
    if extension == "docx" or extension == "doc":
        doc = Document()
        disclaimer_paragraph = doc.add_paragraph()
        disclaimer_run = disclaimer_paragraph.add_run(disclaimer)
        disclaimer_run.bold = True
        # Split the response into paragraphs  
        paragraphs = file_content.split("\n")
        for paragraph_text in paragraphs:
            paragraph = doc.add_paragraph()
            paragraph.style.font.size = Pt(12)
            paragraph.space_before = Pt(0)
            paragraph.space_after = Pt(0)
            paragraph.line_spacing_rule = WD_LINE_SPACING.SINGLE
            paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
 
            # Apply bold formatting to text enclosed in double asterisks (**)  
            bold_parts = re.findall(r"\*\*.*?\*\*", paragraph_text)
            if bold_parts:
                for bold_part in bold_parts:
                    # Remove the double asterisks  
                    bold_text = bold_part.strip("*")
                    paragraph_text = paragraph_text.replace(bold_part, "")
 
                    # Add the bold text to the paragraph  
                    add_bold_text(paragraph, bold_text)
 
                    # Add the remaining text to the paragraph
            paragraph.add_run(paragraph_text)
            
        doc_paragraph = doc.add_paragraph()
        doc_run = doc_paragraph.add_run(dis_end)
        doc_run.bold = True
            # Save the Document as a .docx file  
        doc.save(output_save_path)
    elif extension == "pdf":
        save_content_as_pdf(output_save_path, file_content, file_name)
    else:
        file_content = dis_head + "\n" + dis_top + "\n\n" + file_content + "\n\n" + dis_end
        with open(output_save_path, 'w') as file:
            file.write(file_content)


def add_bold_text(paragraph, text):
    run = paragraph.add_run(text)
    run.bold = True
    return run

### Saving the content into PDF
def save_content_as_pdf(output_save_path, file_content, file_name):
    c = canvas.Canvas(output_save_path, pagesize=letter)
    c.setTitle(file_name)
    c.setFont("Helvetica", 12)

    # Set the starting coordinates, line height, and text width  
    x = 50
    y = 750
    line_height = 14
    text_width = 95
    bottom_margin = 50

    # Split the content into lines  
    lines = file_content.split("\n")

    # Write each line to the PDF with automatic line wrapping  
    for line in lines:
        # Wrap the line if it exceeds the text_width  
        wrapped_lines = textwrap.wrap(line, width=text_width)

        for wrapped_line in wrapped_lines:
            if y < bottom_margin:
                c.showPage()
                y = 750

            c.drawString(x, y, wrapped_line)
            y -= line_height

            # Add a blank line to separate paragraphs
        y -= line_height
    c.showPage()
    c.save()