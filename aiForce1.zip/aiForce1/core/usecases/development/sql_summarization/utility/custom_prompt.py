"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from langchain.agents import Tool
from langchain.prompts import StringPromptTemplate
from typing import List
import tiktoken


class CustomPromptTemplate(StringPromptTemplate):
    # The template to use
    template: str
    # The list of tools available
    tools: List[Tool]
    
    def format(self, **kwargs) -> str:
        # Get the intermediate steps (AgentAction, Observation tuples)
        # Format them in a particular way
        intermediate_steps = kwargs.pop("intermediate_steps")
        thoughts = ""
        for action, observation in intermediate_steps:
            thoughts += action.log
            thoughts += f"\nObservation: {observation}\nThought: "
        # Set the agent_scratchpad variable to that value
        kwargs["agent_scratchpad"] = thoughts
        # Create a tools variable from the list of tools provided
        kwargs["tools"] = "\n".join([f"{tool.name}: {tool.description}" for tool in self.tools])
        # Create a list of tool names for the tools provided
        kwargs["tool_names"] = ", ".join([tool.name for tool in self.tools])
        prompt = self.template.format(**kwargs)
        # print("==============")
        # print(prompt)
        # print(self.num_of_tokens(prompt))
        return self.template.format(**kwargs)

    
    def num_of_tokens(self, string: str, encoding_name: str = 'cl100k_base') -> int:
        encoding = tiktoken.get_encoding(encoding_name)
        # encoding = tiktoken.encoding_for_model('gpt2')
        num_tokens = len(encoding.encode(string))
        return num_tokens



def  return_prompt(template, tools):
    prompt = CustomPromptTemplate(
        template=template,
        tools=tools,    
        # This omits the `agent_scratchpad`, `tools`, and `tool_names` variables because those are generated dynamically
        # This includes the `intermediate_steps` variable because that is needed
        input_variables=["input", "intermediate_steps"]
    )
    return prompt


