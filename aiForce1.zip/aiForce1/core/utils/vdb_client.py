import configparser
import json
import os
import requests


def create_opensearch_client():
    try:
        from opensearchpy import OpenSearch
    except ImportError:
        raise "Could not import OpenSearch. Please install it with `pip install opensearch-py`."
    
    host = os.getenv("host")
    port = os.getenv("port")
    try:
        return OpenSearch(
            hosts=[{'host': host, 'port': port}],
            http_compress=True,  # enables gzip compression for request bodies
            use_ssl=False,
            verify_certs=False,
            ssl_assert_hostname=False,
            ssl_show_warn=False
        )
    except ConnectionRefusedError as e:
        print("Open search is not running..")
        return None
    except ConnectionError as e:
        print("Open search is not running..")
        return None


def create_elasticsearch_client():
    host = os.getenv("host")
    port = os.getenv("port")
    try:
        from elasticsearch import Elasticsearch
    except ImportError:
        raise "Could not import ElasticSearch. Please install it with `pip install elasticsearch`."
    return Elasticsearch(
                hosts="http://" + host + ":" + str(port), timeout=120
            )


def get_vdb_client(vdb_source='opensearch'):
    if vdb_source == 'opensearch':
        return create_opensearch_client()
    else:
        return create_elasticsearch_client()


def get_index_settings(data_type, vdb_source):
    print("cwdPath = os.path.abspath(os.getcwd())", os.path.abspath(os.getcwd()))
    if vdb_source == 'opensearch':
        with open(os.path.join(os.path.abspath(os.getcwd()),"core","config", "os_index_settings.json"), 'r') as f:
            settings = json.load(f)
        filtered_settings = [item['settings'] for item in settings if item['data_type'] == data_type]
        if len(filtered_settings) > 0:
            settings_json = filtered_settings[0]
        else:
            print(f"No settings found for data type '{data_type}'")
        return settings_json
    else:
        with open(os.path.join(os.path.abspath(os.getcwd()),"codebase","server","core","config", "es_index_settings.json"), 'r') as f:
            settings = json.load(f)
        filtered_settings = [item['settings'] for item in settings if item['data_type'] == data_type]
        if len(filtered_settings) > 0:
            settings_json = filtered_settings[0]
        else:
            print(f"No settings found for data type '{data_type}'")
        return settings_json


def create_index_if_not_exist(client, index_name, data_type, vdb_source):
    if not client.indices.exists(index=index_name):
        index_settings = get_index_settings(data_type, vdb_source)
        # Create the index
        response = client.indices.create(index=index_name, body=index_settings)
        # Check if the index creation was successful
        if response["acknowledged"]:
            print(f"Index '{index_name}' created successfully.")
        else:
            print(f"Failed to create index '{index_name}'.")
    else:
        print(f"Index '{index_name}' already exists.")


def insert_bulk_data(client, bulk_data, index_name, vdb_source):
    if vdb_source == 'opensearch':
        from opensearchpy.helpers import bulk, BulkIndexError
        try:
            result = bulk(client, bulk_data)
            print("data insertion to ", index_name, " completed")
        except BulkIndexError as e:
            for item in e.errors:
                print("Failed document:", item["index"])
                print("Error reason:", item["index"]["error"])
    else:
        from elasticsearch.helpers import bulk, BulkIndexError
        try:
            result = bulk(client, bulk_data)
            print("data insertion to ", index_name, " completed")
        except BulkIndexError as e:
            for item in e.errors:
                print("Failed document:", item["index"])
                print("Error reason:", item["index"]["error"])
    return result


def push_data_to_vdb(data, index_name, index_column_name, data_type):
    vdb_source = 'opensearch'
    index_name = index_name.lower()
    print("data insertion to ", index_name, " started")
    result = False
    bulk_data = []
    for row in data:
        bulk_data.append(
            {
                "_op_type": "index",
                "_index": index_name,
                "_id": row[index_column_name],
                "_source": row,
            }
        )
    if bulk_data:
        try:
            client = get_vdb_client(vdb_source)
            create_index_if_not_exist(client, index_name, data_type, vdb_source)
            return insert_bulk_data(client, bulk_data, index_name, vdb_source)
        except Exception as e:
            print(e)
    return result




def drop_index(index_name):
    client = get_vdb_client()
    if client.indices.exists(index=index_name):
        # Delete the index
        client.indices.delete(index=index_name)
        print(f"Index '{index_name}' deleted successfully.")
    else:
        print(f"Index '{index_name}' does not exist.")


def check_if_index_exist(index_name):
    client = get_vdb_client()
    return client.indices.exists(index_name)


def refresh_opensearch_index(index_name):
    host = os.getenv("host")
    port = os.getenv("port")
    url = f"http://{host}:{port}/{index_name}/_refresh"
    response = requests.post(url)
    if response.status_code == 200:
        print(f"Index {index_name} refreshed successfully.")
    else:
        print(f"Failed to refresh index {index_name}. Status code: {response.status_code}")
