import os
import shutil
import tempfile
from typing import Literal

import pandas as pd
from langchain.schema.language_model import BaseLanguageModel
from langchain.vectorstores.base import VectorStore
from langchain.schema.document import Document

from core.data.loaders.code import create_code_parser
from core.data.loaders.document import create_document_parser
from core.data.loaders.tabular_data import load_dataframe_from_file
from core.data.transformers import (convert_dataframe_to_documents,
                                    standardize_dataset_df)


def load_document_to_vector_store(
    vector_store: VectorStore,
    llm: BaseLanguageModel,
    data_type: Literal['code', 'requirement', 'feature', 'testcase', 'testsuite', 'defect', 'api', 'testcase_recommendation'],
    input_file=None,
    df=None,
    *args,
    **kwargs
):
    print("Loading the document into Vector Store. Please wait it takes some time...")
    if data_type == "code":
        if not kwargs.get("language"):
            raise ValueError("Please pass 'language' as kewword argument")

        code_dir = kwargs.get("code_dir")

        if not input_file and not code_dir:
            raise ValueError("Please provide either input_file or code_dir")

        if not code_dir:
            code_dir = tempfile.mkdtemp()
            shutil.unpack_archive(input_file, code_dir)

        code_parser = create_code_parser(code_root=code_dir, language=kwargs.get("language"))
        all_functions = code_parser.get_all_codes_by_type(code_type="function_def")
        df = pd.DataFrame(all_functions, columns=["filename", "name", "source_code"])
        df["filename"] = df["filename"].apply(lambda fn: os.path.relpath(fn, code_dir).replace("\\", "/"))

    if data_type == "api":
        if not input_file:
            raise ValueError("Please provide input_file path")
        
        docs_parser = create_document_parser(input_file=input_file)
        all_functions = docs_parser.get_all_codes_by_type(regex_pattern=kwargs.get("regex_pattern"))
        df = pd.DataFrame(all_functions, columns=["func_name", "type", "source_code"])

    if not input_file and not isinstance(df, pd.DataFrame):
        raise ValueError("Please provide either input_file or df")

    if input_file and data_type != "api" and data_type != "script":
        df = load_dataframe_from_file(input_file=input_file)

    if data_type != "script":
        df1 = standardize_dataset_df(data_type=data_type, llm=llm, df=df)
        docs = convert_dataframe_to_documents(data_type=data_type, df=df1)

    if data_type == "script":
        if not input_file:
            raise ValueError("Please provide input_file path")
        
        if not os.path.isdir(input_file):
            raise ValueError("For 'script' data type, input_file should be a directory containing script files.")
        
        script_files = [f for f in os.listdir(input_file) if os.path.isfile(os.path.join(input_file, f))]
        all_scripts = []
        file_names = []
        for script_file in script_files:
            with open(os.path.join(input_file, script_file), 'r') as f:
                script_text = f.read()
                all_scripts.append(script_text)
                file_names.append(script_file)
        
        docs = [Document(page_content=all_scripts[i], metadata={"filename": file_names[i]}) for i in range(len(all_scripts))]

    if not docs:
        return []

    ids = vector_store.add_documents(docs)
    print("Successfully loaded the document into Vector Store.")
    return ids
