"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os
from concurrent.futures import ThreadPoolExecutor
from typing import List

from azure.devops.connection import Connection
from msrest.authentication import BasicAuthentication
from tfs import TFSAPI

from core.data.connectors.base import *


class TFSConnector(DataConnector):

    def __init__(self, url: str, pat: str, project: str, repository: str, *args, **kwargs):
        """
        Initialize TFS connector
        """
        self.url = url
        self.pat = pat
        self.project = project
        self.repository = repository

        self._connect()

    def _connect(self):
        credentials = BasicAuthentication("", self.pat)
        self.client = TFSAPI(server_url=self.url, pat=self.pat, project=self.project)
        self.git_client = Connection(base_url=self.url, creds=credentials).clients.get_git_client()

    def test_connection(self) -> bool:
        try:
            query = f"""SELECT TOP 1 [System.Id], [System.Title] FROM WorkItems"""
            res = self.client.run_wiql(query=query)
            return True
        except:
            return False

    def get_code_files(self, dir: str = "/") -> List[ProjectFile]:
        """
        Fetches code files from TFS.

        Args:
            dir (str): The directory path to fetch code files from.

        Returns:
            A list of ProjectFile objects.
        """
        files = self.git_client.get_items(
            project=self.project,
            repository_id=self.repository,
            scope_path=dir,
            recursion_level="full",
        )
        project_files = []
        for file in files:
            if file.git_object_type == 'tree':
                continue

            project_files.append(ProjectFile(
                id=file.object_id,
                path=file.path,
                type=file.git_object_type,
                commit_id=file.commit_id
            ))
        return project_files

    def get_file_blob(self, path: str) -> bytes:
        blob_res = self.git_client.get_item_content(
            project=self.project,
            repository_id=self.repository,
            path=path,
        )
        return blob_res

    def download_file(self, path, target_filepath):
        blob_res = self.get_file_blob(path=path)

        os.makedirs(os.path.dirname(target_filepath), exist_ok=True)
        with open(target_filepath, "wb") as f:
            for chunk in blob_res:
                f.write(chunk)

        return target_filepath

    def download_code_files(self, code_files: List[str], target_dir: str):
        params = [(f, os.path.join(target_dir, f.strip('/'))) for f in code_files]

        with ThreadPoolExecutor() as executer:
            res = list(executer.map(lambda x: self.download_file(*x), params))

    def download_code_file_dir(self, dir: str, target_dir: str):
        code_files = [f.path for f in self.get_code_files(dir)]
        self.download_code_files(code_files, target_dir)

    def get_bugs(self, bug_ids: List[int | str] = None) -> List[BugItem]:
        """
        Fetches Bugs from TFS.

        Returns:
            A list of BugItem objects.
        """
        bugs = []
        if bug_ids:
            bugs = self.client.get_workitems(work_items_ids=bug_ids)
        else:
            res = self.client.run_wiql(query="SELECT * FROM WorkItems WHERE [System.WorkItemType] = 'Bug'")
            bugs = res.workitems

        bug_items = []
        for bug in bugs:
            bug_items.append(BugItem(
                id=bug.id,
                type=bug.fields.get("System.WorkItemType"),
                title=bug.fields.get("System.Title"),
                description=bug.fields.get("Microsoft.VSTS.TCM.ReproSteps"),
                created_by=bug.fields.get("System.CreatedBy"),
                created_date=bug.fields.get("System.CreatedDate"),
                assigned_to=bug.fields.get("System.AssignedTo"),
                release=bug.fields.get('System.IterationPath'),
                state=bug.fields.get("System.State"),
                change_date=bug.fields.get('System.ChangedDate'),
                resolution=bug.fields.get('Microsoft.VSTS.Common.ResolvedReason'),
                resolved_by=bug.fields.get('Microsoft.VSTS.Common.ResolvedBy'),
                priority=bug.fields.get("Microsoft.VSTS.Common.Priority"),
                severity=bug.fields.get("Microsoft.VSTS.Common.Severity"),
                meta=bug.fields
            ))
        return bug_items

    def get_testcases(self, testcase_ids: List[int | str] = None) -> List[TestCase]:
        """
        Fetches Testcases from TFS.

        Returns:
            A list of TestCase objects.
        """
        testcases = []
        if testcases:
            testcases = self.client.get_workitems(work_items_ids=testcase_ids)
        else:
            res = self.client.run_wiql(query="SELECT * FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'")
            testcases = res.workitems

        testcase_items = []
        for testcase in testcases:
            testcase_items.append(TestCase(
                id=testcase.id,
                type=testcase.fields.get("System.WorkItemType"),
                title=testcase.fields.get("System.Title"),
                description=testcase.fields.get("System.Description"),
                steps=testcase.fields.get("Microsoft.VSTS.TCM.Steps"),
                created_by=testcase.fields.get("System.CreatedBy"),
                created_date=testcase.fields.get("System.CreatedDate"),
                release=testcase.fields.get('System.IterationPath'),
                environment="",
                change_date=testcase.fields.get('System.ChangedDate'),
                test_type=testcase.fields.get("System.Reason"),
                priority=testcase.fields.get("Microsoft.VSTS.Common.Priority"),
                automated=testcase.fields.get("Microsoft.VSTS.TCM.AutomationStatus"),
                meta=testcase.fields
            ))
        return testcase_items

    def push_testcases(self, testcases: List[TestCase]) -> List[int | str]:
        """
        Pushes Testcases to TFS.

        Args:
            testcases (List[TestCase]): A list of TestCase objects to push.

        Returns:
            A list of Testcase Ids that were successfully pushed.
        """
        ids = []
        for testcase in testcases:
            fields = {'System.Title': testcase.title,
                      'System.Description': testcase.description
                      }
            workitem = self.client.create_workitem('Test Case', fields=fields)
            ids.append(workitem.id)

        return ids
