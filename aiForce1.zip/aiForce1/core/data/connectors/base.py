"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""

import abc
from dataclasses import dataclass, field
from typing import *
from typing import List


@dataclass
class WorkItem:
    id: int
    type: str
    title: str
    description: str
    created_by: str
    created_date: str
    change_date: str
    release: str
    meta: dict = field(default_factory=dict)


class BugItem(WorkItem):
    assigned_to: str
    state: str
    priority: str
    severity: str
    resolution: str
    resolved_by: str


class TestCase(WorkItem):
    steps: str
    environment: str
    test_type: str
    priority: str
    automated: str


@dataclass
class ProjectFile:
    id: str
    path: str
    type: str
    commit_id: str


class DataConnector(metaclass=abc.ABCMeta):
    """
    Abstract base class for a project data connector.

    This class defines the common interface for all the supported sources.
    """

    def __init__(self):
        """
        Constructor for the ProjectDataConnector class.
        """
        self.client = None

    @abc.abstractmethod
    def test_connection(self) -> bool:
        """
        Checks validity of configuration/connection.
        """
        pass

    def get_code_files(self, dir: str = "/") -> List[ProjectFile]:
        """
        Fetches code files from the data source.

        Returns:
            A list of code file objects.
        """
        pass

    def get_bugs(self, bug_ids: List[int | str] = None) -> List[BugItem]:
        """
        Fetches Bugs from the data source.

        Returns:
            A list of Bugs objects.
        """
        pass

    def get_testcases(self, testcase_ids: List[int | str] = None) -> List[TestCase]:
        """
        Fetches Testcases from the data source.

        Returns:
            A list of Testcases objects.
        """
        pass

    def push_testcases(self, testcases: List[TestCase]) -> List[int | str]:
        """
        Push Testcases to the data source.

        Returns:
            A list of Testcases Ids.
        """
        pass
