"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""

from typing import *
from typing import List

from jira import JIRA

from core.data.connectors.base import *


class JiraConnector(DataConnector):
    """  
    Jira data connector class.  
    """

    def __init__(self, url: str, username: str, password: str, project, *args, **kwargs):
        """  
        Constructor for the JiraDataConnector class.  

        Args:  
            url: The URL of the Jira instance.  
            username: The username to authenticate with.  
            password: The password to authenticate with.  
        """
        super().__init__()
        self.url = url
        self.username = username
        self.password = password
        self.project = project

        # self.test_connection()

    def test_connection(self) -> bool:
        """  
        Checks validity of configuration/connection.  
        """
        try:
            self.client = JIRA(self.url, basic_auth=(self.username, self.password), max_retries=1)
            return True
        except:
            return False

    def get_code_files(self, dir: str = "/") -> List[ProjectFile]:
        """  
        Fetches code files from the data source.  

        Returns:  
            A list of code file objects.  
        """
        # Not implemented for Jira
        pass

    def get_bugs(self, bug_ids: List[int | str] = None) -> List[BugItem]:
        """  
        Fetches Bugs from the data source.  

        Returns:  
            A list of Bugs objects.  
        """
        if not self.client:
            self.client = JIRA(self.url, basic_auth=(self.username, self.password))

        if bug_ids:
            jql = "id in ({})".format(", ".join(str(id) for id in bug_ids))
            issues = self.client.search_issues(jql)
        else:
            issues = self.client.search_issues("project = {}".format(self.project))

        bugs = []
        for issue in issues:
            bug = BugItem(
                id=issue.id,
                type="Bug",
                title=issue.fields.summary,
                description=issue.fields.description,
                created_by=issue.fields.creator.displayName,
                created_date=issue.fields.created,
                change_date=issue.fields.updated,
                release=issue.fields.fixVersions[0].name if issue.fields.fixVersions else "",
                assigned_to=issue.fields.assignee.displayName if issue.fields.assignee else "",
                state=issue.fields.status.name,
                priority=issue.fields.priority.name,
                severity=issue.fields.customfield_10009 or "2_Medium",
                resolution=issue.fields.resolution.name if issue.fields.resolution else "",
                resolved_by=issue.fields.resolution.name if issue.fields.resolution else "",
                meta=issue.fields
            )
            bugs.append(bug)

        return bugs

    def get_testcases(self, testcase_ids: List[int | str] = None) -> List[TestCase]:
        """  
        Fetches Testcases from the data source.  

        Returns:  
            A list of Testcases objects.  
        """
        if not self.client:
            self.client = JIRA(self.url, basic_auth=(self.username, self.password))

        if testcase_ids:
            jql = "id in ({})".format(", ".join(str(id) for id in testcase_ids))
            issues = self.client.search_issues(jql)
        else:
            issues = self.client.search_issues("project = TEST")

        testcases = []
        for issue in issues:
            testcase = TestCase(
                id=issue.id,
                type="Testcase",
                title=issue.fields.summary,
                description=issue.fields.description,
                created_by=issue.fields.creator.displayName,
                created_date=issue.fields.created,
                change_date=issue.fields.updated,
                release=issue.fields.fixVersions[0].name if issue.fields.fixVersions else "",
                steps=issue.fields.customfield_10010 if hasattr(issue.fields, "customfield_10010") else "",
                environment=issue.fields.customfield_10011 if hasattr(issue.fields, "customfield_10011") else "",
                test_type=issue.fields.customfield_10012 if hasattr(issue.fields, "customfield_10012") else "",
                priority=issue.fields.priority.name,
                automated=issue.fields.customfield_10013 if hasattr(issue.fields, "customfield_10013") else "",
            )
            testcases.append(testcase)

        return testcases

    def push_testcases(self, testcases: List[TestCase]) -> List[int | str]:
        """  
        Push Testcases to the data source.  

        Returns:  
            A list of Testcases Ids.  
        """
        if not self.client:
            self.client = JIRA(self.url, basic_auth=(self.username, self.password))

        issue_ids = []
        for testcase in testcases:
            issue_dict = {
                "project": {"key": "TEST"},
                "summary": testcase.title,
                "description": testcase.description,
                "issuetype": {"name": "Test"},
                "priority": {"name": testcase.priority},
                "customfield_10010": testcase.steps,
                "customfield_10011": testcase.environment,
                "customfield_10012": testcase.test_type,
                "customfield_10013": testcase.automated,
            }
            issue = self.client.create_issue(fields=issue_dict)
            issue_ids.append(issue.id)

        return issue_ids
