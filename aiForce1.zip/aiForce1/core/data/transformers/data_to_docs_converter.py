"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from typing import List, Literal

from langchain.document_loaders import DataFrameLoader
from langchain.schema.document import Document
from pandas import DataFrame


def convert_dataframe_to_documents(
    data_type: Literal['code', 'requirement', 'feature', 'testcase', 'testsuite', 'defect', 'api', 'testcase_recommendation'],
    df: DataFrame
) -> List[Document]:
    print("Converting the dataframe to documents...")
    df = df.astype(str)

    if data_type == 'code':
        df['page_content'] = 'Filename: ' + df['filename'] + '\nCode: ' + df['source_code']

    if data_type == 'requirement':
        df['page_content'] = 'Id: ' + df['id'] + '\nTitle: ' + df['title']

    if data_type == 'feature':
        df['page_content'] = 'Feature: ' + df['feature']

    if data_type == 'testcase':
        df['page_content'] = 'Id: ' + df['id'] + '\nTitle: ' + df['title']

    if data_type == 'testsuite':
        df['page_content'] = 'Id: ' + df['id'] + '\nTitle: ' + df['title']

    if data_type == 'defect':
        df['page_content'] = 'Id: ' + df['defectId'] + '\nTitle: ' + df['title']

    if data_type == 'api':
        df['page_content'] = 'Funcname: ' + df['func_name'] + '\nAPIDetails: ' + df['source_code']

    if data_type == 'testcase_recommendation':
        df['page_content'] = 'Id: ' + df['testcaseId'] + '\nTitle: ' + df['title']

    loader = DataFrameLoader(df, page_content_column='page_content')
    docs = loader.load()
   
    return docs
