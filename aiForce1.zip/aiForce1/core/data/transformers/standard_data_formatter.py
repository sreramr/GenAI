"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import json
import re
from typing import Literal

from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.schema.language_model import BaseLanguageModel
from langchain.schema.output_parser import BaseOutputParser
from pandas import DataFrame

PROMPT = """Dataframe:
{df}

I need following columns must be present in the dataframe.
Required columns: {required_columns}

Please rename columns in the dataframe to satisfy my requirement.
Return JSON object containing the mappings of the renamed columns.

Example output:
```json
{{
    "Id": "id",
    "Title": "title",
    "Desc": "description"
}}
```
"""


class JsonParser(BaseOutputParser):

    def parse(self, text: str):
        pattern = r'{[^}]*}'
        matches = re.match(pattern, text)
        column_mapping = {}

        if matches:
            column_mapping = json.loads(matches.group())

        return column_mapping


def standardize_dataset_df(
    data_type: Literal['code', 'requirement', 'feature', 'testcase', 'testsuite', 'defect', 'api', 'testcase_recommendation'],
    llm: BaseLanguageModel,
    df: DataFrame
) -> DataFrame:
    print("Standardizing the dataset...")
    # Basic
    df = df.rename(columns={
        "Title": "title",
        "Id": "id",
        "Description": "description",
        "Feature": "feature"
    })

    required_columns = []
    if data_type == 'requirement':
        required_columns = ["id", "title", "description"]

    if data_type == 'feature':
        required_columns = ["feature"]

    if data_type == 'testcase':
        required_columns = ["id", "title", "description"]

    if data_type == 'testsuite':
        required_columns = ["id", "title"]

    if data_type == 'defect':
        required_columns = ["title", "description"]

    if data_type == 'testcase_recommendation':
        required_columns = ["title"]

    # Advance
    missing_columns = [col for col in required_columns if col not in df.columns.tolist()]
    if missing_columns:
        prompt = PromptTemplate(template=PROMPT, input_variables=["df", "required_columns"])
        chain = LLMChain(llm=llm, prompt=prompt, output_parser=JsonParser())
        mapping = chain.run(df=df.head(2).to_string(index=False), required_columns=str(required_columns))

        if isinstance(mapping, dict):
            df = df.rename(columns=mapping)

    missing_columns = [col for col in required_columns if col not in df.columns.tolist()]
    if missing_columns:
        raise ValueError(f"{data_type.title()} has following columns missing: {str(missing_columns)}")

    return df
