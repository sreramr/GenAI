import os 

from core.data.loaders.document.base import  BaseDocumentParser


def create_document_parser(input_file) -> BaseDocumentParser:
    input_type = os.path.splitext(input_file)[1]
    if input_type == ".txt":
        from core.data.loaders.document.txt_parser import TxtParser
        return TxtParser(input_file)

    if input_type == ".docx":
        from core.data.loaders.document.docx_parser import DocxParser
        return DocxParser(input_file)


    raise ValueError("Invalid parameter, input_type={}".format(input_type))


__all__ = [
    "BaseCodeParser",
    "create_document_parser"
]
