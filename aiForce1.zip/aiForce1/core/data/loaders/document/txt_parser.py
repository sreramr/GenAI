"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import re
from .base import BaseDocumentParser

class TxtParser(BaseDocumentParser):
    def __init__(self, input_file) -> None:
        super().__init__(input_file)
        self.input_file = input_file

    def get_all_codes_by_type(self, regex_pattern=r'#{5,}'):
        result = []
        doc_str = self._read_docsfile(self.input_file)
        sections = re.split(regex_pattern, doc_str)
        for i, section in enumerate(sections, start=0):
            if len(section.strip()) != 0:
                # print(f"Section {i}:", section.strip())
                function_name = re.search(r"API:(.+)", section.strip(), re.IGNORECASE).group(1)
                result.append(
                    {'func_name': function_name if len(function_name) > 0 else "", "type": "function_def",
                    "source_code": section.strip()})
        return result
  