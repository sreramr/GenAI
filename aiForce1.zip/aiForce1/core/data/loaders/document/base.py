"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import abc
import os
from abc import abstractmethod
from glob import glob

from core.data.loaders.text_data import load_data_from_file
    

class BaseDocumentParser(abc.ABC):
    def __init__(self, docs_root) -> None:
        self.docs_root = docs_root


    @staticmethod
    def _get_files(code_root, include_pattern):
        code_files = [y for x in os.walk(code_root)
                      for y in glob(os.path.join(x[0], include_pattern))]
        return code_files
    
    
    @abstractmethod
    def get_all_codes_by_type(self, regex_pattern):
        pass

    
    @staticmethod
    def _read_docsfile(input_file):
        doc_content = load_data_from_file(input_file)
        return doc_content