"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os
import charset_normalizer
from multiprocessing import Pool
from typing import List, Literal
from tqdm import tqdm

def load_code_from_file(source_file):
    code_str = str(charset_normalizer.from_path(source_file).best())
    return code_str


def load_code_from_dir(source_dir: str, ext_list: List[str] = [], ignored_files: List[str] = []):
    all_files = []

    filtered_files = [file_path for file_path in all_files if file_path not in ignored_files]
    if len(ext_list) > 0:
        filtered_files = [file_path for file_path in all_files if os.path.splitext(file_path)[1] in ext_list]

    with Pool(processes=os.cpu_count()) as pool:
        results = []
        with tqdm(total=len(filtered_files), desc='Loading code files', ncols=80) as pbar:
            for i, docs in enumerate(pool.imap_unordered(load_code_from_file, filtered_files)):
                results.extend(docs)
                pbar.update()
    return results


def load_alternatecode_from_file(source_file):
    with open(source_file, 'r') as file:
        code = file.readlines()
        return code
      
        
def load_alternatecode_from_dir(source_dir: str, ext_list: List[str] = [], ignored_files: List[str] = []):
    all_files = []

    filtered_files = [file_path for file_path in all_files if file_path not in ignored_files]
    if len(ext_list) > 0:
        filtered_files = [file_path for file_path in all_files if os.path.splitext(file_path)[1] in ext_list]

    with Pool(processes=os.cpu_count()) as pool:
        results = []
        with tqdm(total=len(filtered_files), desc='Loading code files', ncols=80) as pbar:
            for i, docs in enumerate(pool.imap_unordered(load_alternatecode_from_file, filtered_files)):
                results.extend(docs)
                pbar.update()
    return results
