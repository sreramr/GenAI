from core.data.loaders.code.base import BaseCodeParser

SUPPORTED_LANGUAGES = ["python", "java", "csharp"]

def create_code_parser(code_root, language) -> BaseCodeParser:
    if language == "python":
        from core.data.loaders.code.python_parser import PythonCodeParser
        return PythonCodeParser(code_root)

    if language == "java":
        from core.data.loaders.code.java_parser import JavaCodeParser
        return JavaCodeParser(code_root)

    if language == "csharp":
        from core.data.loaders.code.csharp_parser import CSharpCodeParser
        return CSharpCodeParser(code_root)

    raise ValueError("Invalid parameter, language={}".format(language))


__all__ = [
    "BaseCodeParser",
    "create_code_parser"
]
