"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import abc
import os
from abc import abstractmethod
from glob import glob

from core.data.loaders.code_data import load_code_from_file, load_alternatecode_from_file


class BaseCodeParser(abc.ABC):
    def __init__(self, code_root) -> None:
        self.code_root = code_root

    @staticmethod
    def _get_files(code_root, include_pattern):
        code_files = [y for x in os.walk(code_root)
                      for y in glob(os.path.join(x[0], include_pattern))]
        return code_files

    @staticmethod
    def _get_total_locs(code_files):
        count = 0
        for file in code_files:
            with open(file) as f:
                count += len(f.readlines())
        return count

    @abstractmethod
    def get_all_codes_by_type(self, code_type):
        pass

    @abstractmethod
    def get_parent_code_by_line_no(self, code_type, filename, line_no):
        pass

    @staticmethod
    def _read_codefile(filename):
        code_str = load_code_from_file(filename)
        return code_str

    @staticmethod
    def _read_alternate_codefile(filename):     
        code = load_alternatecode_from_file(filename)
        return code
