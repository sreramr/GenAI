"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import re

from .base import BaseCodeParser


def get_csharp_method_body(code_lines, line_number):
    opening_brackets = 0
    closing_brackets = 0
    method_body = ""
    i = line_number - 1
    # iterate through code lines from the given line number
    while i < len(code_lines):
        line = code_lines[i]
        # count opening and closing brackets
        opening_brackets += line.count("{")
        closing_brackets += line.count("}")
        # add the line to the method body
        method_body += line
        # check if the method body is complete
        if opening_brackets > 0 and opening_brackets == closing_brackets:
            break
        i += 1
    return method_body


class CSharpCodeParser(BaseCodeParser):

    def __init__(self, code_root) -> None:
        super().__init__(code_root)
        self.code_root = code_root
        self.code_files = self._get_files(code_root, include_pattern="*.cs")
        self.total_locs = self._get_total_locs(self.code_files)

    def get_all_codes_by_type(self, code_type):
        result = []
        for file in self.code_files:
            code_str = self._read_alternate_codefile(file)
            function_detail_json = self._get_function_name_and_body(code_str)
            for item in function_detail_json:
                result.append({
                    'filename': file,
                    "name": item["function_name"],
                    "source_code": item["function_body"]
                })
        return result

    def get_parent_code_by_line_no(self, code_type, filename, line_no):
        pass

    def _get_function_name_and_body(self, code_str):
        function_names = []
        for i, line in enumerate(code_str):
            match = re.search(r'\b(?:public|private|internal|protected)\s+(?:static\s+)?(?:async\s+)?(?:partial\s+)?(?:unsafe\s+)?(?:override\s+)?(?:virtual\s+)?(?:abstract\s+)?(?:extern\s+)?(?:new\s+)?(?:sealed\s+)?(?:readonly\s+)?(?:volatile\s+)?(?:void\s+)?\w+(?:<\w+>)?\s+(\w+)\s*\(', line)
            if match:
                function_names.append((match.group(1), i+1, line.strip()))
        function_details = []
        for function_name, line, code_body in function_names:
            function_details.append({
                "function_name": function_name,
                "function_body": get_csharp_method_body(code_str, line)
            })
        return function_details
