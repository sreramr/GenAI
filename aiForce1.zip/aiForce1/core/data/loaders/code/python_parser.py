"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import ast
from typing import Literal

import astor
import charset_normalizer

from .base import BaseCodeParser


class PythonCodeParser(BaseCodeParser):

    AST_TYPE_MAP = {
        "function_def": ast.FunctionDef,
        "class_def": ast.ClassDef
    }

    def __init__(self, code_root) -> None:
        super().__init__(code_root)
        self.code_root = code_root
        self.code_files = self._get_files(code_root, include_pattern="*.py")
        self.total_locs = self._get_total_locs(self.code_files)

    def _get_node_details(self, node: ast.AST, filename):
        code_str = str(charset_normalizer.from_path(filename).best())
        source_code_lines = code_str.splitlines()

        return {'name': node.name,
                # 'source_code': astor.to_source(node),
                'source_code': "\n".join(source_code_lines[node.lineno-1: node.end_lineno]),
                'lineno': node.lineno,
                'end_lineno':  node.end_lineno,
                'col_offset': node.col_offset,
                'end_col_offset': node.end_col_offset,
                'locs': (node.end_lineno - node.lineno + 1)}

    def get_all_codes_by_type(self, code_type: Literal["function_def", "class_def"]):
        result = []
        for file in self.code_files:
            tree = astor.parse_file(file)
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, self.AST_TYPE_MAP.get(code_type)):
                    result.append(
                        {'filename': file, "type": code_type,  ** self._get_node_details(node, filename=file)})
        return result

    def get_parent_code_by_line_no(self, code_type: Literal["function_def", "class_def"], filename, line_no):
        tree = astor.parse_file(filename)
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, self.AST_TYPE_MAP.get(code_type)):
                if node.lineno <= line_no and node.end_lineno >= line_no:
                    return {'filename': filename, "type": code_type, ** self._get_node_details(node, filename=filename)}
        return None

    def get_class_hirarchy_family(self, class_name):
        pass
