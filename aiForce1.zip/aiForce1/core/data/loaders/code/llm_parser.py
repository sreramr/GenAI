import re
from typing import List

from langchain.chains import LLMChain
from langchain.document_loaders import DirectoryLoader
from langchain.prompts import PromptTemplate
from langchain.schema.document import Document
from langchain.schema.language_model import BaseLanguageModel
from langchain.schema.output_parser import BaseOutputParser
from langchain.text_splitter import CharacterTextSplitter

PROMPT = """You are given a chunk of codes with line no.
```
{code}
```

Extract function level code details and return in below structured format:
`{{function_name}}: {{start_line}} - {{end_line}}`

Examples:

Input Code:
```
1 def hello_word():
2    print("Hello world")
3 
4 def greet_user(name):
5    print(f"Hi, {{name}}")
6 
7 class Student:
8    def __init__(self, name):
9        self.name = name
10     
11   def get_name(self):
12       return self.name
```

Output:
hello_word: 1 - 2
greet_user: 4 - 5
Student.__init__: 8 - 9
Student.get_name: 11 - 12
"""


class CustomOutputParser(BaseOutputParser):
    def parse(self, text: str):
        functions = re.findall(r'(\w+(\.\w+)?)\:\s(\d+)\s\-\s(\d+)', text)

        result = []
        for function in functions:
            full_function_name = function[0]
            start_line = int(function[2])
            end_line = int(function[3])
            result.append({'function_name': full_function_name, 'start_line': start_line, 'end_line': end_line})

        return result


def _add_line_no(text: str):
    lines = text.splitlines()
    lines = [str(i+1) + " " + line for i, line in enumerate(lines)]
    text = "\n".join(lines)
    return text


def split_code_to_docs(llm: BaseLanguageModel, code_dir: str, glob: str = "**/[!.]*") -> List[Document]:
    loader = DirectoryLoader(path=code_dir, glob=glob, use_multithreading=True)
    docs = loader.load()

    source_map = {}

    for d in docs:
        source_map[d.metadata.get("source")] = d.page_content
        d.page_content = _add_line_no(d.page_content)

    splitter = CharacterTextSplitter(separator="\n", chunk_size=8000)  # 2000 token, 200 LOCs
    docs = splitter.transform_documents(docs)

    prompt = PromptTemplate(template=PROMPT, input_variables=["code"])

    output_parser = CustomOutputParser()
    function_extractor_chain = LLMChain(llm=llm, prompt=prompt, output_parser=output_parser)

    functions_list = []

    for d in docs:
        functions = function_extractor_chain.run(code=d.page_content)

        for fun in functions:
            code_lines = source_map.get(d.metadata.get("source")).splitlines()

            functions_list.append({
                "filename": d.metadata.get("source"),
                "name": fun.get("function_name"),
                "source_code": "\n".join(code_lines[fun.get("start_line")-1: fun.get("end_line")])
            })

    return functions_list
