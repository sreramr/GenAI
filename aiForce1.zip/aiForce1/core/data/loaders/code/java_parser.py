"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from typing import Literal

import javalang

from .base import BaseCodeParser


class JavaCodeParser(BaseCodeParser):
    AST_TYPE_MAP = {
        "function_def": javalang.tree.MethodDeclaration,
        "class_def": javalang.tree.ClassDeclaration
    }

    def __init__(self, code_root) -> None:
        super().__init__(code_root)
        self.code_root = code_root
        self.code_files = self._get_files(code_root, include_pattern="*.java")
        self.total_locs = self._get_total_locs(self.code_files)

    def _get_start_end_lines(self, node, file):
        stack = []
        start_line = int(node.position.line)
        end_line = start_line
        code_lines = self._read_codefile(file).splitlines()
        start_curl_flag = False

        for line in code_lines[start_line-1:]:
            for char in line:
                if char == "{":
                    start_curl_flag = True
                    stack.append(char)

                if char == "}" and len(stack) > 0:
                    stack.pop()

            if start_curl_flag and len(stack) == 0:
                break

            end_line += 1
        return start_line, end_line

    def _get_node_details(self, node, filename):
        code_str = self._read_codefile(filename)
        source_code_lines = code_str.splitlines()

        start_line, end_line = self._get_start_end_lines(node, filename)

        return {'name': node.name,
                # 'source_code': astor.to_source(node),
                'source_code': "\n".join(source_code_lines[start_line-1: end_line]),
                'lineno': start_line,
                'end_lineno':  end_line,
                'col_offset': node.position.column,
                'end_col_offset': node.position.column,
                'locs': (end_line - start_line + 1)}

    def get_all_codes_by_type(self, code_type: Literal["function_def"]):
        result = []
        for file in self.code_files:
            code_str = self._read_codefile(file)
            tree = javalang.parse.parse(code_str)
            for _, node in tree.filter(self.AST_TYPE_MAP.get(code_type)):
                result.append(
                    {'filename': file, "type": code_type,  ** self._get_node_details(node, filename=file)})
        return result

    def get_parent_code_by_line_no(self, code_type: Literal["function_def"], filename, line_no):
        code_str = self._read_codefile(filename)
        tree = javalang.parse.parse(code_str)
        for _, node in tree.filter(self.AST_TYPE_MAP.get(code_type)):
            start_line, end_line = self._get_start_end_lines(node, filename)
            if start_line <= line_no and end_line >= line_no:
                return {'filename': filename, "type": code_type, ** self._get_node_details(node, filename=filename)}
        return None

    def get_class_hirarchy_family(self, class_name):
        pass
