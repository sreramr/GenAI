import pandas as pd
import docx
# from PyPDF2 import PdfReader

class CustomLoader():    
    def load_docx(file_path):
        doc = docx.Document(file_path)
        text = []
        for paragraph in doc.paragraphs:
            text.append(paragraph.text)
        return "\n".join(text)
    
    # def load_pdf(file_path):
    #     reader = PdfReader(file_path)
    #     number_of_pages = len(reader.pages)
    #     text = []
    #     for page_num in range(number_of_pages):
    #         page = reader.pages[page_num]
    #         text.append(page.extract_text())
    #     return "\n".join(text)
    
    def load_txt(file_path):
        f = open(file_path, "r")
        data_content = f.read()
        return data_content
    