"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os
import chardet
import pandas as pd

PANDAS_FILE_READER_MAPPING = {
    ".csv": {"reader": pd.read_csv, "kwargs": {}},
    ".xlsx": {"reader": pd.read_excel, "kwargs": {}},
    ".json": {"reader": pd.read_json, "kwargs": {}}
}

def load_dataframe_from_file(input_file: str) -> pd.DataFrame:
    basename, ext = os.path.splitext(input_file)
    module = PANDAS_FILE_READER_MAPPING.get(ext)

    reader = module.get("reader", pd.read_table)
    kwargs = module.get("kwargs", {})

    if ext == ".csv":
        encoding = detect_encoding(input_file)
        kwargs["encoding"] = encoding

    df = reader(input_file, **kwargs)
    return df

def detect_encoding(file_path):
    with open(file_path, 'rb') as file:
        result = chardet.detect(file.read())
        return result['encoding']