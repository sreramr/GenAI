"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import glob
import os
from multiprocessing import Pool
from typing import List, Literal
from tqdm import tqdm

from langchain.docstore.document import Document
from langchain.document_loaders import (CSVLoader, PDFMinerLoader,
                                        PythonLoader, TextLoader,
                                        UnstructuredExcelLoader,
                                        UnstructuredWordDocumentLoader)
from langchain.schema.document import Document


from core.data.loaders.loader_utility import CustomLoader

FILE_READER_MAPPING_LANGCHAIN = {
    ".docx": (UnstructuredWordDocumentLoader, {}),
    ".pdf": (PDFMinerLoader, {}),
    ".txt": (TextLoader, {"encoding": "utf8"}),
    # ".doc": (UnstructuredWordDocumentLoader, {}),
    # Add more mappings for other file extensions and loaders as needed
}

FILE_READER_MAPPING = {
    ".docx": (CustomLoader.load_docx, {}),
    ".txt": (CustomLoader.load_txt, {})
    # ".doc": (CustomLoader.load_docx, {}),
    # ".pdf": (CustomLoader.load_pdf, {}),
    # Add more mappings for other file extensions and loaders as needed
}


def load_data_from_file(source_file: str, use_langchain:bool = False):
    ext_val = os.path.splitext(source_file)[1]
    if use_langchain:
        if ext_val in FILE_READER_MAPPING_LANGCHAIN:
            loader_class, loader_args = FILE_READER_MAPPING_LANGCHAIN[ext_val]
            loader = loader_class(source_file, **loader_args)
            return loader.load()
        raise ValueError(f"Unsupported file extension '{ext_val}'")
    else:
        if ext_val in FILE_READER_MAPPING:
            loader_class, loader_args = FILE_READER_MAPPING[ext_val]
            doc_content = loader_class(source_file, **loader_args)
            return doc_content
        raise ValueError(f"Unsupported file extension '{ext_val}'")


def load_data_from_dir(source_dir: str, ext_list: List[str] = [], ignored_files: List[str] = [], use_langchain:bool = False):
    """
    Loads all documents from the source documents directory, and filter based on extension
    """
    LOADER_MAPPING = FILE_READER_MAPPING_LANGCHAIN if use_langchain else FILE_READER_MAPPING

    all_files = []
    for ext in LOADER_MAPPING:
        all_files.extend(
            glob.glob(os.path.join(source_dir, f"**/*{ext}"), recursive=True)
        )

    filtered_files = [file_path for file_path in all_files if file_path not in ignored_files]

    if len(ext_list) > 0:
        filtered_files = [file_path for file_path in all_files if os.path.splitext(file_path)[1] in ext_list]

    with Pool(processes=os.cpu_count()) as pool:
        results = []
        with tqdm(total=len(filtered_files), desc='Loading new documents', ncols=80) as pbar:
            for i, docs in enumerate(pool.imap_unordered(load_data_from_file, filtered_files, use_langchain)):
                results.extend(docs)
                pbar.update()
    return results


