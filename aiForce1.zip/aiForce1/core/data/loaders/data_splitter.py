"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import glob
import os
import tiktoken
from multiprocessing import Pool
from typing import List, Literal
from tqdm import tqdm

from core.data.loaders.code_data import load_code_from_file, load_code_from_dir
from core.data.loaders.text_data import load_data_from_file, load_data_from_dir

from langchain.schema.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

SOURCE_TYPE_FOLDER = "Folder"
SOURCE_TYPE_FILE = "File"

SUPPORTED_SPLITTER_LANG = ['cpp', 'go', 'java', 'kotlin', 'js', 'ts', 'php', 'proto', 'python',
                           'rst', 'ruby', 'rust', 'scala', 'swift', 'markdown', 'latex', 'html',
                           'sol', 'csharp', 'cobol']

def process_code_files(source_type, source, credentials={}, chunk_size=4000, chunk_overlap=200, language=None,
                       ext_list: List[str] = [], ignored_files: List[str] = [], use_langchain: bool = False) -> List[Document]:
    """
    Load documents and split in chunks
    """
    final_docs = []
    print(f"Loading data from {source}")
    if source_type == SOURCE_TYPE_FOLDER:
        final_docs.extend(load_data_from_dir(source, ext_list, ignored_files, use_langchain=False))
    elif source_type == SOURCE_TYPE_FILE:
        final_docs.append(load_code_from_file(source, use_langchain=False))

    if len(final_docs) < 1:
        print("No new documents to load")
        exit(0)
    print(f"Loaded {len(final_docs)} new documents from {source}")
    if language:
        if language in SUPPORTED_SPLITTER_LANG:
            print("Processing code files..")
            text_splitter = RecursiveCharacterTextSplitter.from_language(language=language,
                                                                         chunk_size=chunk_size,  # 500 tokens, 50 LOCs
                                                                         chunk_overlap=chunk_overlap)
            texts, metadata = [], []
            for docs in final_docs:
                texts.append(docs.page_content)
                metadata.append(docs.metadata)
            texts = text_splitter.create_documents(texts, metadata)
            print("Code files processed.")
            return texts
        else:
            raise ValueError(f"Unsupported language '{language}'")
    else:
        raise ValueError(f"Language Mandatory!")


def process_documents(source_type, source, separators, credentials={}, chunk_size=4000, chunk_overlap=200, language=None,
                      ext_list: List[str] = [], ignored_files: List[str] = [], use_langchain: bool = False) -> List[Document]:
    """
    Load documents and split in chunks
    """
    final_docs = []
    print(f"Loading data from {source}")
    if source_type == SOURCE_TYPE_FOLDER:
        final_docs.extend(load_data_from_dir(source, ext_list, ignored_files, use_langchain))
    elif source_type == SOURCE_TYPE_FILE:
        final_docs.append(load_data_from_file(source, use_langchain))

    if len(final_docs) < 1:
        print("No new documents to load")
        exit(0)
    print(f"Loaded {len(final_docs)} new documents from {source}")

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                                   separators=separators)
    texts = text_splitter.split_documents(final_docs)
    print(f"Split into {len(texts)} chunks of text (max. {chunk_size} tokens each)")
    return texts


def load_text_data_to_docs(
    input_path: str,
    data_type: Literal["text", "code"] = "text",
    chunk_size=4000,  # 1000 tokens
    ext_list=[],
    ignored_files=[],
    language: str = None,
    use_langchain: bool = False,
    * args,
    **kwargs
) -> List[Document]:

    source_type = "Folder" if os.path.isdir(input_path) else "File"

    if data_type == "code":
        return process_code_files(
            source_type=source_type,
            source=input_path,
            chunk_size=chunk_size,
            ext_list=ext_list,
            ignored_files=ignored_files,
            language=language,
            use_langchain=use_langchain
        )

    return process_documents(
        source_type=source_type,
        source=input_path,
        separators=["\n", "\n\n"],
        chunk_size=chunk_size,
        ext_list=ext_list,
        ignored_files=ignored_files,
        use_langchain=use_langchain
    )


def count_tokens(filecontent, encoding_name="r50k_base"):
    encoding = tiktoken.get_encoding(encoding_name)
    num_tokens = len(encoding.encode(filecontent))
    return num_tokens


def code_splitter(filecontent, lang, chunk_size=5000, chunk_overlap=15):
    code_splitter = RecursiveCharacterTextSplitter.from_language(language=lang,
                                                                chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    code_docs = code_splitter.create_documents([filecontent])
    return code_docs


def text_splitter(filecontent, chunk_size=15000, chunk_overlap=20):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                                length_function=len, add_start_index=True)
    text_docs = text_splitter.create_documents([filecontent])
    return text_docs
