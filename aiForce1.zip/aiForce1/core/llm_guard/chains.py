import logging

from core.llm_guard.output_scanner import LLMGuardOutputChain
from core.llm_guard.prompt_scanner import LLMGuardPromptChain

logger = logging.getLogger(__name__)

try:
    import llm_guard
except ImportError:
    raise ModuleNotFoundError(
        "Could not import llm-guard python package. "
        "Please install it with `pip install llm-guard`."
    )

use_onnx = False


def create_prompt_scanner_chain():
    vault = llm_guard.vault.Vault()

    llm_guard_prompt_scanner = LLMGuardPromptChain(
        vault=vault,
        scanners={
            "Anonymize": {"use_faker": True, "use_onnx": use_onnx},
            "BanSubstrings": {
                "substrings": ["Laiyer"],
                "match_type": "word",
                "case_sensitive": False,
                "redact": True,
            },
            "BanTopics": {"topics": ["violence"], "threshold": 0.7, "use_onnx": use_onnx},
            "Code": {"denied": ["go"], "use_onnx": use_onnx},
            "Language": {"valid_languages": ["en"], "use_onnx": use_onnx},
            "PromptInjection": {"threshold": 0.95, "use_onnx": use_onnx},
            "Regex": {"patterns": ["Bearer [A-Za-z0-9-._~+/]+"]},
            "Secrets": {"redact_mode": "all"},
            "Sentiment": {"threshold": -0.05},
            "TokenLimit": {"limit": 4096},
            "Toxicity": {"threshold": 0.8, "use_onnx": use_onnx},
        },
        scanners_ignore_errors=[
            "Anonymize",
            "BanSubstrings",
            "Regex",
            "Secrets",
            "TokenLimit",
            "PromptInjection",
        ],  # These scanners redact, so I can skip them from failing the prompt
    )

    return llm_guard_prompt_scanner


def create_output_scanner_chain():
    vault = llm_guard.vault.Vault()
    llm_guard_output_scanner = LLMGuardOutputChain(
        vault=vault,
        scanners={
            "BanSubstrings": {
                "substrings": ["Laiyer"],
                "match_type": "word",
                "case_sensitive": False,
                "redact": True,
            },
            "BanTopics": {"topics": ["violence"], "threshold": 0.7, "use_onnx": use_onnx},
            "Bias": {"threshold": 0.75, "use_onnx": use_onnx},
            "Code": {"denied": ["go"], "use_onnx": use_onnx},
            "Deanonymize": {},
            "FactualConsistency": {"minimum_score": 0.5, "use_onnx": use_onnx},
            "JSON": {"required_elements": 0, "repair": True},
            "Language": {
                "valid_languages": ["en"],
                "threshold": 0.5,
                "use_onnx": use_onnx,
            },
            "LanguageSame": {"use_onnx": use_onnx},
            "MaliciousURLs": {"threshold": 0.75, "use_onnx": use_onnx},
            "NoRefusal": {"threshold": 0.5, "use_onnx": use_onnx},
            "Regex": {
                "patterns": ["Bearer [A-Za-z0-9-._~+/]+"],
            },
            "Relevance": {"threshold": 0.5, "use_onnx": use_onnx},
            "Sensitive": {"redact": False, "use_onnx": use_onnx},
            "Sentiment": {"threshold": -0.05},
            "Toxicity": {"threshold": 0.7, "use_onnx": use_onnx},
        },
        scanners_ignore_errors=["BanSubstrings", "Regex", "Sensitive"],
    )

    return llm_guard_output_scanner
