"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
# **********************Main Code_v9*************

import logging
from typing import Any, List
# from llm_guard import scan_prompt
# from llm_guard.vault import Vault
from langchain.schema import PromptValue
from Utility.db_utility.db_utility import get_sec_scanner_config


# from llm_guard.input_scanners import (
#     Anonymize,
#     BanTopics,
#     #    PromptInjection,
#     Toxicity,
#     BanSubstrings,
#     Secrets,
# )


def get_input_scanners():
    from llm_guard.vault import Vault
    from llm_guard.input_scanners import (
        Anonymize,
        BanTopics,
        #    PromptInjection,
        Toxicity,
        BanSubstrings,
        Secrets,
    )
    result = get_sec_scanner_config()
    selectedInputScanners = result['data'][0]['input_scanner']
    default_substring_list = ["Ignore", "Pretend", "Act", "Imagine", "Assume", "Impersonate", "evil", "ANTIGPT",
                              "Hypothetical", "Delete Database", "Delete all"]
    substring_list = result['data'][0]['additional_info'].get('ban_substring', default_substring_list)

    # Define the substring list and other scanner configurations
    vault = Vault()
    logger = logging.getLogger(__name__)

    # sub_topic_list = ["Prompt Injection", "Prompt Leaking", "violence",
    #                   "Hacking", "privilege escalation", "racism",
    #                   "politics", "Jail Breaking"]
    # sub_topic_list = ["Prompt Injection","Hacking","Prompt Leaking","Jail Breaking","privilege escalation", "Racism"]

    # sub_topic_list = ["delete schema", "Print always"]
    # substring_list = ["delete schema", "Print always"]

    sub_topic_list = ["Prompt Injection", "Prompt Leaking", "Jail Breaking"]

    input_scanners = []
    scanner_mapping = {
        "Anonymize": Anonymize(vault),
        "Ban Topics": BanTopics(topics=sub_topic_list, threshold=0.5),
        "Toxicity": Toxicity(threshold=0.5),
        "Secrets": Secrets(redact_mode="all"),
        "Ban Substrings": BanSubstrings(
            substrings=substring_list,
            match_type="word",
            case_sensitive=True,
            redact=True,
        ),
    }

    input_scanners = [scanner_mapping[scanner] for scanner in selectedInputScanners if scanner in scanner_mapping]

    # print(">>>Selected Input Scanners: ", input_scanners)
    return input_scanners


# input_scanners = [
#     #Anonymize(vault), 
#     # BanTopics(topics=sub_topic_list, threshold=0.5),
#     # Toxicity(threshold=0.5),
#     BanSubstrings(substrings=substring_list,
#                    match_type="word",
#                    case_sensitive=True, redact=True),
#     Secrets(redact_mode = "all"),
# ]

class WarningCaptureHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.captured_warnings = []

    def emit(self, record):
        self.captured_warnings.append(record.getMessage())


class PromptScanner:
    def __init__(self, input_scanners: List[Any],
                 raise_error: bool = False,
                 fail_fast: bool = False):
        self.input_scanners = input_scanners
        self.raise_error = raise_error
        self.fail_fast = fail_fast
        self.warning_messages = []

        # Create a custom logging handler to capture warnings
        self.warning_capture_handler = WarningCaptureHandler()
        self.logger = logging.getLogger("llm-guard")
        self.logger.addHandler(self.warning_capture_handler)

    def scan_prompt(self, prompt: PromptValue) -> tuple:
        from llm_guard import scan_prompt
        error_report = ""
        sanitized_prompt, results_valid, results_score, warning_msg = scan_prompt(
            self.input_scanners, prompt.to_string(), self.fail_fast
        )
        # print("sanitized_prompt:>>", sanitized_prompt)
        print("Warning Msg :>>", warning_msg)
        if any(not result for result in results_valid.values()):
            error_report = self.generate_error_report(results_valid, results_score, warning_msg)
            return results_valid, sanitized_prompt, error_report
        else:
            return results_valid, sanitized_prompt, None

    def generate_error_report(self, results_valid, results_score, warning_msg) -> str:
        error_string = "<font color='red'>Security Issues Found.</font>\n\n"
        error_string += "<table><tr><th>Issue Type</th><th>Details</th></tr>"
        for scanner, valid in results_valid.items():
            if valid == False:
                error_string += "<tr>"
                error_string += f"<td> '{scanner}'</td>"
                error_string += "<td>" + warning_msg[scanner] + "</td>"
                error_string += "</tr>"
        error_string += "</table>"
        # error_string += f"- Scanner '{scanner}': {'Valid' if valid else 'Invalid'}\n"

        error_string += "<div style='margin-top:5px'>"
        error_string += "The data provided is not safe and poses a security threat. "
        error_string += "Further processing is not possible, and the request has been terminated."
        error_string += "</div><div style='height:10px'></div>"
        return error_string


class StringPromptValue:
    def __init__(self, text: str):
        self.text = text

    def to_string(self) -> str:
        return self.text


def run_scanner(input_prompt):
    try:
        input_scanners = get_input_scanners()
        prompt_value = StringPromptValue(text=input_prompt)
        prompt_scanner = PromptScanner(input_scanners, raise_error=True)
        results_valid, sanitized_prompt, error_report = prompt_scanner.scan_prompt(prompt_value)

        if all(results_valid.values()):
            return True, sanitized_prompt, error_report
        else:
            return False, sanitized_prompt, error_report
    except Exception as e:
        raise Exception(f"Error while running llm-guard: {str(e)}")
