-- 1. CREATE public."CC_CodeDocumentSplit"
CREATE TABLE IF NOT EXISTS public."CC_CodeDocumentSplit"
(
    id serial NOT NULL PRIMARY KEY,
    artifact_type character varying(30),
    development integer,
    testing integer,
    support integer,
    program_management integer
);


-- 2. CREATE public."CC_ExpectedBenefit"
CREATE TABLE IF NOT EXISTS public."CC_ExpectedBenefit" (
    id serial NOT NULL PRIMARY KEY,
    potential character varying(30),
    expected_benefit integer
);


-- 3. CREATE public."CC_FineTuningMultifier"
CREATE TABLE IF NOT EXISTS public."CC_FineTuningMultifier"
(
    id serial NOT NULL PRIMARY KEY,
    finetune_cycle character varying(30),
    development numeric(6,2),
    testing numeric(6,2),
    support numeric(6,2),
    program_management numeric(6,2)
);



-- 4. CREATE public."CC_ImplementTime_OpsCost"
CREATE TABLE IF NOT EXISTS public."CC_ImplementTime_OpsCost" (
    id serial NOT NULL PRIMARY KEY,
    parameter character varying(30),
    months numeric(6,2),
    ops_cost_multifier integer
);


-- 5. CREATE public."CC_MonthlyUsageFrequency"
CREATE TABLE IF NOT EXISTS public."CC_MonthlyUsageFrequency" (
    id serial NOT NULL PRIMARY KEY,
    parameter character varying(30),
    monthly_usage integer
);


-- 6. CREATE public."CC_OtherConstants"
CREATE TABLE IF NOT EXISTS public."CC_OtherConstants" (
    id serial NOT NULL PRIMARY KEY,
    constant_name character varying(50),
    constant_value double precision
);


-- 7. CREATE public."CC_PhaseDetails"
CREATE TABLE IF NOT EXISTS public."CC_PhaseDetails" (
    id serial NOT NULL PRIMARY KEY,
    phase character varying(30),
    sub_phase character varying(100),
    effort_weightage numeric(6,1),
    benefit_potential character varying(30),
    impl_time_ops_cost character varying(30),
    finetune_cycle character varying(30),
    billrate_type character varying(30),
    custom_billrate numeric(6,2),
    monthly_usage character varying(30)
);


-- 8. CREATE public."CC_DefaultPhaseDetails"
CREATE TABLE IF NOT EXISTS public."CC_DefaultPhaseDetails" (
    id serial NOT NULL PRIMARY KEY,
    phase character varying(30),
    sub_phase character varying(100),
    effort_weightage numeric(6,1),
    benefit_potential character varying(30),
    impl_time_ops_cost character varying(30),
    finetune_cycle character varying(30),
    billrate_type character varying(30),
    custom_billrate numeric(6,2),
    monthly_usage character varying(30)
);
--------------------------------------------------------------------------

-- DROP THE MASTER TABLE VALUES
-- 1. DROP public."CC_CodeDocumentSplit"
TRUNCATE TABLE public."CC_CodeDocumentSplit" CASCADE;

-- 2. DROP public."CC_ExpectedBenefit"
TRUNCATE TABLE public."CC_ExpectedBenefit" CASCADE;  

-- 3. DROP public."CC_FineTuningMultifier"
TRUNCATE TABLE public."CC_FineTuningMultifier" CASCADE;  

-- 4. DROP public."CC_ImplementTime_OpsCost"
TRUNCATE TABLE public."CC_ImplementTime_OpsCost" CASCADE;  

-- 5. DROP public."CC_MonthlyUsageFrequency"
TRUNCATE TABLE public."CC_MonthlyUsageFrequency" CASCADE;  

-- 6. DROP public."CC_OtherConstants"
TRUNCATE TABLE public."CC_OtherConstants" CASCADE; 

-- 7. DROP public."CC_PhaseDetails"
TRUNCATE TABLE public."CC_PhaseDetails" CASCADE; 

-- 8. DROP public."CC_DefaultPhaseDetails"
TRUNCATE TABLE public."CC_DefaultPhaseDetails" CASCADE; 

--------------------------------------------------------------------------

-- 1. INSERT public."CC_CodeDocumentSplit"
INSERT INTO public."CC_CodeDocumentSplit" VALUES (1, 'Documentation', 5, 30, 60, 5);
INSERT INTO public."CC_CodeDocumentSplit" VALUES (2, 'Code', 70, 30, 0, 0);


-- 2. INSERT public."CC_ExpectedBenefit"
INSERT INTO public."CC_ExpectedBenefit" (id, potential, expected_benefit) VALUES (1, 'Low', 20);
INSERT INTO public."CC_ExpectedBenefit" (id, potential, expected_benefit) VALUES (2, 'Medium', 40);
INSERT INTO public."CC_ExpectedBenefit" (id, potential, expected_benefit) VALUES (3, 'High', 60);
INSERT INTO public."CC_ExpectedBenefit" (id, potential, expected_benefit) VALUES (4, 'Very High', 80);
INSERT INTO public."CC_ExpectedBenefit" (id, potential, expected_benefit) VALUES (5, 'Not Applicable', 0);


-- 3. INSERT public."CC_FineTuningMultifier"
INSERT INTO public."CC_FineTuningMultifier" VALUES (1, 'Low', 0.08, 0.06, 0.08, 0.17);
INSERT INTO public."CC_FineTuningMultifier" VALUES (2, 'Medium', 0.25, 0.21, 0.24, 0.67);
INSERT INTO public."CC_FineTuningMultifier" VALUES (3, 'High', 0.58, 0.71, 0.58, 1.67);
INSERT INTO public."CC_FineTuningMultifier" VALUES (4, 'N/A', 0.00, 0.00, 0.00, 0.00);


-- 4. INSERT public."CC_ImplementTime_OpsCost"
INSERT INTO public."CC_ImplementTime_OpsCost" (id, parameter, months, ops_cost_multifier) VALUES (1, 'Low', 0.50, 20);
INSERT INTO public."CC_ImplementTime_OpsCost" (id, parameter, months, ops_cost_multifier) VALUES (2, 'Medium', 1.00, 30);
INSERT INTO public."CC_ImplementTime_OpsCost" (id, parameter, months, ops_cost_multifier) VALUES (3, 'High', 1.50, 40);
INSERT INTO public."CC_ImplementTime_OpsCost" (id, parameter, months, ops_cost_multifier) VALUES (4, 'N/A', 0.00, 0);


-- 5. INSERT public."CC_MonthlyUsageFrequency"
INSERT INTO public."CC_MonthlyUsageFrequency" (id, parameter, monthly_usage) VALUES (1, 'Low', 10);
INSERT INTO public."CC_MonthlyUsageFrequency" (id, parameter, monthly_usage) VALUES (2, 'Medium', 25);
INSERT INTO public."CC_MonthlyUsageFrequency" (id, parameter, monthly_usage) VALUES (3, 'High', 50);
INSERT INTO public."CC_MonthlyUsageFrequency" (id, parameter, monthly_usage) VALUES (4, 'Very High', 100);
INSERT INTO public."CC_MonthlyUsageFrequency" (id, parameter, monthly_usage) VALUES (5, 'N/A', 0);


-- 6. INSERT public."CC_OtherConstants"
INSERT INTO public."CC_OtherConstants" (id, constant_name, constant_value) VALUES (1, 'Data ingress-egress cost', 100);
INSERT INTO public."CC_OtherConstants" (id, constant_name, constant_value) VALUES (2, 'Hours to fine tune on 1 MB code', 5);
INSERT INTO public."CC_OtherConstants" (id, constant_name, constant_value) VALUES (3, 'Hours to fine tune on 1 GB docs', 30);
INSERT INTO public."CC_OtherConstants" (id, constant_name, constant_value) VALUES (4, 'No. of 1k tokens per 1 MB code', 250);
INSERT INTO public."CC_OtherConstants" (id, constant_name, constant_value) VALUES (5, 'No. of 1k tokens per 1 GB doc', 2720);
INSERT INTO public."CC_OtherConstants" (id, constant_name, constant_value) VALUES (6, 'Monthly Cost Multiplier (Online LLMs)', 1.25);


-- 7. INSERT public."CC_PhaseDetails"
-- DEV
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (1, 'Development', 'High Level Design', 1.5, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (2, 'Development', 'Low Level Design', 1.5, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (3, 'Development', 'UI Design', 5.0, 'Not Applicable', 'N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (4, 'Development', 'Database Design', 5.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (5, 'Development', 'Triage', 5.0, 'High', 'Medium', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (6, 'Development', 'Code Generation', 38.0, 'Medium', 'Medium', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (7, 'Development', 'Unit Test Case Generation', 3.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (8, 'Development', 'Unit Testing', 4.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (9, 'Development', 'Code Upkeep (migration, enhancements)', 15.0, 'Medium', 'Medium', 'High', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (10, 'Development', 'Change Impact Analysis', 10.0, 'Medium', 'High', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (11, 'Development', 'Code Refactoring', 5.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (12, 'Development', 'Code Summarization/Understanding', 2.5, 'Very High', 'Medium', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (13, 'Development', 'Code Analysis/Clone Detection', 2.5, 'High', 'Medium', 'Medium', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (14, 'Development', 'Defect Localization', 2.0, 'Medium', 'Medium', 'Low', 'Blended', 0.00, 'Medium');

-- TEST
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (51, 'Testing', 'Test Plan Development', 2.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (52, 'Testing', 'Test Case Identification', 2.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (53, 'Testing', 'Triage', 10.0, 'Low', 'High', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (54, 'Testing', 'Test Case Generation', 10.0, 'Medium', 'High', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (55, 'Testing', 'Similar Test Case Clustering', 1.0, 'Very High', 'Medium', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (56, 'Testing', 'Test Environment Setup', 2.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (57, 'Testing', 'Test Data Creation', 2.0, 'High', 'High', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (58, 'Testing', 'Test Case Recommendation', 1.0, 'Medium', 'High', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (59, 'Testing', 'Manual Testing', 25.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (60, 'Testing', 'Test Report and Root Cause Analysis', 10.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (61, 'Testing', 'Test Script Generation', 15.0, 'High', 'High', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (62, 'Testing', 'Test Script Optimization', 3.0, 'High', 'High', 'High', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (63, 'Testing', 'Test Script Execution', 1.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (64, 'Testing', 'Test Script Execution Result Analysis', 2.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (65, 'Testing', 'Bug Logging', 5.0, 'Medium', 'Medium', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (66, 'Testing', 'Regression Test Cycle Optimization', 2.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (67, 'Testing', 'Test Suite Failure Analysis', 3.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (68, 'Testing', 'Orphan Defect Identification', 2.0, 'High', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (69, 'Testing', 'Duplicate Bug Reduction', 2.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Medium');

-- SUPPORT
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (101, 'Support', 'Ticket Categorization', 3.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (102, 'Support', 'Similar Ticket Identification', 4.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (103, 'Support', 'Issue Identification', 10.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (104, 'Support', 'Related Issue Identification', 4.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (105, 'Support', 'Issue Summarization', 5.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (106, 'Support', 'Resolution Recommendation', 10.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (107, 'Support', 'Resolution Implementation & Validation', 15.0, 'Low', 'High', 'High', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (108, 'Support', 'Ticket Prioritization', 3.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (109, 'Support', 'Ticket Assignment and Routing', 2.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (110, 'Support', 'Escalation Identification (with tone and sentiment analysis)', 4.0, 'Medium', 'Medium', 'Low', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (111, 'Support', 'Knowledge base article creation', 20.0, 'Very High', 'Medium', 'High', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (112, 'Support', 'Self Service and Technical Support', 10.0, 'Medium', 'Medium', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (113, 'Support', 'Diagnostic Questionnaire Creation', 10.0, 'Very High', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');

-- PM
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (151, 'Program Management', 'Requirement Gathering/Summarization', 15.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (152, 'Program Management', 'Functional specification creation', 20.0, 'High', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (153, 'Program Management', 'Feasibility And Risk Analysis', 10.0, 'Low', 'High', 'High', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (154, 'Program Management', 'Roadmap creation (timelines, milestones and deliverables)', 10.0, 'Low', 'Medium', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (155, 'Program Management', 'Triage', 20.0, 'High', 'High', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (156, 'Program Management', 'Project Planning and tracking (schedule, budget and resource allocation)', 15.0, 'Low', 'Medium', 'Medium', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_PhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (157, 'Program Management', 'Release Planning', 10.0, 'Low', 'Medium', 'Low', 'Blended', 0.00, 'Low');


-- 8. INSERT public."CC_DefaultPhaseDetails"
-- DEV
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (1, 'Development', 'High Level Design', 1.5, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (2, 'Development', 'Low Level Design', 1.5, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (3, 'Development', 'UI Design', 5.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (4, 'Development', 'Database Design', 5.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (5, 'Development', 'Triage', 5.0, 'High', 'Medium', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (6, 'Development', 'Code Generation', 38.0, 'Medium', 'Medium', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (7, 'Development', 'Unit Test Case Generation', 3.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (8, 'Development', 'Unit Testing', 4.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (9, 'Development', 'Code Upkeep (migration, enhancements)', 15.0, 'Medium', 'Medium', 'High', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (10, 'Development', 'Change Impact Analysis', 10.0, 'Medium', 'High', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (11, 'Development', 'Code Refactoring', 5.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (12, 'Development', 'Code Summarization/Understanding', 2.5, 'Very High', 'Medium', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (13, 'Development', 'Code Analysis/Clone Detection', 2.5, 'High', 'Medium', 'Medium', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (14, 'Development', 'Defect Localization', 2.0, 'Medium', 'Medium', 'Low', 'Blended', 0.00, 'Medium');

-- TEST
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (51, 'Testing', 'Test Plan Development', 2.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (52, 'Testing', 'Test Case Identification', 2.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (53, 'Testing', 'Triage', 10.0, 'Low', 'High', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (54, 'Testing', 'Test Case Generation', 10.0, 'Medium', 'High', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (55, 'Testing', 'Similar Test Case Clustering', 1.0, 'Very High', 'Medium', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (56, 'Testing', 'Test Environment Setup', 2.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (57, 'Testing', 'Test Data Creation', 2.0, 'High', 'High', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (58, 'Testing', 'Test Case Recommendation', 1.0, 'Medium', 'High', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (59, 'Testing', 'Manual Testing', 25.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (60, 'Testing', 'Test Report and Root Cause Analysis', 10.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (61, 'Testing', 'Test Script Generation', 15.0, 'High', 'High', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (62, 'Testing', 'Test Script Optimization', 3.0, 'High', 'High', 'High', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (63, 'Testing', 'Test Script Execution', 1.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'N/A');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (64, 'Testing', 'Test Script Execution Result Analysis', 2.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (65, 'Testing', 'Bug Logging', 5.0, 'Medium', 'Medium', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (66, 'Testing', 'Regression Test Cycle Optimization', 2.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (67, 'Testing', 'Test Suite Failure Analysis', 3.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (68, 'Testing', 'Orphan Defect Identification', 2.0, 'High', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (69, 'Testing', 'Duplicate Bug Reduction', 2.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Medium');

-- SUPPORT
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (101, 'Support', 'Ticket Categorization', 3.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (102, 'Support', 'Similar Ticket Identification', 4.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (103, 'Support', 'Issue Identification', 10.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (104, 'Support', 'Related Issue Identification', 4.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (105, 'Support', 'Issue Summarization', 5.0, 'Medium', 'Low', 'Low', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (106, 'Support', 'Resolution Recommendation', 10.0, 'Medium', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (107, 'Support', 'Resolution Implementation & Validation', 15.0, 'Low', 'High', 'High', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (108, 'Support', 'Ticket Prioritization', 3.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (109, 'Support', 'Ticket Assignment and Routing', 2.0, 'Low', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (110, 'Support', 'Escalation Identification (with tone and sentiment analysis)', 4.0, 'Medium', 'Medium', 'Low', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (111, 'Support', 'Knowledge base article creation', 20.0, 'Very High', 'Medium', 'High', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (112, 'Support', 'Self Service and Technical Support', 10.0, 'Medium', 'Medium', 'High', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (113, 'Support', 'Diagnostic Questionnaire Creation', 10.0, 'Very High', 'Medium', 'Medium', 'Blended', 0.00, 'Very High');

-- PM
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (151, 'Program Management', 'Requirement Gathering/Summarization', 15.0, 'Not Applicable','N/A', 'N/A', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (152, 'Program Management', 'Functional specification creation', 20.0, 'High', 'Low', 'Low', 'Blended', 0.00, 'High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (153, 'Program Management', 'Feasibility And Risk Analysis', 10.0, 'Low', 'High', 'High', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (154, 'Program Management', 'Roadmap creation (timelines, milestones and deliverables)', 10.0, 'Low', 'Medium', 'Low', 'Blended', 0.00, 'Low');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (155, 'Program Management', 'Triage', 20.0, 'High', 'High', 'Low', 'Blended', 0.00, 'Very High');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (156, 'Program Management', 'Project Planning and tracking (schedule, budget and resource allocation)', 15.0, 'Low', 'Medium', 'Medium', 'Blended', 0.00, 'Medium');
INSERT INTO public."CC_DefaultPhaseDetails" (id, phase, sub_phase, effort_weightage, benefit_potential,  impl_time_ops_cost, finetune_cycle, billrate_type, custom_billrate, monthly_usage) VALUES (157, 'Program Management', 'Release Planning', 10.0, 'Low', 'Medium', 'Low', 'Blended', 0.00, 'Low');

