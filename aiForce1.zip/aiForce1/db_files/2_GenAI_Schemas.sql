-- public.execution_details

CREATE TABLE IF NOT EXISTS public.execution_details
(
    execution_detail_id serial NOT NULL PRIMARY KEY,
    execution_id integer,
    prompt text,
    title character varying(200),
    result text
);


-- public.execution_info

CREATE TABLE IF NOT EXISTS public.execution_info
(
    execution_id serial NOT NULL PRIMARY KEY ,
    usecase_name character varying(50),
    job_name character varying(50),
    input_prompt text,
    input_files_count integer,
	model_name character varying(50),
    exec_starttime timestamp without time zone,
    exec_endtime timestamp without time zone,
	total_cost character varying(50),
    status boolean,
    isdeleted boolean,
    error_msg text,
	modified_at timestamp,
    project_name character varying(50)
);


-- public.execution_summary

CREATE TABLE IF NOT EXISTS public.execution_summary
(
    summary_id serial NOT NULL PRIMARY KEY,
    execution_id integer,
    key character varying(100),
    value character varying(100),
    remarks character varying(500)
);

-- public.ui_controls

CREATE TABLE IF NOT EXISTS public.ui_controls
(
    id serial NOT NULL PRIMARY KEY,
    usecase_name character varying(50),
    usecase_type character varying(25),
    input_control json,
    input_label json,
    input_data json,
    input_visibility json,
    default_value json,
    prompt_value json,
    additional_info json,
    usecase_info character varying,
    active_status boolean
);



-- DROP THE MASTER TABLE VALUES
-- DROP public.ui_controls
TRUNCATE TABLE public.ui_controls CASCADE;



-- 1. Code Generation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (1, 'Code Generation', 'Default', 
'{
	"1": "dropdown",
	"2": "text_area",
	"3": "radio"
}', '{
	"1": "Programming Language",
	"2": "Enter additional requirement",
	"3": "Security Scanner"
}', '{
	"1": ["Python", "Java","C#","ReactJS","C++"],
	"3": ["Yes", "No"]
}', '{
	"1": "True",
	"2": "True",
	"3": "True"
}', '{
	"1": "Python",
	"2": "Generate comment for each function.",
	"3": "No"
}', '{
	"1": ["Generate Python Code", "Generate Java Code","Generate C# Code","Generate ReactJS Code","Generate C++ Code"]
}', '{
"SCANNER" : "3"
}', '["Code generation is the process of automatically generating source code or SQL script from a high-level specification or model. ","Code generation can be used to improve software development productivity, reduce errors and inconsistencies, and enhance software quality and maintainability.","Code generation results can be displayed on screen as a summary report, which provides a brief overview of the generated code, or a detailed report, which includes more comprehensive information about the generated code''s structure, syntax, and functionality.","The generated code can be downloaded as source code files in the target programming language or platform, which can be compiled, tested, and integrated into the software system."]', true);


-- 2. Code Summarization

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (2, 'Code Summarization', 'Default', '{
	"1": "text_area",
	"2": "text_area",
    "3": "radio",
    "4": "radio",
    "5": "text_area"
}', '{
	"1": "Enter detailed requirement",
	"2": "Define the task description",
    "3": "Summary Type",
    "4": "Security Scanner",
    "5": "Define the task description for function level summary"
}', '{"3": ["File", "Function"], "4": ["Yes", "No"]}', '{
	"1": "True",
	"2": "False",
    "3": "True",
    "4": "True",
    "5": "False"
}', '{
  "1":"Summarize code for the given code files.",
	"2": "Purpose: Understand the purpose of the code and what it is supposed to accomplish. \nFunctionality: Describe the main functions of the code and how they work. \nInput and Output: Mention the inputs the code requires and the output it produces. \nDependencies: Identify any external libraries or modules that the code depends on. \nclasses and Functions: list the classes and functions used in the code and their purpose \nAlgorithms and Data Structures: Explain the algorithms and data structures used in the code. \nExceptions and Error Handling: Mention the exceptions and error handling mechanisms used in the code. \nPerformance: Describe the performance characteristics of the code, including time and space complexity. \nStyle and Formatting: Discuss the code style and formatting conventions, including naming, comments, and indentation.\n The final output all titles and subtitles should be bold.",
    "3": "File",
    "4": "No",
    "5": "**Function:** Name of function.\n\n**Description:**\nUnderstand the purpose of the code and explain in detail that what function is supposed to accomplish.  \n\n** Input:**- List of input parameters along with their data types and use of it.  \n\n**Output:**\nDescription of the output along with its data type.  \n\n**Algorithms and Data Structures:**\nExplain the algorithms and data structures used in the code.  \n\n**Exceptions:**\n- List of any exceptions that can be raised by the function.  \n\n**Dependencies:**\n- List of any external dependencies that the function relies on.  \n\n**Style and Formatting:**\nDiscuss the codes style and formatting conventions, including naming conventions, comments, and indentation.\n---"
}', '{
	"1": "Main Task",
	"2": "Task Description",
    "5": "Function Summary Format"
}', '{"TYPE" : "3", "SCANNER" : "4"}', '["Code summarization is the process of generating a concise and informative summary of a given code snippet or program.", "It involves extracting the most important and relevant information from the code, such as its purpose, functionality, and input/output data.", "We get on screen summary and detailed report for each run (Job), which provides a brief overview of the code, or a detailed report, which includes more comprehensive information about the code''s structure, syntax, and functionality.","The summary and detail reports can be downloaded as PDF format."]', true);


-- 3. Code Clone Detection

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (4, 'Code Clone Detection', 'Chat', '{
	"1": "text_area"
}', '{
	"1": "Enter detailed requirement"
}', '{}', '{
	"1": "True"
}', '{
	"1": "Detect the code clone for given files."
} ', '{
	"1": ""
}', '{}', '["Code clone detection is identifying repeated or duplicated code fragments in given code files.", "It involves analyzing the source code to identify patterns of code that are syntactically or semantically similar to each other.", "Code clone detection results is displayed on screen as a summary and detailed report, which provides a brief overview of the code clones detected, or a detailed report, which includes more comprehensive information about the code clones'' locations, sizes, and contexts.", "The generated reports can be downloaded as PDF files."]', true);


-- 4. Security Assessment

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (5, 'Security Assessment', 'Default', '{
	"1": "text_area"
}', '{
	"1": "Enter detailed requirement"
}', '{}', '{
	"1": "True"
}', '{
	"1": "Detect license, package and code vulnerability for given code files."
} ', '{
	"1": ""
}', '{}', '["Security assessment involves identifying and evaluating potential vulnerabilities and risks in software applications.","License checks involve verifying that the libraries used in the software application adhere to the terms of their licenses. ","Code vulnerability assessments involve analyzing the code for potential security weaknesses or vulnerabilities that could be exploited by attackers. ","This includes checking for common coding mistakes, such as buffer overflows or SQL injection vulnerabilities, that could allow attackers to gain unauthorized access to the system or steal sensitive data. ","The security assessment results are available as a report for user to view/download for any downstream consumption. ","Result can be downloaded as PDF format. "]', true);


-- 5. Change Impact Analysis 

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (3, 'Change Impact Analysis', 'Default', '{
	"1": "text_area",
	"2": "text_area",
    "3":"radio"
}', '{
	"1": "Enter detailed requirement",
	"2": "Define Output Format",
    "3": "Security Scanner"
}', '{"3" : ["Yes", "No"]}', '{
	"1": "True",
	"2": "False",
    "3": "True"
}', '{
    "1":"Xenius - Add OTP authentication support for User login and Password reset functionality.",
    "2": "Analyze the potential effects of this change on the Python files and function and provide a detailed report outlining the impact. \n Note: Some files may or may not have any changes. Only list the files that have the changes. \n\n 1. Proposed Changes: \n - Describe the specific changes proposed to meet the users requirement. \n - list down the file name and potential changes at function level along with its function in detail and describe the changes that will be required to implement the functionality. \n Generate a detailed report by list down the file name and potential changes at function level along with its function in detail and describe the changes that will be required to implement the functionality. \n Generate the output should be in the following example format. Replace the file name with actual file and the function name and its functionality and changes and its dependencies if any. \n file name (for eg. generate_utility.py ) \n The following changes need to be made in the (file name) file: \n - function name(for eg. create_synthetic_data_generate_table()) \n The function creates a table in the database for storing information about generated synthetic data. The SQL query used to create the table needs to be modified to be compatible with MSSQL. \n - dependencies (if any) \n Replace the postgres_conn dependency with the MSSQL connection library. \n\n 2. Dependencies Analysis: \n - Identify external dependencies, third-party libraries, and APIs that impacted by the change. \n - Analyze the potential impact on other modules or functions and its dependencies. \n\n 3. Performance Impact: \n - Assess the potential impact of the changes on the projects performance. \n - Identify critical areas where performance can be affected in files and its function level. \n\n 4. Security Impact: \n - Evaluate the impact of the changes on the security and identify potential security vulnerabilities in function level. \n Generate a detailed change impact analysis report based on the analysis.",
    "3":"No"
} ', '{
	"1": "User change request:",
	"2": ""
}', '{"SCANNER" : "3"}', '["Change impact analysis is the process of identifying the potential effects of a change in a software system on other parts of the system. ", "This use case analyzing the source code, dependencies, and requirements to determine the scope and magnitude of the change and its potential impact on the system''s functionality, performance, and reliability.", "Change impact analysis can be used to reduce the risk of introducing defects or errors into the system, improve the quality of software testing, and support software maintenance and evolution.", "Change Impact results is displayed on screen as a summary and detailed report, which provides a brief overview of the code clones detected, or a detailed report, which includes more comprehensive information about the code clones'' locations, sizes, and contexts.", "The generated reports can be downloaded as PDF files."]', true);


-- 6. SQL Generation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (6, 'SQL Generation', 'Default', '{
	"1": "text_area",
	"2": "text_area",
	"3": "text_area",
	"4":"radio"
}', '{
	"1": "Enter detailed requirement",
	"2": "Enter tables definitions",
	"3": "Additional Information",
	"4": "Security Scanner"
}', '{"4" : ["Yes", "No"]}', '{
	"1": "True",
	"2": "True",
	"3": "False",
	"4":"True"
}', '{
	"1": "Create a stored procedure to get data quality check report including Datasource Name, Datasource Type, Expectation Suite Name, Count of Run, Count of Critical Data Element, Last Run Date Time, Total Failed, Total Passed result.",
	"2": "dqc_report(id, datasource_name, expectation_suite_name, result_status, created_at, updated_at, cde_name)\ndqc_datasources_store(datasource_name, type)\ndqc_expectations_store(expectation_suite_name\ndqc_validations_store(expectation_suite_name, run_time)",
	"3": "Return generated script on the basis of provided information. The generated script should be returned inside single code block. ",
	"4":"No"
}', '{
	"1": "Task Descriptions:",
	"2": "Tables Definitions:"
}', '{"SCANNER" : "4"}', '["SQL generation is the process of generating SQL code based on a set of requirements or specifications.","The process involves taking detailed requirements from the user and table definitions (optional) to generate SQL code satisfying those requirements.","Final result and summary can be downloaded in PDF format."]', true);


-- 7. Code Refactoring

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (7, 'Code Refactoring', 'Default', '{
	"1": "text_area"
}', '{
	"1": "Enter detailed requirement"
}', '{}', '{
	"1": "True"
}', '{
	"1": "Refactor the given code files."
} ', '{
	"1": ""
}', '{}', '["Code Refactoring is the process of improving the structure, design and quality of existing code without changing its functionality.","The process involves analysing the uploaded code to identify areas of improvement and make necessary changes according to the provided user input. ","The results of code refactoring are displayed in the form of a summary and detailed report containing code violations, refactoring plan, refactored code.","The generated reports are downloadable in PDF format."]', true);


-- 8. SQL Summarization


INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (8, 'SQL Summarization', 'Default', '{
	"1": "text_area",
    "2":"radio"
}', '{
	"1": "Enter detailed requirement",
    "2": "Security Scanner"
}', '{ "2" : ["Yes", "No"]}', '{
	"1": "True",
    "2": "True"
}', '{
	"1": "Summarize the given database tables.",
    "2":"No"
} ', '{
	"1": ""
}', '{"SCANNER" : "2"}', '["SQL summarization is the process of generating a concise and informative summary of a given SQL code, making complex SQL queries more understandable for new developers and business stakeholders.","It involves extracting important and relevant information from the SQL code such as tables and attributes involved, the joins, conditions and aggregations used and the overall query structure.","We will get on screen summary and a detailed report for each individual Job containing result summary, profiling, critical data element and rules.","The summary and detailed reports are downloadable in PDF format."]', true);


-- 9. Code Migration


INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (9, 'Code Migration', 'Default', '{
    "1": "dropdown",
    "2": "text_area",
    "3":"radio"
}', '{
    "1": "Migration Type",
    "2":  "Enter detailed requirement",
    "3": "Security Scanner"
}', '{
    "1": ["Code Modernization - Monolith to Microservice", "Code Migration - One Language to Another Language"],
    "2": "Enter detailed requirement",
    "3" : ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True",
    "3": "True"
}', '{
    "1": "Code Modernization - Monolith to Microservice",
    "2": "Service Methods:get_data_services, get_metadata, get_file_data",
    "3":"No"
}', '{
    "1": ""
}', '{"SCANNER" : "3"}', '["Code Migration is the process of modernizing or migrating the code from one language to another language.","It involves extracting the most important and relevant information from the code, such as its purpose, functionality, and input/output data.", "We will get on screen summary and a detailed report for each individual Job containing result summary, code summarization, migration code and supported methods.","The summary and detailed reports are downloadable in PDF format and migrated codes are downloadable in ZIP format."]', true);


-- 10. Unit Test Case Generation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (10, 'Unit Test Case Generation', 'Default', '{
    "1": "text_area",
    "2": "radio"
}', '{
    "1":  "Enter detailed requirement",
    "2": "Security Scanner"
}', '{
    "1": "Enter detailed requirement",
    "2" : ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True"
}', '{
    "1": "Generate unit test case for the given code files.",
    "2":"No"
}', '{
    "1": ""
}', '{"SCANNER" : "2"}', '["Unit Test Case Generation is the process of creating test cases to validate the functionality of a unit of code.", "It involves extracting the most important and relevant information from the code, such as its purpose, inputs, expected outputs, and any dependencies or interactions with other units of code.", "We will get on screen summary and a detailed report for each individual Job containing result summary and uni test cases","The summary and detailed reports are downloadable in PDF format and unit test cases are downloadable in ZIP format."]', true);


-- TESTING USECASES

-- 51. Test Case Generation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (51, 'Test Case Generation', 'Default', '{
    "1": "text_area",
    "2": "radio"
}', '{
    "1": "Enter detailed requirement",
    "2": "Security Scanner"
}', '{
    "2": ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True"
}', '{
    "1": "Test Case Format is - Test Case Id, Title, Prerequisites, Test Steps, Expected Results.",
    "2": "No"
} ', '{
    "1": "",
    "2": ["Yes","No"]
}', '{}', '["Test case generation is the process of generating test cases from the given product/software requirements.", "It involves understanding the requirements/features that need to be available in the product and generate test steps to test that feature.", "A detailed report is generated as output for each run to show the details of the generated test cases including test case ID, test steps, and expected results.", "The summary and detailed report can be downloaded in .pdf format.", "Generated test cases can be downloaded or used for other testing related use cases."]', true);

 
-- 52. Test Script Generation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (52, 'Test Script Generation', 'Default', '{
    "1": "text_area",
    "2": "dropdown",
    "3": "dropdown",
    "4": "radio",
    "5": "radio"
}', '{
    "1": "Add detailed requirement (if Any)",
    "2": "Framework",
    "3": "Programming Language",
    "4": "Security Scanner",
    "5": "Enable Context"
}', '{
    "1": "",
    "2": ["Geb - Spock (Browser Automation/Web Testing Framework)", "HCL eDAT (PowerShell Based Device Testing)", "Jest (Javascript Based Testing Framework for Web Applications)", "pyATS (Python Based Testing Framework for Network Devices)", "Selenium", "None"],
    "3": ["Groovy", "PowerShell", "Python", "Javascript", "Java"],
    "4": ["Yes", "No"],
    "5": ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True",
    "3": "True",
    "4": "True",
    "5": "True" 
    
}', '{
    "1": "Generate Test Script from each of the requirements / Test Cases in the excel.",
    "2": "None",
    "3": "PowerShell",
    "4": "No",
    "5": "No"
}', '{
    "2": ["Generate Test Script using Jest Framework", "Generate Test Script using eDAT Framework", "Generate Test Script using pyATS Framework", "Generate Test Script"],
    "3": ["Generate Java Code", "Generate Powershell Code", "Generate Python Code", "Generate Javascript Code"]
}', '{
"SYSTEM_ROLE" : "1"
}', '["Test script generation is the process of generating test scripts to test the given requirements/features.", "Users can generate test scripts based on the test cases or even using the requirements directly eliminating the need for test case generation.", "Currently Java, Python, PowerShell based test script generation is supported.", "Test scripts can be generated for custom test engines like HCL-eDAT, pyATS, and JEST providing appropriate API and library descriptions.", "As output, a detailed report is generated for each run showing the details of the generated test scripts and the summary to describe the functions of the test scripts.", "Generated test scripts can be downloaded and reviewed for deployment.", "The summary and detailed report can be downloaded in .pdf format."]', true);


-- 53. Test Case Grouping

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status)
VALUES (53, 'Test Case Grouping', 'Default', '{
    "1": "radio",
    "2": "text_area",
	"3": "radio"
	
}', '{
    "1": "Define Role",
    "2": "Please provide the additional ṛequirement info",
	"3": "Security Scanner"
}', '{
    "1": ["Tester/Automation Engineer"],
	"3": ["Yes", "No"]
}', '{
    "1": "False",
    "2": "True",
	"3": "True"
}', '{
    "1": "Tester/Automation Engineer",
    "2": "Group the following test cases.",
	"3": "No"
}', '{
    "1": ["You are a Tester/Automation Engineer"],
    "2": "Requirements:"
}', '{
    "SYSTEM_ROLE" : "1"
}', '["Test case grouping is the process of identifying the similarities across the various test cases.", "It involves searching for similarities in test steps and functions of the test cases.", "A group ID is assigned for the identified group of test cases and the description of the group is also generated and presented.", "Generated test case group details can be downloaded to optimize the test cases or for resource assignment for test execution.", "The summary and detailed report can be downloaded in .pdf format."]', NULL);

-- 54. Test Case Optimization

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status)
VALUES (54, 'Test Case Optimization', 'Default', '{
    "1": "radio",
    "2": "text_area",
	"3": "radio"
}', '{
    "1": "Define Role",
    "2": "Please provide the additional ṛequirement info",
	"3": "Security Scanner"
}', '{
    "1": ["Tester/Automation Engineer"],
	"3": ["Yes", "No"]
}', '{
    "1": "False",
    "2": "True",
	"3": "True"
}', '{
    "1": "Tester/Automation Engineer",
    "2": "Optimize the following test cases.",
	"3": "No"
}', '{
    "1": ["You are a Tester/Automation Engineer"],
    "2": "Requirements:"
}', '{
    "SYSTEM_ROLE" : "1"
}', '["Test case optimization is the process of combining two or more test cases to minimize the redundant test steps and to optimize the testing effort.", "It uses the test cases that are grouped based on similarity in their test steps and expected results.", "A detailed report is generated listing the details of the combined test cases and reduction in test steps.", "Optimized test cases can be downloaded for further usage.", "The summary and detailed report can be downloaded in .pdf format."]', NULL);


-- 55. Orphan Defect Detection

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) 
VALUES (55, 'Orphan Defect Detection', 'Default', '{
    "1": "text_area",
    "2": "radio"
}', '{
    "1": "Enter detailed requirement",
    "2": "Result Display"
}', '{"2": ["All Defects", "Only Orphans"]}', '{
    "1": "True",
    "2": "True"
}', '{
    "1": "Map the defect with test case and show the orphan defect.",
    "2": "All Defects"
} ', '{
    "1": "",
    "2": ["", ""]
}', '{}', '["Orphan defect detection is the process of identifying the orphan defect, that goes unattended during testing process.", "An orphan defect is a defect that has no relationship with any of the test cases. i.e., none of the test cases executed so far have tested the presence or absence of the features.", "Feature to test case mapping and feature to defect mapping is used to detect orphan defects.", "The detected orphan defects can then be used to generate new test cases to test and identify the fix for these defects.", "The generated new test cases are readily downloadable and can be used to ensure test completeness.", "The summary and detailed report can be downloaded in .pdf format."]', true);

-- 56. Duplicate Defect Detection

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) 
VALUES (56, 'Duplicate Defect Detection', 'Default
', '{
    "1" : "radio",
    "2" : "radio",
    "3" : "text_area"
}', '{
    "1": "Process",
    "2": "Search Fields",
    "3": "Defects Related To"
}', '{
    "1": ["Group Defects", "Find Duplicates"],
    "2": ["Defect Title", "Defect Description","Both"]
}', '{
    "1": "True",
    "2": "True",
    "3": "True"
}', '{
    "1": "Group Defects",
    "2": "Both",
    "3": ""
}', '{
    "1": ["You are a Tester", "Automation Engineer"],
    "2": ["in Python", "in Powershell"],
    "3": "Defect related to:"
}', '{
"SYSTEM_ROLE" : "1"
}', '["Duplicate defect detection is a method to detect defects that talk about similar issue/bugs in an application.", "It involves identifying the similarities between the reported defects and grouping the defects that are talking about identical problems.", "The defect that best describe the problem is marked as original defect and other defects present in the group as eliminated as duplicate defect.", "The updated defect log without duplicate defects can be downloaded.", "The summary and detailed report can be downloaded in .pdf format."]', true);

-- 57. Test Suite Failure

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) 
VALUES (57, 'Test Suite Failure', 'Default
', '{
    "1" : "text_area"
}', '{
        "1": "Please provide the additional ṛequirement info (if any):"
}','{}', '{
        "1": "True"
}', '{
    "1": "Identify failure of the automation test suit by analyzing the test execution logs."
}', '{
    "1": ""
}', '{}', '["Test suit failure analysis is a process of detecting the failure of the automation test suit by analyzing the test execution logs.", "Execution of the test scripts is carried out in an automation test suit, and it can fail due to two reasons - failure of the described feature and failure of the test suit.", "This use case involves analyzing the possible exceptions in the test scripts and searching for similarity in the test execution log.", "The test execution log file will get updated to define the failure as a test suit failure or functional failure of the product/software.", "The summary and detailed report can be downloaded in .pdf format."]', true);

-- 58. Test Case Recommendation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) 
VALUES (58, 'Test Case Recommendation', 'Default', '{
    "1": "text_area"
}', '{
    "1": "Please provide the additional ṛequirement info (if any):"
}', '{}', '{
    "1": "True"
}', '{
    "1": "Recommnend the test cases for defect."
} ', '{
    "1": ""
}', '{}', '["Test case recommendation is the process of identifying the test cases that need to be executed for the given defect log during next release.", "It involves analysis of features that was reported as defects log and the test cases responsible to test those features.", "The existing defect log gets updated with the most significant test cases and the log can be downloaded.", "The summary and detailed report can be downloaded in .pdf format."]', true);

-- 59. Test Script Optimization

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status)
VALUES (59, 'Test Script Optimization', 'Default', '{
    "1": "text_area",
    "2": "radio"
}', '{
    "1": "Enter detailed requirement",
    "2": "Security Scanner"
}', '{
    "2": ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True"
}', '{
    "1": "Combine the test scripts based on common test steps.",
    "2": "No"
} ', '{
    "1": "",
    "2": ["Yes","No"]
}', '{}', '["Test script optimization is a process of optimizing the two or more test scripts to accelerate testing process and eliminate redundant codes in the test scripts.", "Like test case optimization, it also tends to reduce the number of steps present in the test scripts.", "It involves detection of redundant code or functions present in the test scripts and combines them to create a new test script.", "The optimized test script can be downloaded for review and deployment.", "The summary and detailed report can be downloaded in .pdf format."]', true);

-- 60. Test Case Updation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status)
VALUES (60, 'Test Case Updation', 'Default', '{
    "1": "text_area",
    "2": "radio"
}', '{
    "1": "Additional Details:",
    "2": "Security Scanner"
}', '{
    "2": ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True"
}', '{
    "1": "Update the provided test case as per the new requirement.",
    "2": "No"
} ', '{
    "1": "",
    "2": ["Yes","No"]
}', '{}', '["This use case deals with updating the existing test case based on the changes in existing requirements.","As part of the use case, Large Language Models (GPT 3.5 Turbo, Llama 2 etc.) are used to evaluate the new requirements and existing test cases to update the test case steps accordingly.","The results are available as part of a report. The new test cases can be downloaded to the local system or published to the source management repo (TFS). Further, the user can also download the report as a pdf file for consumption."]', true);

-- 61. Test Script Updation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (61, 'Test Script Updation', 'Default', '{
    "1": "text_area",
    "2": "radio",
    "3": "radio"
}', '{
    "1": "Add detailed requirement (if Any)",
    "2": "Mapping",
    "3": "Security Scanner"
}', '{
    "1": "",
    "2": ["Yes", "No"],
    "3": ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True",
    "3": "True"
    
}', '{
    "1": "Update the provided test scripts as per the new test cases / requirements.",
    "2": "Yes",
    "3": "No"
}', '{}', '{
"SYSTEM_ROLE" : "1"
}', '["This use case deals with updating the existing test scripts based on the changes in existing test cases or requirements.", "As part of the use case, Large Language Models (GPT 3.5 Turbo, Llama 2 etc.) are used to evaluate the new test cases / requirements and existing test scripts to update the test script steps accordingly.", "The results are available as part of a report. The new test scripts can be downloaded to the local system or published to the source management repo (TFS). Further, the user can also download the report as a pdf file for consumption."]', true);

-- 62. Test Case Standardization

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status)
VALUES (62, 'Test Case Standardization', 'Default', '{
    "1": "text_area",
	"2": "customlist",
	"3": "radio"
}', '{
    "1": "Details:",
    "2": "Attributes:",
	"3": "Security Scanner"
}', '{
    "2": [{
      "name": "Test Case Identifier"
    },
    {
      "name": "Test Case Name"
    },
    {
      "name": "Test Case Description"  
    },
    {
      "name": "Test Environment" 
    },
    {
      "name": "Test Prerequisites"
    },
    {
      "name": "Test Procedure/Steps"
    },
    {
      "name": "Test Priority" 
    },
    {
        "name": "Test Case Traceability"   
    },
    {
        "name": "Test Case Category"  
    },
    {
        "name": "Expected Results"   
    }],
    "3": ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True",
	"3": "True"
}', '{
    "1": "Standardize the format of the uploaded test cases as defined.",
	"3": "No"
}','{
    "1": ""
}','{}', '["Test Case Standardization use case deals with standardizing the input test cases into a user defined standard format.","A detailed report is generated as output for each job run showing the details of the standardized test cases.", "The detailed report can be downloaded in .pdf format for any further use.", "Standardized test cases can be downloaded, pushed to Azure DevOps or pushed to AIForce central data repo for consumption by any downstream use cases."]', true);

-- 101. Q and A

INSERT INTO public.ui_controls (id, usecase_name, usecase_type,input_control,input_label,input_data,input_visibility,default_value, prompt_value,additional_info, usecase_info,active_status)
VALUES( 101, 'Q and A', 'Chat', '{
	"1": "text_area"
}', '{
	"1": "Enter detailed requirement"
}','{}', '{
	"1": "True"
}', '{
	"1": "Retrive answers from the text documents(pdf, text, etc.)."
} ','{
	"1": ""
}','{}',
        '["Q and A use case processes the uploaded project level documents containing functional and technical and information which might be helpful to developers, testers and PMs.", "A chat option in the use case allows users to ask questions and get relevant answers from the uploaded and processed knowledge documents rather than finding the information manually."]',
        true
);


-- 201.	Data Generation
INSERT INTO public.ui_controls (id, usecase_name, usecase_type,input_control,input_label,input_data,input_visibility,default_value, prompt_value,additional_info, usecase_info,active_status)
VALUES (201, 'Data Generation', 'Default',
    '{"1": "text_area"}',
    '{
    "1": "Enter detailed requirement"}',
    '{}',
    '{"1": "True"}',
    '{"1": "Generate Feature Mapping."}',
    '{"1": ""}',
    '{}',
    '[
        "Data mapping is the process of generation of unavailable data or not retriable from project repositories like source code management system, defect management system or test case management system.",
        "Data mapping can be used to generate feature list, feature mapping to test cases and feature mapping to defects.",
        "Data mapping can also be used to generate defect to code elements mapping data and this data can be utilized for related development use cases in this application",
        "Data mapping results can be displayed on screen as a summary report, which provides top 5 records of the generated feature with its mapping data and defect - files mapping data.",
        "The generated data can be downloaded as excel files in zip format"
    ]',
    true
);


-- Backup Old one
-- 501. Code Generation

INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (501, 'Code Generation V1', 'Default', '{
	"1": "radio",
	"2": "dropdown",
	"3": "dropdown",
	"4": "text_area",
	"5": "radio",
	"6": "text_area",
	"7": "text_area",
	"8": "radio",
	"9": "radio",
	"10": "radio",
	"11": "radio",
	"12": "text_area",
	"13":"dropdown",
    "14": "radio"
}', '{
	"1": "Define Role",
	"2": "Programming Language",
	"3": "Define Technique",
	"4":  "Enter detailed requirement",
	"5": "Define Expected Output",
	"6": "Existing Library Context",
	"7": "Define Coding Guidelines",
	"8": "Define Commenting Type",
	"9": "Would you like to generate unit test case for the generated code?",
	"10": "Would you like to generate technical documentation for the generated code?",
	"11": "Would you like the code to be available as a docker deployment?",
	"12": "Additional Information",
	"13":"Output Type",
    "14": "Security Scanner"
}', '{
	"1": ["Developer", "Data Scientist"],
	"2": ["Python", "Java"],
	"3": ["Machine Learning", "Backend Development", "Front End Development"],
	"5": ["Display on Screen", "Expose as a REST Service"],
	"8": ["Function Level", "Line by Line"],
	"9": ["Yes", "No"],
	"10" : ["Yes", "No"],
	"11" : ["Yes", "No"],
	"13" : ["Code","Unit Test Case"],
    "14" : ["Yes", "No"]
}', '{
	"1": "False",
	"2": "True",
	"3": "False",
	"4": "True",
	"5": "False",
	"6": "False",
	"7": "False",
	"8": "False",
	"9": "False",
	"10": "False",
	"11": "False",
	"12": "False",
	"13": "False",
    "14": "True"
}', '{
	"1": "Developer",
	"2": "Python",
	"3": "Machine Learning",
	"4": "Detecting the anomaly for timeseries data.",
	"5": "Display on Screen",
	"6": "To use these functions, import from utils: \n - utils.detect_datetime_column(df) -> identifies the date time column in the data and returns the date time column name \n - utils.fill_missing_values(df, time_col) -> takes in the date time column name and fills missing values \n - utils.encode_categorical_columns(df) -> performs categorical encoding",
	"7": "-Include complete sentence single line comments within all methods of class \n -In each line of code, the character limit is 79 characters \n -Wildcard imports (from import *) should be avoided \n -Follow specific naming conventions: \n *Function name - Lower case and underscore(_) in between the words \n *Class name - Camel case \n *Object name - Lower case and very short name",
	"8": "Function Level",
	"9": "No",
	"10" : "No",
	"11" : "No",
	"13" : "Code",
    "14" : "Yes"
}', '{
	"1": ["You are a software engineer", "You are an Expert Data Scientist"],
	"2": ["Generate Python Code", "Generate Java Code"],
	"3": ["To Solve Machine Learning Problem for", "To Solve Database Problem for", "To Implement React Based UI for"],
	"5": ["Plot chart using mplot library using above code result.", "Create a REST based implementation"],
	"6": "Utilities:",
	"7": "Coding Guidelines:",
	"8": ["Generate comment for each function.", "Generate comment for code line."],
	"9": ["Also generate the all possible unit test cases for generated code", ""],
	"10": ["Generate the well explained technical document for generated code. The generated technical document must have below section Introduction, Problem Statement, Solution Approach, Functionality of Code, Input and Output Format, Conclusion.", ""],
	"11": ["Generate docker file and deployment steps for above code", ""],
	"13":["Return only generated code. The title should be Generated Code. Must return the generated code in inside of single code block. Do not return any code explanation. The final response title and subtitle should be bold.","Generate the unit test case to validate the above code.\n-The test script should cover the class methods and edge case scenarios.\n-Avoid hardcoded output values and substantiate target values using input data\n-Ensure correct behavior without relying on specific output values\n-Remember to follow the coding guidelines mentioned before.\nThe above prompt first generate code and then unit test case. But must return the unit test case only in a single code block."]
}', '{
"SYSTEM_ROLE" : "1",
"SCANNER" : "14"
}', '["Code generation is the process of automatically generating source code or SQL script from a high-level specification or model. ","Code generation can be used to improve software development productivity, reduce errors and inconsistencies, and enhance software quality and maintainability.","Code generation results can be displayed on screen as a summary report, which provides a brief overview of the generated code, or a detailed report, which includes more comprehensive information about the generated code''s structure, syntax, and functionality.","The generated code can be downloaded as source code files in the target programming language or platform, which can be compiled, tested, and integrated into the software system."]', false);


-- Embedding Configuration
-- 501. Code Generation
CREATE TABLE IF NOT EXISTS embedding_configuration(             
    id SERIAL NOT NULL PRIMARY KEY,
    org_id integer,
    llm_model varchar(50),
    config json,
    isactive boolean,
    CONSTRAINT FK_org_id FOREIGN key(org_id) REFERENCES "Organizations"("OrgId"));


-- Update Test case generation default prompt
DELETE FROM public.ui_controls WHERE id = 51;
    
INSERT INTO public.ui_controls (id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, prompt_value, additional_info, usecase_info, active_status) VALUES (51, 'Test Case Generation', 'Default', '{
    "1": "text_area",
    "2": "radio"
}', '{
    "1": "Enter detailed requirement",
    "2": "Security Scanner"
}', '{
    "2": ["Yes", "No"]
}', '{
    "1": "True",
    "2": "True"
}', '{
    "1": "Write detailed all possible test cases covering positive, negative and boundary scenarios for the requirement. Ensure complete coverage is achieved.",
    "2": "No"
} ', '{
    "1": "",
    "2": ["Yes","No"]
}', '{}', '["Test case generation is the process of generating test cases from the given product/software requirements.", "It involves understanding the requirements/features that need to be available in the product and generate test steps to test that feature.", "A detailed report is generated as output for each run to show the details of the generated test cases including test case ID, test steps, and expected results.", "The summary and detailed report can be downloaded in .pdf format.", "Generated test cases can be downloaded or used for other testing related use cases."]', true);
