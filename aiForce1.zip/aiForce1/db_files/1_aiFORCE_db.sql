-- Builds
CREATE TABLE public."Builds" (
    "BuildId" integer NOT NULL,
    "VersionId" integer NOT NULL,
    "BuildNumber" character varying(15) NOT NULL
);

CREATE SEQUENCE public."Builds_BuildId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public."Builds_BuildId_seq" OWNED BY public."Builds"."BuildId";


-- ChangeBasedTestcases

CREATE TABLE public."ChangeBasedTestcases" (
    "Id" integer NOT NULL,
    "Release" character varying(10),
    "TestcaseId" character varying(15),
    "ProjectId" integer
);

CREATE SEQUENCE public."ChangeBasedTestcases_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public."ChangeBasedTestcases_Id_seq" OWNED BY public."ChangeBasedTestcases"."Id";


-- CodeComponents

CREATE TABLE public."CodeComponents" (
    "CodeFileId" integer NOT NULL,
    "ProjectId" integer NOT NULL,
    "FileName" character varying(255) NOT NULL,
    "Release" character varying(15) NOT NULL,
    "Build" character varying(15) NOT NULL,
    "CreatedDate" timestamp without time zone,
    "RevisionId" character varying(20)
);


CREATE SEQUENCE public."CodeComponents_CodeFileId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public."CodeComponents_CodeFileId_seq" OWNED BY public."CodeComponents"."CodeFileId";


-- DefectTestcaseMapping

CREATE TABLE public."DefectTestcaseMapping" (
    "Id" integer NOT NULL,
    "TestcaseId" character varying(15) NOT NULL,
    "DefectId" character varying(15) NOT NULL,
    "ProjectId" integer NOT NULL
);


CREATE SEQUENCE public."DefectTestcaseMapping_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public."DefectTestcaseMapping_Id_seq" OWNED BY public."DefectTestcaseMapping"."Id";


-- DefectsFile

CREATE TABLE public."DefectsFile" (
    "DefectId" character varying(15) NOT NULL,
    "ProjectId" integer NOT NULL,
    "FileList" text NOT NULL,
    "FileDiff" text,
    "BranchName" character varying(200),
    "CommitDate" timestamp without time zone
);

-- DefectsInfo

CREATE TABLE public."DefectsInfo" (
    "DefectId" character varying(15) NOT NULL,
    "ProjectId" integer NOT NULL,
    "Title" character varying(500) NOT NULL,
    "Description" text,
    "Release" character varying(15) NOT NULL,
    "Build" character varying(15) NOT NULL,
    "Priority" smallint,
    "PredictedPriority" smallint,
    "Severity" smallint,
    "CreationDate" timestamp without time zone NOT NULL,
    "Status" character varying(50),
    "CreatedBy" character varying(100),
    "UpdatedBy" character varying(100),
    "ResolvedBy" character varying(100),
    "IsInternal" boolean,
    "ReqType" character varying(50),
    "TestCaseId" character varying(15),
    "IsOrphanDefect" boolean DEFAULT false,
    "FeatureName" character varying(200)
);

-- EnvironmentTestcases

CREATE TABLE public."EnvironmentTestcases" (
    "Id" integer NOT NULL,
    "TestcaseId" character varying(15),
    "ProjectId" integer NOT NULL,
    "MaxCount" integer NOT NULL,
    "TestcaseType" character varying(50)
);


CREATE SEQUENCE public."EnvironmentTestcases_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EnvironmentTestcases_Id_seq" OWNED BY public."EnvironmentTestcases"."Id";


-- Environments

CREATE TABLE public."Environments" (
    "EnvId" integer NOT NULL,
    "ProjectId" integer NOT NULL,
    "EnvName" character varying(50) NOT NULL,
    "IsActive" boolean NOT NULL
);


CREATE SEQUENCE public."Environments_EnvId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Environments_EnvId_seq" OWNED BY public."Environments"."EnvId";


-- FeatureDefects

CREATE TABLE public."FeatureDefects" (
    "Id" integer NOT NULL,
    "FeatureId" integer,
    "DefectId" character varying(15),
    "ProjectId" integer,
    score double precision
);


CREATE SEQUENCE public."FeatureDefects_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FeatureDefects_Id_seq" OWNED BY public."FeatureDefects"."Id";


-- FeatureSourceCode

CREATE TABLE public."FeatureSourceCode" (
    "Id" integer NOT NULL,
    "FeatureId" integer,
    "SourceCodeId" character varying(15),
    "ProjectId" integer,
    score double precision
);


CREATE SEQUENCE public."FeatureSourceCode_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FeatureSourceCode_Id_seq" OWNED BY public."FeatureSourceCode"."Id";


-- FeatureTestcases

CREATE TABLE public."FeatureTestcases" (
    "Id" integer NOT NULL,
    "FeatureId" integer,
    "TestcaseId" character varying(15),
    "ProjectId" integer,
    score double precision
);

CREATE SEQUENCE public."FeatureTestcases_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FeatureTestcases_Id_seq" OWNED BY public."FeatureTestcases"."Id";


-- Features

CREATE TABLE public."Features" (
    "FeatureId" integer NOT NULL,
    "ProjectId" integer NOT NULL,
    "ParentFeatureId" integer,
    "FeatureName" character varying(200),
    "IsActive" boolean NOT NULL,
    "CreatedOn" timestamp without time zone NOT NULL,
    "Keywords" character varying(200)
);

CREATE SEQUENCE public."Features_FeatureId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Features_FeatureId_seq" OWNED BY public."Features"."FeatureId";


-- GoldenTestcases

CREATE TABLE public."GoldenTestcases" (
    "Id" integer NOT NULL,
    "TestcaseId" character varying(15) NOT NULL,
    "ProjectId" integer NOT NULL,
    "MaxCount" integer NOT NULL,
    "TestcaseType" character varying(50)
);

CREATE SEQUENCE public."GoldenTestcases_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GoldenTestcases_Id_seq" OWNED BY public."GoldenTestcases"."Id";


-- Organizations

CREATE TABLE public."Organizations" (
    "OrgId" integer NOT NULL,
    "OrgName" character varying(50) NOT NULL,
    "DomainName" character varying(50) NOT NULL,
    "Description" character varying(500),
    "CreatedOn" timestamp without time zone NOT NULL,
    "IsActive" boolean NOT NULL
);


CREATE SEQUENCE public."Organizations_OrgId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Organizations_OrgId_seq" OWNED BY public."Organizations"."OrgId";


-- Plans

CREATE TABLE public."Plans" (
    "PlanId" integer NOT NULL,
    "PlanName" character varying(50) NOT NULL,
    "ProjectId" integer NOT NULL
);


CREATE SEQUENCE public."Plans_PlanId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public."Plans_PlanId_seq" OWNED BY public."Plans"."PlanId";


-- ProjectFiles

CREATE TABLE public."ProjectFiles" (
    "ProjectFileId" integer NOT NULL,
    "ProjectId" integer NOT NULL,
    "FileType" character varying(50) NOT NULL,
    "FileName" character varying(100) NOT NULL,
    "StartDate" timestamp without time zone NOT NULL,
    "EndDate" timestamp without time zone,
    "Collection" character varying(50) UNIQUE,
    "TotalRows" integer,
    "InsertedRows" integer
);



CREATE SEQUENCE public."ProjectFiles_ProjectFileId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public."ProjectFiles_ProjectFileId_seq" OWNED BY public."ProjectFiles"."ProjectFileId";


--  Projects

CREATE TABLE public."Projects" (
    "ProjectId" integer NOT NULL,
    "OrgId" smallint NOT NULL,
    "ProjectName" character varying(50) NOT NULL UNIQUE,
    "Description" character varying(500),
    "IsDefault" boolean NOT NULL,
    "IsActive" boolean NOT NULL,
    "Token" character varying(100)
);


CREATE SEQUENCE public."Projects_ProjectId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER SEQUENCE public."Projects_ProjectId_seq" OWNED BY public."Projects"."ProjectId";


-- Releases

CREATE TABLE public."Releases" (
    "VersionId" integer NOT NULL,
    "ProjectId" integer NOT NULL,
    "VersionNumber" character varying(15) NOT NULL
);


CREATE SEQUENCE public."Releases_VersionId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Releases_VersionId_seq" OWNED BY public."Releases"."VersionId";


-- Roles

CREATE TABLE public."Roles" (
    "RoleId" integer NOT NULL,
    "RoleName" character varying(50) NOT NULL,
    "SysId" smallint NOT NULL,
    "IsActive" boolean NOT NULL
);


CREATE SEQUENCE public."Roles_RoleId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Roles_RoleId_seq" OWNED BY public."Roles"."RoleId";


-- TestcasesExecution

CREATE TABLE public."TestcasesExecution" (
    "Id" integer NOT NULL,
    "TestcaseId" character varying(15) NOT NULL,
    "ProjectId" integer NOT NULL,
    "Title" character varying(500) NOT NULL,
    "Environment" character varying(500),
    "Release" character varying(15) NOT NULL,
    "Build" character varying(15) NOT NULL,
    "ExecutionDate" timestamp without time zone,
    "ExecutionBy" character varying(100),
    "ExecutionId" character varying(50),
    "PlannedDate" timestamp without time zone,
    "Category" character varying(50),
    "Status" character varying(20)
);


CREATE SEQUENCE public."TestcasesExecution_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TestcasesExecution_Id_seq" OWNED BY public."TestcasesExecution"."Id";


-- TestcasesInfo

CREATE TABLE public."TestcasesInfo" (
    "TestcaseId" character varying(15) NOT NULL,
    "ProjectId" integer NOT NULL,
    "Title" character varying(500) NOT NULL,
    "Description" text,
    "Environment" character varying(500) NOT NULL,
    "FeatureName" character varying(200),
    "Priority" character varying(15),
    "IsAutomated" boolean,
    "TestType" character varying(50),
    "CreationDate" timestamp without time zone NOT NULL,
    "RAG" character varying(10)
);


-- UserOrgs

CREATE TABLE public."UserOrgs" (
    "Id" integer NOT NULL,
    "OrgId" smallint NOT NULL,
    "Uid" integer NOT NULL,
    "IsActive" boolean NOT NULL
);


CREATE SEQUENCE public."UserOrgs_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserOrgs_Id_seq" OWNED BY public."UserOrgs"."Id";


-- Users

CREATE TABLE public."Users" (
    "Uid" integer NOT NULL,
    "LoginName" character varying(50) NOT NULL,
    "Password" character varying(255) NOT NULL,
    "FullName" character varying(50) NOT NULL,
    "EmailId" character varying(100) NOT NULL,
    "RoleId" smallint NOT NULL,
    "IsActive" boolean NOT NULL
);


CREATE SEQUENCE public."Users_Uid_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Users_Uid_seq" OWNED BY public."Users"."Uid";


-- breakeven_calculator

CREATE TABLE public.breakeven_calculator (
    id integer NOT NULL,
    phase character varying(50),
    sub_phase character varying(250),
    effort_weightage numeric(6,3),
    applicability character varying(100),
    person_months numeric(6,2),
    other_cost integer,
    finetune_factor character varying,
    monthly_cost numeric(6,2),
    benefit numeric(6,2),
    default_effort_weightage numeric(6,3)
);



CREATE SEQUENCE public.breakeven_calculator_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.breakeven_calculator_id_seq OWNED BY public.breakeven_calculator.id;


-- SERIAL COLUMN


ALTER TABLE ONLY public."Builds" ALTER COLUMN "BuildId" SET DEFAULT nextval('public."Builds_BuildId_seq"'::regclass);



ALTER TABLE ONLY public."ChangeBasedTestcases" ALTER COLUMN "Id" SET DEFAULT nextval('public."ChangeBasedTestcases_Id_seq"'::regclass);



ALTER TABLE ONLY public."CodeComponents" ALTER COLUMN "CodeFileId" SET DEFAULT nextval('public."CodeComponents_CodeFileId_seq"'::regclass);


ALTER TABLE ONLY public."DefectTestcaseMapping" ALTER COLUMN "Id" SET DEFAULT nextval('public."DefectTestcaseMapping_Id_seq"'::regclass);


ALTER TABLE ONLY public."EnvironmentTestcases" ALTER COLUMN "Id" SET DEFAULT nextval('public."EnvironmentTestcases_Id_seq"'::regclass);


ALTER TABLE ONLY public."Environments" ALTER COLUMN "EnvId" SET DEFAULT nextval('public."Environments_EnvId_seq"'::regclass);


ALTER TABLE ONLY public."FeatureDefects" ALTER COLUMN "Id" SET DEFAULT nextval('public."FeatureDefects_Id_seq"'::regclass);


ALTER TABLE ONLY public."FeatureSourceCode" ALTER COLUMN "Id" SET DEFAULT nextval('public."FeatureSourceCode_Id_seq"'::regclass);


ALTER TABLE ONLY public."FeatureTestcases" ALTER COLUMN "Id" SET DEFAULT nextval('public."FeatureTestcases_Id_seq"'::regclass);


ALTER TABLE ONLY public."Features" ALTER COLUMN "FeatureId" SET DEFAULT nextval('public."Features_FeatureId_seq"'::regclass);


ALTER TABLE ONLY public."GoldenTestcases" ALTER COLUMN "Id" SET DEFAULT nextval('public."GoldenTestcases_Id_seq"'::regclass);


ALTER TABLE ONLY public."Organizations" ALTER COLUMN "OrgId" SET DEFAULT nextval('public."Organizations_OrgId_seq"'::regclass);


ALTER TABLE ONLY public."Plans" ALTER COLUMN "PlanId" SET DEFAULT nextval('public."Plans_PlanId_seq"'::regclass);


ALTER TABLE ONLY public."ProjectFiles" ALTER COLUMN "ProjectFileId" SET DEFAULT nextval('public."ProjectFiles_ProjectFileId_seq"'::regclass);


ALTER TABLE ONLY public."Projects" ALTER COLUMN "ProjectId" SET DEFAULT nextval('public."Projects_ProjectId_seq"'::regclass);


ALTER TABLE ONLY public."Releases" ALTER COLUMN "VersionId" SET DEFAULT nextval('public."Releases_VersionId_seq"'::regclass);


ALTER TABLE ONLY public."Roles" ALTER COLUMN "RoleId" SET DEFAULT nextval('public."Roles_RoleId_seq"'::regclass);


ALTER TABLE ONLY public."TestcasesExecution" ALTER COLUMN "Id" SET DEFAULT nextval('public."TestcasesExecution_Id_seq"'::regclass);


ALTER TABLE ONLY public."UserOrgs" ALTER COLUMN "Id" SET DEFAULT nextval('public."UserOrgs_Id_seq"'::regclass);


ALTER TABLE ONLY public."Users" ALTER COLUMN "Uid" SET DEFAULT nextval('public."Users_Uid_seq"'::regclass);


ALTER TABLE ONLY public.breakeven_calculator ALTER COLUMN id SET DEFAULT nextval('public.breakeven_calculator_id_seq'::regclass);


-- PRIMARY KEY CONSTRAINTS

ALTER TABLE ONLY public."Builds"
    ADD CONSTRAINT "Builds_pkey" PRIMARY KEY ("BuildId");


ALTER TABLE ONLY public."ChangeBasedTestcases"
    ADD CONSTRAINT "ChangeBasedTestcases_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."CodeComponents"
    ADD CONSTRAINT "CodeComponents_pkey" PRIMARY KEY ("CodeFileId");


ALTER TABLE ONLY public."DefectTestcaseMapping"
    ADD CONSTRAINT "DefectTestcaseMapping_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."DefectsFile"
    ADD CONSTRAINT "DefectsFile_pkey" PRIMARY KEY ("DefectId", "ProjectId", "FileList");


ALTER TABLE ONLY public."DefectsInfo"
    ADD CONSTRAINT "DefectsInfo_pkey" PRIMARY KEY ("DefectId", "ProjectId");


ALTER TABLE ONLY public."EnvironmentTestcases"
    ADD CONSTRAINT "EnvironmentTestcases_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."Environments"
    ADD CONSTRAINT "Environments_pkey" PRIMARY KEY ("EnvId");


ALTER TABLE ONLY public."FeatureDefects"
    ADD CONSTRAINT "FeatureDefects_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."FeatureSourceCode"
    ADD CONSTRAINT "FeatureSourceCode_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."FeatureTestcases"
    ADD CONSTRAINT "FeatureTestcases_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."Features"
    ADD CONSTRAINT "Features_pkey" PRIMARY KEY ("FeatureId");


ALTER TABLE ONLY public."GoldenTestcases"
    ADD CONSTRAINT "GoldenTestcases_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."Organizations"
    ADD CONSTRAINT "Organizations_pkey" PRIMARY KEY ("OrgId");


ALTER TABLE ONLY public."Plans"
    ADD CONSTRAINT "Plans_pkey" PRIMARY KEY ("PlanId");


ALTER TABLE ONLY public."ProjectFiles"
    ADD CONSTRAINT "ProjectFiles_pkey" PRIMARY KEY ("ProjectFileId");


ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_pkey" PRIMARY KEY ("ProjectId");


ALTER TABLE ONLY public."Releases"
    ADD CONSTRAINT "Releases_pkey" PRIMARY KEY ("VersionId");


ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY ("RoleId");


ALTER TABLE ONLY public."TestcasesExecution"
    ADD CONSTRAINT "TestcasesExecution_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."TestcasesInfo"
    ADD CONSTRAINT "TestcasesInfo_pkey" PRIMARY KEY ("TestcaseId", "ProjectId", "Environment");


ALTER TABLE ONLY public."UserOrgs"
    ADD CONSTRAINT "UserOrgs_pkey" PRIMARY KEY ("Id");


ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("Uid");


ALTER TABLE ONLY public.breakeven_calculator
    ADD CONSTRAINT breakeven_calculator_pkey PRIMARY KEY (id);


-- UNIQUE KEY CONSTRAINTS

ALTER TABLE ONLY public."CodeComponents"
    ADD CONSTRAINT "unique_CodeComponents" UNIQUE ("ProjectId", "FileName", "Release", "Build");



ALTER TABLE ONLY public."Features"
    ADD CONSTRAINT "unique_Features" UNIQUE ("ProjectId", "FeatureName");



ALTER TABLE ONLY public."TestcasesExecution"
    ADD CONSTRAINT "unique_TestcasesExecution" UNIQUE ("ProjectId", "TestcaseId", "Environment", "Release", "Build", "ExecutionDate");


ALTER TABLE ONLY public."Builds"
    ADD CONSTRAINT unique_build_version UNIQUE ("VersionId", "BuildNumber");


ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT unique_emailid UNIQUE ("EmailId");


ALTER TABLE ONLY public."EnvironmentTestcases"
    ADD CONSTRAINT unique_env_testcase_project UNIQUE ("TestcaseId", "ProjectId");


ALTER TABLE ONLY public."FeatureSourceCode"
    ADD CONSTRAINT unique_feature_code_project UNIQUE ("FeatureId", "SourceCodeId", "ProjectId");


ALTER TABLE ONLY public."FeatureDefects"
    ADD CONSTRAINT unique_feature_defect_project UNIQUE ("FeatureId", "DefectId", "ProjectId");


ALTER TABLE ONLY public."FeatureTestcases"
    ADD CONSTRAINT unique_feature_tc_project UNIQUE ("FeatureId", "TestcaseId", "ProjectId");


ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT unique_loginname UNIQUE ("LoginName");


ALTER TABLE ONLY public."Releases"
    ADD CONSTRAINT unique_proj_version UNIQUE ("ProjectId", "VersionNumber");


ALTER TABLE ONLY public."Environments"
    ADD CONSTRAINT unique_project_env UNIQUE ("EnvName", "ProjectId");


ALTER TABLE ONLY public."ChangeBasedTestcases"
    ADD CONSTRAINT unique_release_tc_project UNIQUE ("Release", "TestcaseId", "ProjectId");


ALTER TABLE ONLY public."DefectTestcaseMapping"
    ADD CONSTRAINT unique_test_defect_project UNIQUE ("TestcaseId", "DefectId", "ProjectId");


ALTER TABLE ONLY public."GoldenTestcases"
    ADD CONSTRAINT unique_testcase_project UNIQUE ("TestcaseId", "ProjectId");


-- CREATE UNIQUE INDEX

CREATE UNIQUE INDEX "IX_Environments" ON public."Environments" USING btree ("EnvName", "ProjectId");


CREATE UNIQUE INDEX "IX_Organizations" ON public."Organizations" USING btree ("DomainName");


CREATE UNIQUE INDEX "IX_Plans" ON public."Plans" USING btree ("ProjectId", "PlanName");


CREATE UNIQUE INDEX "IX_Projects" ON public."Projects" USING btree ("OrgId", "ProjectName");


CREATE UNIQUE INDEX "IX_UserOrganizations" ON public."UserOrgs" USING btree ("OrgId", "Uid");




-- FOREIGN KEY CONSTRAINTS

ALTER TABLE ONLY public."DefectTestcaseMapping"
    ADD CONSTRAINT "FK_DefectTestcasesMapping_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."Environments"
    ADD CONSTRAINT "FK_Environments_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."FeatureDefects"
    ADD CONSTRAINT "FK_FeatureDefects_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."FeatureSourceCode"
    ADD CONSTRAINT "FK_FeatureSourceCode_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."FeatureTestcases"
    ADD CONSTRAINT "FK_FeatureTestcases_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."ProjectFiles"
    ADD CONSTRAINT "FK_ProjectFiles_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "FK_Projects_Organizations" FOREIGN KEY ("OrgId") REFERENCES public."Organizations"("OrgId");


ALTER TABLE ONLY public."TestcasesInfo"
    ADD CONSTRAINT "FK_TestCases_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."TestcasesExecution"
    ADD CONSTRAINT "FK_TestcasesExecution_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


ALTER TABLE ONLY public."UserOrgs"
    ADD CONSTRAINT "FK_UserOrganizations_Organizations" FOREIGN KEY ("OrgId") REFERENCES public."Organizations"("OrgId");


ALTER TABLE ONLY public."UserOrgs"
    ADD CONSTRAINT "FK_UserOrganizations_Users" FOREIGN KEY ("Uid") REFERENCES public."Users"("Uid");


ALTER TABLE ONLY public."Builds"
    ADD CONSTRAINT "FK_Version_Releases" FOREIGN KEY ("VersionId") REFERENCES public."Releases"("VersionId");


ALTER TABLE ONLY public."Releases"
    ADD CONSTRAINT "FK_Versions_Projects" FOREIGN KEY ("ProjectId") REFERENCES public."Projects"("ProjectId");


-- Unstructured File Data Table
CREATE TABLE "UnstructuredFileData" (
    "Id" SERIAL PRIMARY KEY,
    "ProjectId" INT NOT NULL,
    "FileType" VARCHAR(255) NOT NULL,
    "FolderName" VARCHAR(255),
    "FilePath" TEXT NOT NULL,
    "CreatedOn" TIMESTAMP NOT NULL,
    FOREIGN KEY ("ProjectId") REFERENCES "Projects"("ProjectId")
);



-- Default Data


-- Assigning default value  
ALTER TABLE
    "DefectsInfo"
ALTER COLUMN
    "IsInternal"
SET
    DEFAULT TRUE;

INSERT INTO
    "Roles"("RoleName", "SysId", "IsActive")
VALUES
    ('admin', 1, true);

INSERT INTO
    "Organizations"(
        "OrgName",
        "DomainName",
        "Description",
        "CreatedOn",
        "IsActive"
    )
VALUES
    (
        'HCLTech',
        'hcl.com',
        'HCL Technologies Ltd.',
        '2023-10-05 08:22:19.523565',
        true
    );

INSERT INTO
    "Users"(
        "LoginName",
        "Password",
        "FullName",
        "EmailId",
        "RoleId",
        "IsActive"
    )
VALUES
    (
        'admin@hcl.com',
        '$2b$12$mopPSsGDoUmRPqsYbP9VbujBLvfpYaU3mHejhW2IlAPpBi/h/Ho4u',
        'Administrator',
        'admin@hcl.com',
        1,
        true
    );

INSERT INTO
    "UserOrgs"("OrgId", "Uid", "IsActive")
VALUES
    (1, 1, true);

INSERT INTO public."Projects"(
	"OrgId", "ProjectName", "Description", "IsDefault", "IsActive", "Token")
VALUES (1, 'default', 'default project', true, true, 'default_89fe51a3-d2c5-4742-9a69-d82767b91e5b');

---- configuration
CREATE TABLE IF NOT EXISTS public.configuration
                (
                    id serial NOT NULL PRIMARY KEY,
                    org_id integer,
                    llm_model character varying(50),
                    config json,
                    IsActive boolean
                );

ALTER TABLE
    "configuration"
ADD
    CONSTRAINT "FK_org_id" FOREIGN KEY("org_id") REFERENCES "Organizations"("OrgId");

CREATE TABLE IF NOT EXISTS public.security_config
                (
                    id serial NOT NULL PRIMARY KEY,
                    org_id integer,
                    scanner_status character varying(50),
                    input_scanner character varying(200),
                    output_scanner character varying(200),
                    additional_info json
				);
				
ALTER TABLE
    "security_config"
ADD
    CONSTRAINT "FK_org_id" FOREIGN KEY("org_id") REFERENCES "Organizations"("OrgId");
INSERT INTO public.security_config(
	org_id, scanner_status, input_scanner, output_scanner, additional_info)
	VALUES (1, 'yes', '["Anonymize", "Ban Substrings", "Secrets"]', '["Ban Substrings", "Ban Topics", "Language"]', '{}');

ALTER TABLE "DefectsInfo" ADD "Efforts" INTEGER DEFAULT(0);

CREATE TABLE IF NOT EXISTS public.security_keywords
                (
                    id serial NOT NULL PRIMARY KEY,
                    org_id integer,
                    input_keywords jsonb,
                    output_keywords jsonb);

INSERT INTO public.security_keywords(
	org_id, input_keywords, output_keywords)
	VALUES (1, '{"Ban Substrings":["Ignore", "Pretend", "Act", "Imagine", "Assume", "Impersonate", "evil", "ANTIGPT", 
                "Hypothetical", "Delete Database", "Delete all"],
                "Anonymize": ["pseudonymize", "de-identify" , "obfuscate", "mask", "encrypt", "conceal", "disguise"],
                "Secrets":["password", "secret key", "token", "API key", "credentials", "private key", "passphrase",
                "access token", "authentication", "encryption key", "secure storage"], 
                "Ban Topics":[],"Code":[],"Language":[], "Prompt Injection":[], "Regex":[],"Sentiment":[], "Token Limit":[], "Toxicity":[]}',
			'{"Ban Substrings": ["prohibited", "restricted", "banned", "taboo", "off-limits", "objectionable"],
                "Ban Topics": ["assault", "attack","bloodshed","aggression","war"],
                "Language": ["English", "spanish", "french"],
                "Deanonymize": [],
                "Ban Competitors":[], "Bias":[], "Code":[], "JSON":[], "Language Same":[], "Malicious URLs":[], 
                "No Refusal":[], "Reading Time":[], "Factual Consistency":[], "Regex":[], "Relevance":[], "Sensitive":[], "Sentiment":[],
                "Toxicity":[], "URL Reachability":[]}');


---- TFS configuration
CREATE TABLE IF NOT EXISTS public.TFSConfig
                (
                    "id" serial NOT NULL PRIMARY KEY,
                    "repo_url" character varying(100),
                    "pat" character varying(100),
                    "org_name" character varying(50),
                    "proj_name" character varying(50),
                    "repo_name" character varying(50));

---- Changes done on 03 March 2024 for security config page by Richard
DROP TABLE IF EXISTS public.security_config;
CREATE TABLE IF NOT EXISTS public.security_config
                (
                    id serial NOT NULL PRIMARY KEY,
                    org_id integer,
                    scanner_status character varying(50),
                    input_scanner character varying(200),
                    output_scanner character varying(200),
                    additional_info json
				);

ALTER TABLE
    "security_config"
ADD
    CONSTRAINT "FK_org_id" FOREIGN KEY("org_id") REFERENCES "Organizations"("OrgId");
INSERT INTO public.security_config(
	org_id, scanner_status, input_scanner, output_scanner, additional_info)
	VALUES (1, 'yes', '["Anonymize", "Ban Substrings", "Secrets"]', '["BanSubstrings", "BanTopics", "Language"]', '{}');


DROP TABLE IF EXISTS public.security_keywords;
CREATE TABLE IF NOT EXISTS public.security_keywords
                (
                    id serial NOT NULL PRIMARY KEY,
                    org_id integer,
                    input_keywords jsonb,
                    output_keywords jsonb);

INSERT INTO public.security_keywords(
	org_id, input_keywords, output_keywords)
	VALUES (1, '{"Ban Substrings":["Ignore", "Pretend", "Act", "Imagine", "Assume", "Impersonate", "evil", "ANTIGPT",
                "Hypothetical", "Delete Database", "Delete all"],
                "Anonymize": ["pseudonymize", "de-identify" , "obfuscate", "mask", "encrypt", "conceal", "disguise"],
                "Secrets":["password", "secret key", "token", "API key", "credentials", "private key", "passphrase",
                "access token", "authentication", "encryption key", "secure storage"],
                "Ban Topics":[],"Code":[],"Language":[], "Prompt Injection":[], "Regex":[],"Sentiment":[], "Token Limit":[], "Toxicity":[]}',
			'{"BanSubstrings": ["prohibited", "restricted", "banned", "taboo", "off-limits", "objectionable"],
                "BanTopics": ["assault", "attack","bloodshed","aggression","war"],
                "Language": ["English", "spanish", "french"],
                "Deanonymize": [],
                "BanCompetitors":[], "Bias":[], "Code":[], "JSON":[], "LanguageSame":[], "MaliciousURLs":[],
                "NoRefusal":[], "ReadingTime":[], "FactualConsistency":[], "Regex":[], "Relevance":[], "Sensitive":[], "Sentiment":[],
                "Toxicity":[], "URLReachability":[]}');
